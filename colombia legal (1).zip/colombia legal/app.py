from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
import json
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
import io
import base64
from PIL import Image, ImageDraw, ImageFont
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re
import unicodedata
import numpy as np
from analytics_system import analytics
from predictive_analytics import predictive_analytics
from recommendation_system import recommendation_system
from external_integrations import api_blueprint, external_integrations

app = Flask(__name__)
app.secret_key = 'colombia_legal_secret_key_2025'

# Registrar blueprint de API
app.register_blueprint(api_blueprint)

# Configuración de búsqueda inteligente
class SmartSearch:
    def __init__(self):
        self.vectorizer = None
        self.tfidf_matrix = None
        self.documents = []
        self.initialized = False
        
        # Palabras clave para diferentes tipos de preguntas
        self.question_patterns = {
            'que_es': ['qué es', 'que es', 'define', 'definir', 'concepto', 'significa'],
            'como': ['cómo', 'como', 'de qué manera', 'procedimiento'],
            'cuando': ['cuándo', 'cuando', 'fecha', 'tiempo'],
            'donde': ['dónde', 'donde', 'lugar', 'ubicación'],
            'quien': ['quién', 'quien', 'responsable', 'encargado'],
            'por_que': ['por qué', 'porque', 'razón', 'motivo'],
            'cuanto': ['cuánto', 'cuanto', 'cantidad', 'monto', 'valor']
        }
    
    def normalize_text(self, text):
        """Normaliza texto para mejor búsqueda"""
        if not text:
            return ""
        
        # Convertir a minúsculas
        text = text.lower()
        
        # Remover acentos
        text = unicodedata.normalize('NFKD', text)
        text = ''.join([c for c in text if not unicodedata.combining(c)])
        
        # Remover caracteres especiales pero mantener espacios
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # Remover espacios múltiples
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def initialize(self):
        """Inicializa el sistema de búsqueda con los documentos actuales"""
        try:
            conn = sqlite3.connect('legislation.db')
            c = conn.cursor()
            
            c.execute('''
                SELECT id, title, content, full_text, keywords, category, document_type, document_number
                FROM documents
            ''')
            
            results = c.fetchall()
            conn.close()
            
            if not results:
                print("No se encontraron documentos en la base de datos")
                return False
            
            # Preparar documentos para vectorización
            self.documents = []
            texts_for_vectorization = []
            
            for row in results:
                doc = {
                    'id': row[0],
                    'title': row[1],
                    'content': row[2],
                    'full_text': row[3] or row[2],  # Usar content si full_text está vacío
                    'keywords': row[4] or '',
                    'category': row[5],
                    'document_type': row[6],
                    'document_number': row[7] or ''
                }
                self.documents.append(doc)
                
                # Combinar texto para vectorización
                combined_text = f"{doc['title']} {doc['content']} {doc['keywords']}"
                texts_for_vectorization.append(self.normalize_text(combined_text))
            
            # Crear vectorizador TF-IDF
            self.vectorizer = TfidfVectorizer(
                max_features=5000,
                stop_words=None,  # No usamos stop words en español por simplicidad
                ngram_range=(1, 2),  # Unigrams y bigrams
                min_df=1,
                max_df=0.95
            )
            
            # Vectorizar documentos
            self.tfidf_matrix = self.vectorizer.fit_transform(texts_for_vectorization)
            
            self.initialized = True
            print(f"Sistema de búsqueda inicializado con {len(self.documents)} documentos")
            return True
            
        except Exception as e:
            print(f"Error inicializando búsqueda inteligente: {e}")
            self.initialized = False
            return False
    
    def search_documents(self, query, max_results=1):
        """Búsqueda inteligente con scoring"""
        if not self.initialized:
            return []
        
        try:
            # Normalizar query
            normalized_query = self.normalize_text(query)
            
            # Vectorizar la consulta
            query_vector = self.vectorizer.transform([normalized_query])
            
            # Calcular similitudes
            similarities = cosine_similarity(query_vector, self.tfidf_matrix).flatten()
            
            # Obtener índices ordenados por similitud
            ranked_indices = similarities.argsort()[::-1]
            
            results = []
            for idx in ranked_indices[:max_results]:
                if similarities[idx] > 0.01:  # Umbral mínimo de relevancia
                    doc = self.documents[idx].copy()
                    doc['relevance_score'] = float(similarities[idx])
                    doc['score_percentage'] = int(similarities[idx] * 100)
                    results.append(doc)
            
            return results
            
        except Exception as e:
            print(f"Error en búsqueda: {e}")
            return []
    
    def answer_question(self, question):
        """Responde preguntas usando búsqueda inteligente"""
        if not self.initialized:
            return "El sistema de búsqueda no está disponible en este momento."
        
        try:
            # Buscar documentos relevantes
            relevant_docs = self.search_documents(question, max_results=1)
            
            if not relevant_docs:
                return "No encontré información relevante para responder tu pregunta. Intenta con términos más específicos sobre legislación colombiana."
            
            # Determinar tipo de pregunta
            question_type = self.detect_question_type(question)
            
            # Generar respuesta basada en documentos relevantes
            answer = self.generate_answer(question, relevant_docs, question_type)
            
            return answer
            
        except Exception as e:
            return f"Error procesando la pregunta: {str(e)}"
    
    def detect_question_type(self, question):
        """Detecta el tipo de pregunta para dar mejor respuesta"""
        question_lower = question.lower()
        
        for q_type, patterns in self.question_patterns.items():
            for pattern in patterns:
                if pattern in question_lower:
                    return q_type
        
        return 'general'
    
    def generate_answer(self, question, relevant_docs, question_type):
        """Genera respuesta basada en documentos relevantes"""
        if not relevant_docs:
            return "No se encontró información relevante."
        
        # Tomar los documentos más relevantes
        top_docs = relevant_docs[:3]
        
        # Construir respuesta
        answer_parts = []
        
        # Introducción
        if question_type == 'que_es':
            answer_parts.append("Según la legislación colombiana:")
        elif question_type == 'como':
            answer_parts.append("De acuerdo con las normas vigentes:")
        else:
            answer_parts.append("Basado en la información legal disponible:")
        
        # Agregar información de documentos relevantes
        for i, doc in enumerate(top_docs, 1):
            doc_info = f"\n\n{i}. **{doc['title']}**"
            if doc['document_type'] and doc['document_number']:
                doc_info += f" ({doc['document_type']} {doc['document_number']})"
            
            # Encontrar la parte más relevante del contenido
            content_snippet = self.extract_relevant_snippet(question, doc['content'])
            doc_info += f"\n{content_snippet}"
            
            if doc['score_percentage'] > 20:  # Solo mostrar documentos muy relevantes
                answer_parts.append(doc_info)
        
        # Agregar disclaimer
        answer_parts.append("\n\n*Esta información es extraída de la base de datos legal. Para casos específicos, consulte con un profesional del derecho.*")
        
        return ''.join(answer_parts)
    
    def extract_relevant_snippet(self, question, content, max_length=300):
        """Extrae el fragmento más relevante del contenido"""
        if not content:
            return ""
        
        # Buscar términos de la pregunta en el contenido
        question_terms = self.normalize_text(question).split()
        content_normalized = self.normalize_text(content)
        
        # Encontrar la mejor posición
        best_pos = 0
        max_matches = 0
        
        # Dividir contenido en fragmentos
        words = content.split()
        for i in range(0, len(words), 20):  # Ventana deslizante de 20 palabras
            snippet = ' '.join(words[i:i+50])  # Tomar 50 palabras
            snippet_normalized = self.normalize_text(snippet)
            
            matches = sum(1 for term in question_terms if term in snippet_normalized)
            if matches > max_matches:
                max_matches = matches
                best_pos = i
        
        # Extraer el mejor fragmento
        if best_pos + 50 < len(words):
            snippet = ' '.join(words[best_pos:best_pos+50])
        else:
            snippet = ' '.join(words[:min(50, len(words))])
        
        if len(snippet) > max_length:
            snippet = snippet[:max_length] + "..."
        
        return snippet

# Instancia global de búsqueda inteligente
smart_search = SmartSearch()

# Inicializar las bases de datos
def init_db():
    # Base de datos de usuarios
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            document_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    conn.commit()
    conn.close()
    
    # Base de datos de legislación
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            subcategory TEXT,
            date_published DATE,
            document_type TEXT,
            document_number TEXT,
            keywords TEXT,
            full_text TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Insertar datos de ejemplo
    sample_documents = [
        {
            'title': 'Constitución Política de Colombia - Artículo 1',
            'content': 'Colombia es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, con autonomía de sus entidades territoriales, democrática, participativa y pluralista, fundada en el respeto de la dignidad humana, en el trabajo y la solidaridad de las personas que la integran y en la prevalencia del interés general.',
            'category': 'Constitución',
            'subcategory': 'Principios Fundamentales',
            'date_published': '1991-07-04',
            'document_type': 'Constitución',
            'document_number': 'Art. 1',
            'keywords': 'estado social derecho república democrática',
            'full_text': 'ARTÍCULO 1. Colombia es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, con autonomía de sus entidades territoriales, democrática, participativa y pluralista, fundada en el respeto de la dignidad humana, en el trabajo y la solidaridad de las personas que la integran y en la prevalencia del interés general.'
        },
        {
            'title': 'Código Civil Colombiano - Artículo 1',
            'content': 'La ley es una declaración de la voluntad soberana que, manifestada en la forma prescrita por la Constitución, manda, prohíbe o permite.',
            'category': 'Código Civil',
            'subcategory': 'Disposiciones Generales',
            'date_published': '1887-05-26',
            'document_type': 'Código',
            'document_number': 'Art. 1',
            'keywords': 'ley voluntad soberana constitución',
            'full_text': 'ARTÍCULO 1°. La ley es una declaración de la voluntad soberana que, manifestada en la forma prescrita por la Constitución, manda, prohíbe o permite.'
        },
        {
            'title': 'Ley 906 de 2004 - Código de Procedimiento Penal',
            'content': 'Por la cual se expide el Código de Procedimiento Penal. El presente código tiene por objeto establecer las normas que rigen la actuación de la Fiscalía General de la Nación, la Policía Judicial, los jueces y tribunales penales, la defensa, las víctimas y los terceros intervinientes en el desarrollo de la investigación y el juzgamiento de las conductas punibles.',
            'category': 'Procedimiento Penal',
            'subcategory': 'Código Procedimiento',
            'date_published': '2004-08-31',
            'document_type': 'Ley',
            'document_number': '906',
            'keywords': 'procedimiento penal fiscalía investigación juzgamiento',
            'full_text': 'LEY 906 DE 2004. Por la cual se expide el Código de Procedimiento Penal. El Congreso de Colombia DECRETA: ARTÍCULO 1°. OBJETO. El presente código tiene por objeto establecer las normas que rigen la actuación de la Fiscalía General de la Nación, la Policía Judicial, los jueces y tribunales penales, la defensa, las víctimas y los terceros intervinientes en el desarrollo de la investigación y el juzgamiento de las conductas punibles.'
        }
    ]
    
    for doc in sample_documents:
        c.execute('''
            INSERT OR IGNORE INTO documents 
            (title, content, category, subcategory, date_published, document_type, document_number, keywords, full_text)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (doc['title'], doc['content'], doc['category'], doc['subcategory'], 
              doc['date_published'], doc['document_type'], doc['document_number'], 
              doc['keywords'], doc['full_text']))
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT id, username, password_hash FROM users WHERE username = ?', (username,))
        user = c.fetchone()
        conn.close()
        
        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            flash(f'¡Bienvenido/a {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Credenciales incorrectas', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        password_hash = generate_password_hash(password)
        
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                     (username, email, password_hash))
            conn.commit()
            conn.close()
            
            flash('Registro exitoso. Por favor inicia sesión.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('El usuario o email ya existe', 'error')
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Has cerrado sesión correctamente', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/search')
def search():
    query = request.args.get('q', '')
    start_time = datetime.now()
    
    if not query:
        return jsonify({'documents': [], 'suggestions': []})
    
    user_id = session.get('user_id')
    category_filter = request.args.get('category', '')
    
    # Usar búsqueda inteligente si está disponible
    if smart_search.initialized:
        try:
            # Búsqueda con scoring inteligente
            results = smart_search.search_documents(query, max_results=1)
            
            documents = []
            for doc in results:
                documents.append({
                    'id': doc['id'],
                    'title': doc['title'],
                    'content': doc['content'][:200] + '...' if len(doc['content']) > 200 else doc['content'],
                    'category': doc['category'],
                    'subcategory': doc.get('subcategory', ''),
                    'document_type': doc['document_type'],
                    'document_number': doc['document_number'],
                    'relevance_score': doc['relevance_score'],
                    'score_percentage': doc['score_percentage']
                })
            
            # Calcular duración de búsqueda
            search_duration = (datetime.now() - start_time).total_seconds() * 1000
            
            # Log de la búsqueda
            analytics.log_search(
                user_id=user_id,
                search_query=query,
                category_filter=category_filter,
                results_count=len(documents),
                search_duration_ms=int(search_duration)
            )
            
            # Log de actividad del usuario
            analytics.log_user_activity(
                user_id=user_id,
                username=session.get('username'),
                action_type='search',
                details={'query': query, 'results_count': len(documents)},
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            
            return jsonify({'documents': documents})
            
        except Exception as e:
            print(f"Error en búsqueda inteligente: {e}")
            # Fallback a búsqueda básica
            pass
    
    # Búsqueda básica como fallback
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    # Búsqueda en título, contenido y palabras clave
    search_query = f'%{query}%'
    c.execute('''
        SELECT DISTINCT id, title, content, category, subcategory, document_type, document_number
        FROM documents 
        WHERE title LIKE ? OR content LIKE ? OR keywords LIKE ?
        ORDER BY 
            CASE 
                WHEN title LIKE ? THEN 1
                WHEN keywords LIKE ? THEN 2
                ELSE 3
            END,
            title
        LIMIT 1
    ''', (search_query, search_query, search_query, search_query, search_query))
    
    results = c.fetchall()
    conn.close()
    
    documents = []
    for row in results:
        documents.append({
            'id': row[0],
            'title': row[1],
            'content': row[2][:200] + '...' if len(row[2]) > 200 else row[2],
            'category': row[3],
            'subcategory': row[4] or '',
            'document_type': row[5],
            'document_number': row[6],
            'relevance_score': 0.5,
            'score_percentage': 50
        })
    
    # Calcular duración de búsqueda
    search_duration = (datetime.now() - start_time).total_seconds() * 1000
    
    # Log de la búsqueda (fallback)
    analytics.log_search(
        user_id=user_id,
        search_query=query,
        category_filter=category_filter,
        results_count=len(documents),
        search_duration_ms=int(search_duration)
    )
    
    # Log de actividad del usuario
    analytics.log_user_activity(
        user_id=user_id,
        username=session.get('username'),
        action_type='search',
        details={'query': query, 'results_count': len(documents), 'search_type': 'fallback'},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    return jsonify({'documents': documents})
    
    results = c.fetchall()
    conn.close()
    
    documents = []
    seen_titles = set()  # Para rastrear títulos ya vistos
    for row in results:
        title = row[1]
        # Solo agregar si no hemos visto este título antes
        if title not in seen_titles:
            seen_titles.add(title)
            documents.append({
                'id': row[0],
                'title': title,
                'content': row[2][:200] + '...' if len(row[2]) > 200 else row[2],
                'category': row[3],
                'subcategory': row[4],
                'document_type': row[5],
                'document_number': row[6],
                'relevance_score': 0.5,  # Valor por defecto para búsqueda básica
                'score_percentage': 50
            })
    
    return jsonify({'documents': documents})

@app.route('/autocomplete')
def autocomplete():
    query = request.args.get('q', '')
    
    if len(query) < 2:
        return jsonify([])
    
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    search_query = f'%{query}%'
    c.execute('''
        SELECT DISTINCT title FROM documents 
        WHERE title LIKE ? 
        ORDER BY title 
        LIMIT 10
    ''', (search_query,))
    
    suggestions = [row[0] for row in c.fetchall()]
    conn.close()
    
    return jsonify(suggestions)

@app.route('/document/<int:doc_id>')
def view_document(doc_id):
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('''
        SELECT id, title, content, category, subcategory, date_published, 
               document_type, document_number, keywords, full_text
        FROM documents WHERE id = ?
    ''', (doc_id,))
    
    document = c.fetchone()
    conn.close()
    
    if not document:
        flash('Documento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    doc_dict = {
        'id': document[0],
        'title': document[1],
        'content': document[2],
        'category': document[3],
        'subcategory': document[4],
        'date_published': document[5],
        'document_type': document[6],
        'document_number': document[7],
        'keywords': document[8],
        'full_text': document[9]
    }
    
    # Log de visualización de documento
    user_id = session.get('user_id')
    analytics.log_document_view(
        document_id=doc_id,
        user_id=user_id,
        action='view'
    )
    
    # Log de actividad del usuario
    analytics.log_user_activity(
        user_id=user_id,
        username=session.get('username'),
        action_type='view_document',
        details={'document_id': doc_id, 'document_title': document[1]},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    return render_template('document.html', document=doc_dict)

@app.route('/add_favorite/<int:doc_id>', methods=['POST'])
def add_favorite(doc_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Debes iniciar sesión'})
    
    user_id = session['user_id']
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    
    # Verificar si ya está en favoritos
    c.execute('SELECT id FROM user_favorites WHERE user_id = ? AND document_id = ?', 
              (user_id, doc_id))
    existing = c.fetchone()
    
    if existing:
        return jsonify({'success': False, 'message': 'Ya está en favoritos'})
    
    c.execute('INSERT INTO user_favorites (user_id, document_id) VALUES (?, ?)',
              (user_id, doc_id))
    conn.commit()
    conn.close()
    
    # Log de favorito agregado
    analytics.log_document_view(
        document_id=doc_id,
        user_id=user_id,
        action='favorite'
    )
    
    analytics.log_user_activity(
        user_id=user_id,
        username=session.get('username'),
        action_type='add_favorite',
        details={'document_id': doc_id},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    return jsonify({'success': True, 'message': 'Añadido a favoritos'})

@app.route('/remove_favorite/<int:doc_id>', methods=['POST'])
def remove_favorite(doc_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Debes iniciar sesión'})
    
    user_id = session['user_id']
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('DELETE FROM user_favorites WHERE user_id = ? AND document_id = ?',
              (user_id, doc_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Eliminado de favoritos'})

@app.route('/favorites')
def favorites():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    
    conn_users = sqlite3.connect('users.db')
    conn_docs = sqlite3.connect('legislation.db')
    
    c_users = conn_users.cursor()
    c_docs = conn_docs.cursor()
    
    c_users.execute('SELECT document_id FROM user_favorites WHERE user_id = ?', (user_id,))
    favorite_ids = [row[0] for row in c_users.fetchall()]
    
    favorite_documents = []
    for doc_id in favorite_ids:
        c_docs.execute('''
            SELECT id, title, content, category, subcategory, document_type, document_number
            FROM documents WHERE id = ?
        ''', (doc_id,))
        doc = c_docs.fetchone()
        if doc:
            favorite_documents.append({
                'id': doc[0],
                'title': doc[1],
                'content': doc[2][:200] + '...' if len(doc[2]) > 200 else doc[2],
                'category': doc[3],
                'subcategory': doc[4],
                'document_type': doc[5],
                'document_number': doc[6]
            })
    
    conn_users.close()
    conn_docs.close()
    
    return render_template('favorites.html', documents=favorite_documents)

@app.route('/download_pdf/<int:doc_id>')
def download_pdf(doc_id):
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('SELECT title, full_text, category, document_type, document_number FROM documents WHERE id = ?', (doc_id,))
    document = c.fetchone()
    conn.close()
    
    if not document:
        flash('Documento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    # Crear PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Estilos personalizados
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=TA_CENTER,
        textColor=colors.HexColor('#1e3a8a')
    )
    
    watermark_style = ParagraphStyle(
        'Watermark',
        parent=styles['Normal'],
        fontSize=10,
        alignment=TA_CENTER,
        textColor=colors.grey
    )
    
    content_style = ParagraphStyle(
        'Content',
        parent=styles['Normal'],
        fontSize=12,
        alignment=TA_JUSTIFY,
        spaceAfter=12
    )
    
    story = []
    
    # Título del documento
    story.append(Paragraph(document[0], title_style))
    story.append(Spacer(1, 12))
    
    # Información del documento
    info = f"<b>Categoría:</b> {document[2]}<br/>"
    info += f"<b>Tipo:</b> {document[3]}<br/>"
    info += f"<b>Número:</b> {document[4]}<br/>"
    story.append(Paragraph(info, styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Contenido
    story.append(Paragraph(document[1], content_style))
    story.append(Spacer(1, 30))
    
    # Marca de agua
    watermark_text = "Generado por Colombia Legal - Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares"
    story.append(Paragraph(watermark_text, watermark_style))
    
    doc.build(story)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'Colombia_Legal_{document[0][:50]}.pdf',
        mimetype='application/pdf'
    )

@app.route('/download/<format>/<int:doc_id>')
def download_multiple_formats(format, doc_id):
    """Download document in multiple formats"""
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('SELECT title, full_text, category, document_type, document_number FROM documents WHERE id = ?', (doc_id,))
    document = c.fetchone()
    conn.close()
    
    if not document:
        return jsonify({'error': 'Documento no encontrado'}), 404
    
    title, content, category, doc_type, doc_number = document
    
    # Sanitize filename
    safe_title = ''.join(c for c in title[:50] if c.isalnum() or c in (' ', '-', '_')).rstrip()
    
    try:
        if format.lower() == 'docx':
            return download_as_docx(doc_id, title, content, category, doc_type, doc_number, safe_title)
        elif format.lower() == 'txt':
            return download_as_txt(doc_id, title, content, category, doc_type, doc_number, safe_title)
        elif format.lower() == 'html':
            return download_as_html(doc_id, title, content, category, doc_type, doc_number, safe_title)
        elif format.lower() == 'json':
            return download_as_json(doc_id, title, content, category, doc_type, doc_number, safe_title)
        elif format.lower() == 'epub':
            return download_as_epub(doc_id, title, content, category, doc_type, doc_number, safe_title)
        elif format.lower() == 'csv':
            return download_as_csv(doc_id, title, content, category, doc_type, doc_number, safe_title)
        else:
            return jsonify({'error': 'Formato no soportado'}), 400
            
    except Exception as e:
        print(f"Error generating {format} file: {e}")
        return jsonify({'error': f'Error generando archivo {format.upper()}'}), 500

def download_as_docx(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate DOCX file"""
    try:
        from docx import Document
        from docx.shared import Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        # Create document
        doc = Document()
        
        # Add title
        title_para = doc.add_heading(title, 0)
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add document info
        info_para = doc.add_paragraph()
        info_para.add_run(f"Categoría: ").bold = True
        info_para.add_run(f"{category}\n")
        info_para.add_run(f"Tipo: ").bold = True
        info_para.add_run(f"{doc_type}\n")
        info_para.add_run(f"Número: ").bold = True
        info_para.add_run(f"{doc_number}\n")
        
        # Add content
        doc.add_paragraph(content)
        
        # Add footer
        footer_para = doc.add_paragraph()
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer_para.add_run("Generado por Colombia Legal - Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares")
        footer_run.italic = True
        
        # Save to buffer
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        return send_file(
            buffer,
            as_attachment=True,
            download_name=f'Colombia_Legal_{safe_title}.docx',
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        
    except ImportError:
        # Fallback if python-docx is not installed
        return jsonify({'error': 'Formato DOCX no disponible. Usa PDF en su lugar.'}), 501

def download_as_txt(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate plain text file"""
    txt_content = f"{title}\n"
    txt_content += "=" * len(title) + "\n\n"
    txt_content += f"Categoría: {category}\n"
    txt_content += f"Tipo: {doc_type}\n"
    txt_content += f"Número: {doc_number}\n\n"
    txt_content += content + "\n\n"
    txt_content += "---\n"
    txt_content += "Generado por Colombia Legal\n"
    txt_content += "Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares"
    
    buffer = io.BytesIO()
    buffer.write(txt_content.encode('utf-8'))
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'Colombia_Legal_{safe_title}.txt',
        mimetype='text/plain'
    )

def download_as_html(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate HTML file"""
    html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
            line-height: 1.6;
            color: #333;
        }}
        .header {{
            text-align: center;
            margin-bottom: 2rem;
            border-bottom: 3px solid #1e3a8a;
            padding-bottom: 1rem;
        }}
        h1 {{
            color: #1e3a8a;
            margin-bottom: 0.5rem;
        }}
        .document-info {{
            background: #f8fafc;
            padding: 1rem;
            border-radius: 8px;
            margin: 1.5rem 0;
        }}
        .info-item {{
            margin: 0.5rem 0;
        }}
        .info-label {{
            font-weight: bold;
            color: #1e3a8a;
        }}
        .content {{
            text-align: justify;
            margin: 2rem 0;
        }}
        .footer {{
            margin-top: 3rem;
            padding-top: 1rem;
            border-top: 1px solid #e2e8f0;
            text-align: center;
            font-size: 0.9em;
            color: #64748b;
            font-style: italic;
        }}
        @media print {{
            body {{ margin: 0; }}
            .header {{ page-break-after: avoid; }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
    </div>
    
    <div class="document-info">
        <div class="info-item">
            <span class="info-label">Categoría:</span> {category}
        </div>
        <div class="info-item">
            <span class="info-label">Tipo:</span> {doc_type}
        </div>
        <div class="info-item">
            <span class="info-label">Número:</span> {doc_number}
        </div>
    </div>
    
    <div class="content">
        {content.replace(chr(10), '<br>')}
    </div>
    
    <div class="footer">
        <p>Documento exportado desde Colombia Legal</p>
        <p>Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares</p>
        <p>Fecha de exportación: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
    </div>
</body>
</html>"""
    
    buffer = io.BytesIO()
    buffer.write(html_content.encode('utf-8'))
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'Colombia_Legal_{safe_title}.html',
        mimetype='text/html'
    )

def download_as_json(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate JSON file"""
    import json
    
    json_data = {
        "document": {
            "id": doc_id,
            "title": title,
            "category": category,
            "document_type": doc_type,
            "document_number": doc_number,
            "content": content,
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "exported_by": "Colombia Legal",
                "format": "json",
                "version": "1.0",
                "character_count": len(content),
                "word_count": len(content.split())
            },
            "authors": [
                "Vicente Soto Liemann",
                "Juan David Cardona Lopez", 
                "Sharon Sofia Castellanos Alvares"
            ]
        }
    }
    
    buffer = io.BytesIO()
    json_str = json.dumps(json_data, ensure_ascii=False, indent=2)
    buffer.write(json_str.encode('utf-8'))
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'Colombia_Legal_{safe_title}.json',
        mimetype='application/json'
    )

def download_as_epub(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate EPUB file (simplified version)"""
    try:
        from ebooklib import epub
        
        book = epub.EpubBook()
        book.set_identifier(f'colombia-legal-{doc_id}')
        book.set_title(title)
        book.set_language('es')
        book.add_author('Colombia Legal')
        
        # Create chapter
        chapter = epub.EpubHtml(title='content', file_name='content.xhtml', lang='es')
        chapter.content = f'''
        <h1>{title}</h1>
        <div class="info">
            <p><strong>Categoría:</strong> {category}</p>
            <p><strong>Tipo:</strong> {doc_type}</p>
            <p><strong>Número:</strong> {doc_number}</p>
        </div>
        <div class="content">
            {content.replace(chr(10), '<br/>')}
        </div>
        <div class="footer">
            <p><em>Generado por Colombia Legal</em></p>
        </div>
        '''
        
        book.add_item(chapter)
        book.toc = [epub.Link("content.xhtml", title, "content")]
        book.add_item(epub.EpubNcx())
        book.add_item(epub.EpubNav())
        book.spine = ['nav', chapter]
        
        buffer = io.BytesIO()
        epub.write_epub(buffer, book)
        buffer.seek(0)
        
        return send_file(
            buffer,
            as_attachment=True,
            download_name=f'Colombia_Legal_{safe_title}.epub',
            mimetype='application/epub+zip'
        )
        
    except ImportError:
        return jsonify({'error': 'Formato EPUB no disponible.'}), 501

def download_as_csv(doc_id, title, content, category, doc_type, doc_number, safe_title):
    """Generate CSV file with document data"""
    import csv
    
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    
    # Header
    writer.writerow(['Campo', 'Valor'])
    
    # Data
    writer.writerow(['ID', doc_id])
    writer.writerow(['Título', title])
    writer.writerow(['Categoría', category])
    writer.writerow(['Tipo', doc_type])
    writer.writerow(['Número', doc_number])
    writer.writerow(['Contenido', content])
    writer.writerow(['Fecha de exportación', datetime.now().strftime('%d/%m/%Y %H:%M')])
    writer.writerow(['Exportado por', 'Colombia Legal'])
    
    # Convert to bytes
    csv_content = buffer.getvalue()
    bytes_buffer = io.BytesIO()
    bytes_buffer.write(csv_content.encode('utf-8'))
    bytes_buffer.seek(0)
    
    return send_file(
        bytes_buffer,
        as_attachment=True,
        download_name=f'Colombia_Legal_{safe_title}.csv',
        mimetype='text/csv'
    )

@app.route('/smart_search')
def smart_search_endpoint():
    """Endpoint para búsqueda inteligente con información detallada"""
    query = request.args.get('q', '')
    
    if not query:
        return jsonify({'documents': [], 'message': 'Consulta vacía'})
    
    if not smart_search.initialized:
        return jsonify({'documents': [], 'message': 'Sistema de búsqueda no disponible'})
    
    try:
        # Realizar búsqueda inteligente
        results = smart_search.search_documents(query, max_results=1)
        
        # Formatear resultados con información adicional
        documents = []
        for doc in results:
            documents.append({
                'id': doc['id'],
                'title': doc['title'],
                'content': doc['content'][:300] + '...' if len(doc['content']) > 300 else doc['content'],
                'category': doc['category'],
                'document_type': doc['document_type'],
                'document_number': doc['document_number'],
                'relevance_score': round(doc['relevance_score'], 3),
                'score_percentage': doc['score_percentage'],
                'match_quality': 'Excelente' if doc['score_percentage'] > 70 else 
                               'Buena' if doc['score_percentage'] > 40 else 'Regular'
            })
        
        return jsonify({
            'documents': documents,
            'total_found': len(documents),
            'search_type': 'inteligente'
        })
        
    except Exception as e:
        return jsonify({'documents': [], 'message': f'Error en búsqueda: {str(e)}'})

@app.route('/ai_chat', methods=['POST'])
def ai_chat():
    if not smart_search.initialized:
        return jsonify({
            'success': False, 
            'message': 'El sistema de búsqueda inteligente no está disponible en este momento.'
        })
    
    data = request.get_json()
    question = data.get('question', '')
    
    if not question:
        return jsonify({
            'success': False, 
            'message': 'Por favor proporciona una pregunta.'
        })
    
    # Usar el nuevo sistema de respuesta a preguntas
    answer = smart_search.answer_question(question)
    
    return jsonify({
        'success': True,
        'answer': answer
    })

# ========== RUTAS DE ANALYTICS ==========

@app.route('/analytics')
def analytics_dashboard():
    """Dashboard principal de analytics"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Solo permitir acceso a administradores (simplificado)
    # En producción, implementar un sistema de roles más robusto
    user_id = session.get('user_id')
    if user_id != 1:  # Asumiendo que el user_id 1 es admin
        flash('Acceso denegado. Solo administradores pueden ver analytics.', 'error')
        return redirect(url_for('dashboard'))
    
    # Obtener métricas para el dashboard
    metrics = analytics.get_dashboard_metrics(days=30)
    
    return render_template('analytics.html', metrics=metrics)

@app.route('/analytics/metrics')
def get_analytics_metrics():
    """API endpoint para obtener métricas"""
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401
    
    user_id = session.get('user_id')
    if user_id != 1:  # Solo admin
        return jsonify({'error': 'Acceso denegado'}), 403
    
    days = request.args.get('days', 30, type=int)
    metrics = analytics.get_dashboard_metrics(days=days)
    
    return jsonify(metrics)

@app.route('/analytics/generate-report', methods=['POST'])
def generate_analytics_report():
    """Generar reporte automático"""
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401
    
    user_id = session.get('user_id')
    if user_id != 1:  # Solo admin
        return jsonify({'error': 'Acceso denegado'}), 403
    
    try:
        data = request.get_json()
        report_type = data.get('type', 'weekly')
        
        # Generar reporte
        report = analytics.generate_automatic_report(report_type)
        
        # Guardar en archivo
        filename = analytics.save_report_to_file(report)
        
        return jsonify({
            'success': True,
            'filename': filename,
            'report_type': report_type,
            'generated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/analytics/activity-log')
def get_activity_log():
    """Obtener log de actividad reciente"""
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401
    
    user_id = session.get('user_id')
    if user_id != 1:  # Solo admin
        return jsonify({'error': 'Acceso denegado'}), 403
    
    try:
        conn = sqlite3.connect('legislation.db')
        cursor = conn.cursor()
        
        # Obtener actividad reciente
        cursor.execute('''
            SELECT username, action_type, details, timestamp
            FROM user_activity 
            ORDER BY timestamp DESC 
            LIMIT 50
        ''')
        
        activities = []
        for row in cursor.fetchall():
            activities.append({
                'username': row[0],
                'action_type': row[1],
                'details': json.loads(row[2]) if row[2] else {},
                'timestamp': row[3]
            })
        
        conn.close()
        
        return jsonify({'activities': activities})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========== RUTAS DE ANALYTICS AVANZADO ==========

@app.route('/advanced-analytics')
def advanced_analytics_dashboard():
    """Dashboard de analytics avanzado"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session.get('user_id')
    if user_id != 1:  # Solo admin
        flash('Acceso denegado. Solo administradores pueden ver analytics avanzado.', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('advanced_analytics.html')

# ========== RUTAS DE ANALYTICS PREDICTIVO ==========

@app.route('/predictive/forecast', methods=['POST'])
def generate_forecast():
    """Generar forecast predictivo"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        data = request.get_json()
        days = data.get('days', 14)
        
        # Generar forecast completo
        forecast_report = predictive_analytics.generate_forecast_report(days)
        
        return jsonify({
            'status': 'success',
            'forecast': forecast_report
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/predictive/trends')
def get_trends_analysis():
    """Obtener análisis de tendencias"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        trends, error = predictive_analytics.analyze_trends()
        
        if error:
            return jsonify({'error': error}), 500
        
        return jsonify({
            'status': 'success',
            'trends': trends
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/predictive/seasonal')
def get_seasonal_analysis():
    """Obtener análisis estacional"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        seasonal, error = predictive_analytics.seasonal_analysis()
        
        if error:
            return jsonify({'error': error}), 500
        
        return jsonify({
            'status': 'success',
            'seasonal': seasonal
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========== RUTAS DE SISTEMA DE RECOMENDACIONES ==========

@app.route('/recommendations/personalized/<int:user_id>')
def get_personalized_recommendations(user_id):
    """Obtener recomendaciones personalizadas"""
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401
    
    # Los usuarios pueden ver sus propias recomendaciones o admin puede ver cualquiera
    session_user_id = session.get('user_id')
    if session_user_id != user_id and session_user_id != 1:
        return jsonify({'error': 'No autorizado'}), 403
    
    try:
        # Construir perfiles si no existen
        recommendation_system.build_user_profiles()
        recommendation_system.build_content_vectors()
        
        # Obtener recomendaciones
        limit = request.args.get('limit', 10, type=int)
        recommendations = recommendation_system.get_personalized_recommendations(user_id, limit)
        
        return jsonify({
            'status': 'success',
            'user_id': user_id,
            'recommendations': recommendations
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/recommendations/popular')
def get_popular_recommendations():
    """Obtener documentos populares"""
    try:
        limit = request.args.get('limit', 10, type=int)
        popular_docs = recommendation_system.get_popular_documents(limit)
        
        return jsonify({
            'status': 'success',
            'popular_documents': popular_docs
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/recommendations/trending')
def get_trending_topics():
    """Obtener temas en tendencia"""
    try:
        days = request.args.get('days', 7, type=int)
        trending = recommendation_system.get_trending_topics(days)
        
        return jsonify({
            'status': 'success',
            'trending': trending
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/recommendations/suggestions')
def get_search_suggestions():
    """Obtener sugerencias de búsqueda"""
    try:
        partial_query = request.args.get('q', '')
        user_id = session.get('user_id')
        
        if len(partial_query) < 2:
            return jsonify({'suggestions': []})
        
        # Construir perfiles si es necesario
        if user_id:
            recommendation_system.build_user_profiles()
        
        suggestions = recommendation_system.get_search_suggestions(
            partial_query, user_id, num_suggestions=8
        )
        
        return jsonify({
            'status': 'success',
            'suggestions': suggestions
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/recommendations/similar/<int:document_id>')
def get_similar_documents(document_id):
    """Obtener documentos similares"""
    try:
        # Construir vectores si no existen
        recommendation_system.build_content_vectors()
        
        limit = request.args.get('limit', 5, type=int)
        similar_docs = recommendation_system.get_similar_documents(document_id, limit)
        
        return jsonify({
            'status': 'success',
            'document_id': document_id,
            'similar_documents': similar_docs
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========== RUTAS DE INTEGRACIONES EXTERNAS ==========

@app.route('/integrations/generate-api-key', methods=['POST'])
def generate_api_key():
    """Generar nueva API key"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        data = request.get_json()
        client_name = data.get('client_name')
        permissions = data.get('permissions', [])
        
        if not client_name or not permissions:
            return jsonify({'error': 'client_name y permissions son requeridos'}), 400
        
        api_key = external_integrations.generate_api_key(client_name, permissions)
        
        return jsonify({
            'status': 'success',
            'api_key': api_key,
            'client_name': client_name,
            'permissions': permissions
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/integrations/webhook/register', methods=['POST'])
def register_webhook():
    """Registrar webhook"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        data = request.get_json()
        event_type = data.get('event_type')
        endpoint_url = data.get('endpoint_url')
        secret_key = data.get('secret_key')
        
        if not event_type or not endpoint_url:
            return jsonify({'error': 'event_type y endpoint_url son requeridos'}), 400
        
        success = external_integrations.register_webhook(event_type, endpoint_url, secret_key)
        
        return jsonify({
            'status': 'success' if success else 'error',
            'message': 'Webhook registrado exitosamente' if success else 'Error registrando webhook'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/integrations/export/tableau')
def export_tableau_data():
    """Exportar datos para Tableau"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        tableau_data = external_integrations.create_tableau_connector()
        
        return jsonify({
            'status': 'success',
            'data': tableau_data.to_dict('records'),
            'schema': {
                'columns': list(tableau_data.columns),
                'row_count': len(tableau_data)
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/integrations/export/powerbi')
def export_powerbi_data():
    """Exportar datos para Power BI"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        powerbi_data = external_integrations.create_powerbi_dataset()
        
        return jsonify({
            'status': 'success',
            'data': powerbi_data.to_dict('records'),
            'metadata': {
                'total_records': len(powerbi_data),
                'date_range': {
                    'start': powerbi_data['date'].min() if len(powerbi_data) > 0 else None,
                    'end': powerbi_data['date'].max() if len(powerbi_data) > 0 else None
                }
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/integrations/export/analytics')
def export_analytics_data():
    """Exportar datos de analytics"""
    if 'user_id' not in session or session.get('user_id') != 1:
        return jsonify({'error': 'No autorizado'}), 401
    
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        format_type = request.args.get('format', 'json')
        
        if not start_date or not end_date:
            return jsonify({'error': 'start_date y end_date son requeridos'}), 400
        
        export_data = external_integrations.export_analytics_data(
            start_date, end_date, format_type
        )
        
        return jsonify({
            'status': 'success',
            'export_data': export_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Inicializar bases de datos
    init_db()
    
    # Inicializar búsqueda inteligente en un hilo separado para no bloquear la aplicación
    import threading
    threading.Thread(target=smart_search.initialize, daemon=True).start()
    
    app.run(debug=True, host='0.0.0.0', port=5000)