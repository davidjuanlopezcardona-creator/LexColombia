# Colombia Legal 🏛️⚖️

**Plataforma integral de consulta de legislación y jurisprudencia colombiana**

![Colombia Legal](https://img.shields.io/badge/Colombia_Legal-v2.0.0-blue?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.8+-green?style=for-the-badge&logo=python)
![Flask](https://img.shields.io/badge/Flask-3.0+-red?style=for-the-badge&logo=flask)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

## 📋 Descripción

**Colombia Legal** es una aplicación web moderna y profesional que proporciona acceso completo a toda la legislación y jurisprudencia de Colombia. Diseñada con tecnologías web modernas, ofrece una experiencia de usuario excepcional con funcionalidades avanzadas de búsqueda e inteligencia artificial.

### 🎯 Características Principales

- 🔍 **Búsqueda Inteligente**: Motor de búsqueda avanzado con autocompletado
- 🤖 **Asistente de IA**: Inteligencia artificial especializada en legislación colombiana
- 💾 **Base de Datos Completa**: Acceso a toda la normatividad colombiana
- ❤️ **Sistema de Favoritos**: Guarda y organiza tus documentos importantes
- 📱 **100% Responsive**: Funciona perfectamente en todos los dispositivos
- 🌙 **Modo Oscuro/Claro**: Cambia entre temas según tu preferencia
- 📄 **Descarga PDF**: Genera PDFs con marca de agua profesional
- 🔐 **Sistema de Usuarios**: Registro e inicio de sesión seguro
- 🎨 **Diseño Profesional**: Interfaz moderna con colores azul oscuro

## 🚀 Instalación y Configuración

### Prerrequisitos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- 4GB de RAM (recomendado para IA)
- Conexión a internet (para descargar modelos de IA)

### Instalación Paso a Paso

1. **Clonar o descargar el proyecto**
   ```bash
   # Si tienes git instalado
   git clone <url-del-repositorio>
   cd "colombia legal"
   
   # O descargar y extraer el ZIP
   ```

2. **Crear entorno virtual (recomendado)**
   ```bash
   python -m venv venv
   
   # Activar en Windows
   venv\Scripts\activate
   
   # Activar en Linux/Mac
   source venv/bin/activate
   ```

3. **Instalar dependencias**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configurar variables de entorno**
   ```bash
   # Copiar archivo de ejemplo
   cp .env.example .env
   
   # Editar .env con tus configuraciones
   ```

5. **Ejecutar la aplicación**
   ```bash
   python run.py
   ```

6. **Acceder a la aplicación**
   - Abrir navegador en: `http://localhost:5000`
   - ¡Listo para usar! 🎉

## 📖 Guía de Uso

### Primer Uso

1. **Registro**: Crea tu cuenta con usuario, email y contraseña
2. **Inicio de Sesión**: Accede con tus credenciales
3. **Explorar**: Utiliza el buscador o navega por categorías
4. **Favoritos**: Guarda documentos importantes
5. **IA**: Usa el asistente para consultas específicas

### Funcionalidades Principales

#### 🔍 Búsqueda Avanzada
- Búsqueda por palabras clave
- Autocompletado inteligente
- Filtros por categoría y tipo
- Resultados relevantes y ordenados

#### 🤖 Asistente de IA
- Responde preguntas sobre legislación
- Basado en la base de datos local
- Interfaz de chat intuitiva
- Disponible 24/7

#### 💾 Gestión de Documentos
- Visualización completa de documentos
- Sistema de favoritos personalizado
- Descarga en formato PDF
- Impresión directa

#### 👤 Gestión de Usuario
- Registro e inicio de sesión seguro
- Perfil personalizado
- Historial de favoritos
- Configuraciones de usuario

## 🏗️ Arquitectura Técnica

### Stack Tecnológico

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, JavaScript
- **Base de Datos**: SQLite
- **IA**: Transformers (Hugging Face)
- **PDF**: ReportLab
- **Estilos**: CSS personalizado con variables

### Estructura del Proyecto

```
colombia legal/
├── app.py                 # Aplicación principal Flask
├── run.py                 # Script de inicio
├── config.py              # Configuraciones
├── requirements.txt       # Dependencias
├── .env.example          # Variables de entorno
├── templates/            # Templates HTML
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── document.html
│   └── favorites.html
├── static/               # Archivos estáticos
│   ├── css/
│   │   └── style.css     # Estilos principales
│   ├── js/
│   │   └── main.js       # JavaScript principal
│   └── images/           # Imágenes
├── users.db              # Base de datos de usuarios
├── legislation.db        # Base de datos de legislación
└── README.md             # Este archivo
```

### Bases de Datos

#### `users.db`
- **users**: Información de usuarios registrados
- **user_favorites**: Documentos favoritos por usuario

#### `legislation.db`
- **documents**: Toda la legislación y jurisprudencia
  - Títulos, contenido, categorías
  - Metadatos y palabras clave
  - Texto completo indexado

## 🎨 Diseño y UX

### Paleta de Colores
- **Primario**: Azul Oscuro (#1e3a8a)
- **Secundario**: Gris Slate (#64748b)
- **Acentos**: Amarbre (#f59e0b)
- **Estados**: Verde (#10b981), Rojo (#ef4444)

### Características de Diseño
- Diseño responsive y mobile-first
- Interfaz limpia y profesional
- Navegación intuitiva
- Retroalimentación visual clara
- Modo oscuro/claro
- Animaciones suaves

## 🔧 Configuración Avanzada

### Variables de Entorno

```env
# Servidor
FLASK_HOST=0.0.0.0        # IP del servidor
FLASK_PORT=5000           # Puerto
FLASK_DEBUG=True          # Modo debug

# Seguridad
SECRET_KEY=tu_clave_secreta

# IA
AI_MODEL_NAME=modelo_personalizado
```

### Personalización

#### Cambiar Colores
Editar variables CSS en `static/css/style.css`:

```css
:root {
  --primary-color: #tu_color;
  --secondary-color: #tu_color;
}
```

#### Agregar Documentos
Insertar en `legislation.db`:

```python
# Ejemplo de inserción
new_document = {
    'title': 'Título del documento',
    'content': 'Contenido resumido',
    'category': 'Categoría',
    'full_text': 'Texto completo'
}
```

## 📊 Rendimiento

### Optimizaciones
- Carga lazy de imágenes
- Compresión de assets
- Cache de consultas frecuentes
- Indexación de base de datos
- IA local (sin APIs externas)

### Capacidades
- Búsquedas simultáneas: 100+
- Documentos soportados: Ilimitados
- Usuarios concurrentes: 50+
- Tiempo de respuesta: <200ms

## 🔒 Seguridad

### Medidas Implementadas
- Hash de contraseñas (Werkzeug)
- Protección CSRF
- Validación de entrada
- Sanitización de datos
- Sesiones seguras
- Headers de seguridad

### Recomendaciones para Producción
- Usar HTTPS
- Configurar firewall
- Backups regulares
- Monitoreo de logs
- Actualizaciones de seguridad

## 🚀 Despliegue

### Desarrollo Local
```bash
python run.py
```

### Producción con Gunicorn
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Docker (opcional)
```dockerfile
# Dockerfile de ejemplo
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "run.py"]
```

## 🤝 Contribución

### Autores
- **Vicente Soto Liemann**
- **Juan David Cardona Lopez**
- **Sharon Sofia Castellanos Alvares**

### Contacto
- 📞 Teléfono: 3205214751
- 📧 Email: davidjuanlopezcardona@gmail.com

### Cómo Contribuir
1. Fork del proyecto
2. Crear rama de feature
3. Commit de cambios
4. Push a la rama
5. Crear Pull Request

## 📝 Licencia

Este proyecto está bajo la Licencia MIT. Ver `LICENSE` para más detalles.

## 🆘 Soporte

### Problemas Comunes

#### Error de IA
```bash
# Reinstalar dependencias de IA
pip install --upgrade transformers torch
```

#### Base de Datos
```bash
# Recrear bases de datos
rm *.db
python run.py
```

#### Permisos
```bash
# Linux/Mac
chmod +x run.py
```

### Obtener Ayuda
- 📧 Email: davidjuanlopezcardona@gmail.com
- 📞 Teléfono: 3205214751
- 🐛 Issues: Crear issue en el repositorio

## 🎉 Agradecimientos

- Comunidad de Flask por el framework
- Hugging Face por los modelos de IA
- Font Awesome por los iconos
- Google Fonts por las tipografías
- Comunidad open source

---

<div align="center">

**Colombia Legal v2.0.0**

*Hecho con ❤️ para la comunidad legal de Colombia*

[⭐ Deja una estrella si te gusta el proyecto]()

</div>