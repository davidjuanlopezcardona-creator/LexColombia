#!/usr/bin/env python3
"""
🎉 DEMOSTRACIÓN INTERACTIVA - BÚSQUEDA INTELIGENTE LEXCOLOMBIA
Sistema de respuesta a preguntas legales implementado exitosamente
"""

import sys
sys.path.append('/workspace/extracted_documents')
from app import SmartSearch

def demo_interactive():
    """Demostración interactiva del nuevo sistema"""
    
    print("🏛️  LEXCOLOMBIA - BÚSQUEDA INTELIGENTE")
    print("=" * 50)
    print("✨ Sistema de respuesta a preguntas legales")
    print("📚 Base de datos: 1000+ documentos oficiales colombianos")
    print()
    
    # Inicializar sistema
    print("🔄 Inicializando sistema inteligente...")
    search_system = SmartSearch()
    
    if not search_system.initialize():
        print("❌ Error: No se pudo inicializar el sistema")
        return
    
    print(f"✅ Sistema listo con {len(search_system.documents)} documentos")
    print()
    
    # Demostración de capacidades
    print("🎯 DEMOSTRACIONES DE CAPACIDADES")
    print("-" * 40)
    
    # 1. Búsqueda simple
    print("\n1️⃣  BÚSQUEDA SEMÁNTICA")
    demo_searches = [
        "constitución política colombia",
        "código penal procedimiento",
        "derechos civiles fundamentales"
    ]
    
    for query in demo_searches:
        print(f"\n🔍 Búsqueda: '{query}'")
        results = search_system.search_documents(query, max_results=2)
        
        if results:
            for i, doc in enumerate(results, 1):
                score = doc['score_percentage']
                relevance = "🟢 Alta" if score > 50 else "🟡 Media" if score > 25 else "🔴 Baja"
                print(f"   {i}. {doc['title']}")
                print(f"      📊 Score: {score}% - {relevance}")
        else:
            print("   📭 No se encontraron resultados relevantes")
    
    # 2. Respuesta a preguntas
    print("\n\n2️⃣  RESPUESTA A PREGUNTAS")
    demo_questions = [
        "¿Qué es la constitución colombiana?",
        "¿Cómo funciona el sistema legal?",
        "¿Cuáles son los derechos fundamentales?"
    ]
    
    for question in demo_questions:
        print(f"\n❓ Pregunta: {question}")
        answer = search_system.answer_question(question)
        
        # Mostrar respuesta resumida
        lines = answer.split('\n')
        intro = lines[0] if lines else ""
        first_doc = next((line for line in lines if line.startswith('1.')), "")
        
        print(f"   💬 {intro}")
        if first_doc:
            print(f"   📄 {first_doc[:80]}...")
    
    # 3. Estadísticas del sistema
    print("\n\n3️⃣  ESTADÍSTICAS DEL SISTEMA")
    print("-" * 30)
    print(f"📊 Documentos procesados: {len(search_system.documents)}")
    print(f"🔤 Características TF-IDF: {search_system.tfidf_matrix.shape[1]}")
    print(f"🎯 Tipos de documento únicos: {len(set(doc['document_type'] for doc in search_system.documents))}")
    
    # Mostrar tipos de documentos más comunes
    doc_types = {}
    for doc in search_system.documents:
        dt = doc['document_type']
        doc_types[dt] = doc_types.get(dt, 0) + 1
    
    print("\n📋 Tipos de documentos más comunes:")
    for doc_type, count in sorted(doc_types.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"   • {doc_type}: {count} documentos")
    
    print("\n" + "=" * 50)
    print("🎉 IMPLEMENTACIÓN EXITOSA")
    print("✅ Búsqueda inteligente funcionando")
    print("✅ Respuesta a preguntas en español")
    print("✅ Sistema optimizado y eficiente")
    print("✅ Base de datos actualizada con 1000+ documentos")
    print()
    print("🚀 La aplicación está lista para responder preguntas legales!")

if __name__ == "__main__":
    demo_interactive()