#!/usr/bin/env python3
"""
Script de prueba para las funcionalidades avanzadas de LexColombia
Prueba Analytics Predictivo, Sistema de Recomendaciones e Integraciones Externas
"""

import os
import sys
import json
import time
from datetime import datetime

# Agregar el directorio del proyecto al path
sys.path.append(os.path.dirname(__file__))

def test_predictive_analytics():
    """Probar sistema de analytics predictivo"""
    print("🔮 === PRUEBAS DE ANALYTICS PREDICTIVO ===\n")
    
    try:
        from predictive_analytics import PredictiveAnalytics
        
        # Inicializar sistema
        predictor = PredictiveAnalytics('legislation.db')
        print("✅ Sistema predictivo inicializado")
        
        # Probar obtención de datos históricos
        print("📊 Obteniendo datos históricos...")
        historical_data = predictor.get_historical_data(days=30)
        print(f"   - Registros históricos: {len(historical_data)}")
        
        if len(historical_data) > 0:
            print(f"   - Columnas: {list(historical_data.columns)}")
            print(f"   - Período: {historical_data['date'].min()} a {historical_data['date'].max()}")
        
        # Probar análisis de tendencias
        print("\n📈 Analizando tendencias...")
        trends, error = predictor.analyze_trends()
        
        if not error and trends:
            print("   ✅ Análisis de tendencias completado")
            for metric, trend_data in trends.items():
                direction = trend_data['direction']
                growth = trend_data['growth_rate']
                print(f"   - {metric}: {direction} ({growth:+.1f}%)")
        else:
            print(f"   ⚠️ Error en tendencias: {error}")
        
        # Probar análisis estacional
        print("\n📅 Analizando patrones estacionales...")
        seasonal, error = predictor.seasonal_analysis()
        
        if not error and seasonal:
            print("   ✅ Análisis estacional completado")
            if 'peak_day' in seasonal:
                print(f"   - Día pico: {seasonal['peak_day']}")
            if 'daily_patterns' in seasonal and seasonal['daily_patterns']:
                print(f"   - Patrones diarios disponibles")
        else:
            print(f"   ⚠️ Error en estacional: {error}")
        
        # Probar predicción
        print("\n🔮 Generando predicciones...")
        predictions, error = predictor.predict_next_days('daily_searches', 7)
        
        if not error and predictions:
            print("   ✅ Predicciones generadas")
            print(f"   - Próximos 7 días predichos")
            for pred in predictions[:3]:
                print(f"   - {pred['date']}: {pred['predicted_value']:.1f} búsquedas")
        else:
            print(f"   ⚠️ Error en predicciones: {error}")
        
        # Probar reporte completo
        print("\n📄 Generando reporte de forecast...")
        forecast_report = predictor.generate_forecast_report(14)
        
        if forecast_report:
            print("   ✅ Reporte de forecast generado")
            print(f"   - Período: {forecast_report['forecast_period']}")
            print(f"   - Métricas incluidas: {len(forecast_report['predictions'])}")
            
            # Guardar reporte
            filepath = predictor.save_forecast_report(forecast_report)
            print(f"   - Guardado en: {filepath}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error en analytics predictivo: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_recommendation_system():
    """Probar sistema de recomendaciones"""
    print("\n🎯 === PRUEBAS DE SISTEMA DE RECOMENDACIONES ===\n")
    
    try:
        from recommendation_system import RecommendationSystem
        
        # Inicializar sistema
        recommender = RecommendationSystem('legislation.db')
        print("✅ Sistema de recomendaciones inicializado")
        
        # Cargar documentos
        print("📚 Cargando documentos...")
        documents_df = recommender.load_documents()
        print(f"   - Documentos cargados: {len(documents_df)}")
        
        # Construir vectores de contenido
        print("🔧 Construyendo vectores de contenido...")
        success = recommender.build_content_vectors()
        
        if success:
            print("   ✅ Vectores TF-IDF construidos")
            print(f"   - Dimensiones de matriz: {recommender.document_vectors.shape}")
        
        # Construir perfiles de usuario
        print("👥 Construyendo perfiles de usuario...")
        user_count = recommender.build_user_profiles()
        print(f"   - Perfiles creados: {user_count}")
        
        # Probar documentos populares
        print("\n🔥 Obteniendo documentos populares...")
        popular_docs = recommender.get_popular_documents(5)
        
        if popular_docs:
            print("   ✅ Documentos populares obtenidos")
            for i, doc in enumerate(popular_docs[:3]):
                print(f"   {i+1}. {doc['title'][:50]}... ({doc['view_count']} vistas)")
        
        # Probar similitud de documentos
        if len(documents_df) > 0:
            test_doc_id = documents_df.iloc[0]['id']
            print(f"\n🔍 Buscando documentos similares a ID {test_doc_id}...")
            
            similar_docs = recommender.get_similar_documents(test_doc_id, 3)
            
            if similar_docs:
                print("   ✅ Documentos similares encontrados")
                for i, doc in enumerate(similar_docs):
                    score = doc['similarity_score']
                    print(f"   {i+1}. {doc['title'][:50]}... (similitud: {score:.3f})")
        
        # Probar recomendaciones personalizadas
        if user_count > 0:
            test_user_id = list(recommender.user_profiles.keys())[0]
            print(f"\n💡 Generando recomendaciones para usuario {test_user_id}...")
            
            recommendations = recommender.get_personalized_recommendations(test_user_id, 5)
            
            if recommendations:
                print("   ✅ Recomendaciones personalizadas generadas")
                for i, rec in enumerate(recommendations[:3]):
                    confidence = rec.get('confidence', 0)
                    reason = rec.get('reason', 'N/A')
                    print(f"   {i+1}. {rec['title'][:50]}... ({confidence:.2f} - {reason})")
        
        # Probar sugerencias de búsqueda
        print("\n🔍 Probando sugerencias de búsqueda...")
        suggestions = recommender.get_search_suggestions('constitución', None, 5)
        
        if suggestions:
            print("   ✅ Sugerencias generadas")
            for i, sugg in enumerate(suggestions[:3]):
                print(f"   {i+1}. {sugg['query']} ({sugg['type']})")
        
        # Probar temas en tendencia
        print("\n📈 Obteniendo temas en tendencia...")
        trending = recommender.get_trending_topics(7)
        
        if trending and 'search_terms' in trending:
            print("   ✅ Temas en tendencia obtenidos")
            print(f"   - Términos populares: {len(trending['search_terms'])}")
            print(f"   - Categorías populares: {len(trending['categories'])}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error en sistema de recomendaciones: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_external_integrations():
    """Probar integraciones externas"""
    print("\n🔌 === PRUEBAS DE INTEGRACIONES EXTERNAS ===\n")
    
    try:
        from external_integrations import ExternalIntegrations
        
        # Inicializar sistema
        integrations = ExternalIntegrations('legislation.db')
        print("✅ Sistema de integraciones inicializado")
        
        # Probar generación de API key
        print("🔑 Generando API key de prueba...")
        api_key = integrations.generate_api_key(
            'Test Client', 
            ['analytics_read', 'documents_read']
        )
        print(f"   - API Key generada: {api_key[:16]}...")
        
        # Probar validación de API key
        print("🔐 Validando API key...")
        is_valid = integrations.validate_api_key(api_key, 'analytics_read')
        print(f"   - Validación: {'✅ Válida' if is_valid else '❌ Inválida'}")
        
        # Probar registro de webhook
        print("🔗 Registrando webhook de prueba...")
        webhook_success = integrations.register_webhook(
            'search_performed',
            'https://example.com/webhook',
            'test_secret'
        )
        print(f"   - Webhook: {'✅ Registrado' if webhook_success else '❌ Error'}")
        
        # Probar exportación de datos
        print("📤 Probando exportación de datos...")
        from datetime import date, timedelta
        
        end_date = date.today()
        start_date = end_date - timedelta(days=7)
        
        export_data = integrations.export_analytics_data(
            start_date.isoformat(),
            end_date.isoformat(),
            'json'
        )
        
        if export_data and 'metadata' in export_data:
            print("   ✅ Datos exportados exitosamente")
            metadata = export_data['metadata']
            print(f"   - Búsquedas: {metadata['total_records']['searches']}")
            print(f"   - Interacciones: {metadata['total_records']['document_interactions']}")
            print(f"   - Actividades: {metadata['total_records']['user_activities']}")
        
        # Probar conectores BI
        print("\n📊 Probando conectores de BI...")
        
        # Conector Tableau
        tableau_data = integrations.create_tableau_connector()
        print(f"   - Tableau: {len(tableau_data)} registros preparados")
        
        # Conector Power BI
        powerbi_data = integrations.create_powerbi_dataset()
        print(f"   - Power BI: {len(powerbi_data)} registros agregados")
        
        # Mapping Elasticsearch
        es_mapping = integrations.create_elasticsearch_mapping()
        print(f"   - Elasticsearch: Mapping preparado con {len(es_mapping['mappings']['properties'])} campos")
        
        return True
        
    except Exception as e:
        print(f"❌ Error en integraciones externas: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_api_endpoints():
    """Probar endpoints de API (simulado)"""
    print("\n🌐 === PRUEBAS DE ENDPOINTS DE API (Simulado) ===\n")
    
    # Simular pruebas de endpoints sin servidor real
    endpoints_to_test = [
        '/api/v1/analytics/summary',
        '/api/v1/documents/popular',
        '/api/v1/recommendations/1',
        '/api/v1/export/analytics',
        '/api/v1/tableau/connector',
        '/api/v1/powerbi/dataset'
    ]
    
    print("📡 Endpoints de API disponibles:")
    for endpoint in endpoints_to_test:
        print(f"   ✅ {endpoint}")
    
    print("\n🔧 Para probar los endpoints reales:")
    print("   1. Ejecuta: python app.py")
    print("   2. Obtén una API key desde /advanced-analytics")
    print("   3. Usa curl o Postman con el header X-API-Key")
    
    return True

def performance_test():
    """Pruebas de rendimiento"""
    print("\n⚡ === PRUEBAS DE RENDIMIENTO ===\n")
    
    try:
        # Medir tiempo de inicialización
        start_time = time.time()
        
        from predictive_analytics import PredictiveAnalytics
        from recommendation_system import RecommendationSystem
        from external_integrations import ExternalIntegrations
        
        predictor = PredictiveAnalytics('legislation.db')
        recommender = RecommendationSystem('legislation.db')
        integrations = ExternalIntegrations('legislation.db')
        
        init_time = time.time() - start_time
        print(f"🚀 Inicialización de sistemas: {init_time:.3f} segundos")
        
        # Medir tiempo de construcción de vectores
        start_time = time.time()
        recommender.build_content_vectors()
        vector_time = time.time() - start_time
        print(f"🔧 Construcción de vectores TF-IDF: {vector_time:.3f} segundos")
        
        # Medir tiempo de perfiles de usuario
        start_time = time.time()
        user_count = recommender.build_user_profiles()
        profile_time = time.time() - start_time
        print(f"👥 Construcción de perfiles de usuario: {profile_time:.3f} segundos ({user_count} usuarios)")
        
        # Medir tiempo de predicciones
        if user_count > 0:
            start_time = time.time()
            predictor.analyze_trends()
            trend_time = time.time() - start_time
            print(f"📈 Análisis de tendencias: {trend_time:.3f} segundos")
        
        print(f"\n📊 Resumen de rendimiento:")
        print(f"   - Tiempo total: {init_time + vector_time + profile_time:.3f}s")
        print(f"   - Memoria de vectores: ~{recommender.document_vectors.nbytes / 1024 / 1024:.1f} MB")
        
        return True
        
    except Exception as e:
        print(f"❌ Error en pruebas de rendimiento: {e}")
        return False

def main():
    """Función principal de pruebas"""
    print("🚀 INICIANDO PRUEBAS DE FUNCIONALIDADES AVANZADAS DE LEXCOLOMBIA")
    print("=" * 70)
    
    # Cambiar al directorio correcto
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    results = {}
    
    try:
        # Ejecutar todas las pruebas
        print(f"📅 Fecha de pruebas: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"🗂️ Directorio de trabajo: {os.getcwd()}")
        
        results['predictive_analytics'] = test_predictive_analytics()
        results['recommendation_system'] = test_recommendation_system()
        results['external_integrations'] = test_external_integrations()
        results['api_endpoints'] = test_api_endpoints()
        results['performance'] = performance_test()
        
        # Resumen final
        print("\n🎉 === RESUMEN DE RESULTADOS ===")
        
        passed = sum(results.values())
        total = len(results)
        
        for test_name, result in results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            print(f"   {test_name}: {status}")
        
        print(f"\n📊 Resultado general: {passed}/{total} pruebas exitosas")
        
        if passed == total:
            print("🎉 ¡TODAS LAS FUNCIONALIDADES AVANZADAS ESTÁN OPERATIVAS!")
        else:
            print("⚠️ Algunas funcionalidades requieren atención")
        
        print("\n🌐 Para usar las funcionalidades:")
        print("   1. Ejecuta: python app.py")
        print("   2. Ve a: http://localhost:5000/advanced-analytics")
        print("   3. Inicia sesión como admin (user_id = 1)")
        
        print("\n📚 Funcionalidades disponibles:")
        print("   🔮 Analytics Predictivo - Forecasting y tendencias")
        print("   🎯 Sistema de Recomendaciones - Personalización AI")
        print("   🔌 Integraciones Externas - APIs y conectores BI")
        print("   📊 Exportación de datos - Tableau, Power BI, CSV")
        print("   🔗 Webhooks - Notificaciones en tiempo real")
        
    except Exception as e:
        print(f"\n❌ ERROR CRÍTICO EN LAS PRUEBAS: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()