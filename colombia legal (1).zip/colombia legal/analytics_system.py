"""
Sistema de Analytics para Colombia Legal
Maneja el tracking de actividad, métricas y reportes automáticos
"""

import sqlite3
import json
from datetime import datetime, timedelta
from collections import defaultdict
import os

class AnalyticsSystem:
    def __init__(self, db_path='legislation.db'):
        self.db_path = db_path
        self.initialize_analytics_tables()
    
    def initialize_analytics_tables(self):
        """Crea las tablas necesarias para analytics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Tabla de actividad de usuarios
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_activity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                action_type TEXT,  -- 'search', 'view_document', 'login', 'register', 'add_favorite', 'remove_favorite'
                details TEXT,      -- JSON con detalles específicos
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                user_agent TEXT
            )
        ''')
        
        # Tabla de métricas de búsqueda
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS search_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                search_query TEXT,
                category_filter TEXT,
                results_count INTEGER,
                search_duration_ms INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Tabla de métricas de documentos
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS document_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id INTEGER,
                user_id INTEGER,
                action TEXT,       -- 'view', 'favorite', 'download', 'share'
                time_spent_seconds INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Tabla de estadísticas diarias agregadas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE UNIQUE,
                total_searches INTEGER DEFAULT 0,
                unique_users INTEGER DEFAULT 0,
                total_document_views INTEGER DEFAULT 0,
                total_new_users INTEGER DEFAULT 0,
                most_searched_term TEXT,
                most_viewed_document_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def log_user_activity(self, user_id, username, action_type, details=None, ip_address=None, user_agent=None):
        """Registra actividad del usuario"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        details_json = json.dumps(details) if details else None
        
        cursor.execute('''
            INSERT INTO user_activity 
            (user_id, username, action_type, details, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, username, action_type, details_json, ip_address, user_agent))
        
        conn.commit()
        conn.close()
    
    def log_search(self, user_id, search_query, category_filter, results_count, search_duration_ms):
        """Registra una búsqueda"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO search_metrics 
            (user_id, search_query, category_filter, results_count, search_duration_ms)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, search_query, category_filter, results_count, search_duration_ms))
        
        conn.commit()
        conn.close()
    
    def log_document_view(self, document_id, user_id, action='view', time_spent_seconds=0):
        """Registra visualización de documento"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO document_metrics 
            (document_id, user_id, action, time_spent_seconds)
            VALUES (?, ?, ?, ?)
        ''', (document_id, user_id, action, time_spent_seconds))
        
        conn.commit()
        conn.close()
    
    def get_dashboard_metrics(self, days=30):
        """Obtiene métricas para el dashboard"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Fecha de inicio
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        metrics = {}
        
        # Métricas básicas del período
        cursor.execute('''
            SELECT COUNT(*) FROM user_activity 
            WHERE timestamp >= ?
        ''', (start_date,))
        metrics['total_activities'] = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT COUNT(DISTINCT user_id) FROM user_activity 
            WHERE timestamp >= ? AND user_id IS NOT NULL
        ''', (start_date,))
        metrics['unique_users'] = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT COUNT(*) FROM search_metrics 
            WHERE timestamp >= ?
        ''', (start_date,))
        metrics['total_searches'] = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT COUNT(*) FROM document_metrics 
            WHERE timestamp >= ? AND action = 'view'
        ''', (start_date,))
        metrics['total_document_views'] = cursor.fetchone()[0]
        
        # Top 10 búsquedas
        cursor.execute('''
            SELECT search_query, COUNT(*) as count
            FROM search_metrics 
            WHERE timestamp >= ? AND search_query IS NOT NULL AND search_query != ''
            GROUP BY search_query 
            ORDER BY count DESC 
            LIMIT 10
        ''', (start_date,))
        metrics['top_searches'] = cursor.fetchall()
        
        # Top 10 documentos más vistos
        cursor.execute('''
            SELECT dm.document_id, d.title, d.category, COUNT(*) as views
            FROM document_metrics dm
            LEFT JOIN documents d ON dm.document_id = d.id
            WHERE dm.timestamp >= ? AND dm.action = 'view'
            GROUP BY dm.document_id 
            ORDER BY views DESC 
            LIMIT 10
        ''', (start_date,))
        metrics['top_documents'] = cursor.fetchall()
        
        # Actividad por día (últimos 7 días)
        cursor.execute('''
            SELECT DATE(timestamp) as date, COUNT(*) as activities
            FROM user_activity 
            WHERE timestamp >= ?
            GROUP BY DATE(timestamp) 
            ORDER BY date DESC 
            LIMIT 7
        ''', (start_date,))
        metrics['daily_activity'] = cursor.fetchall()
        
        # Distribución por categorías más buscadas
        cursor.execute('''
            SELECT category_filter, COUNT(*) as searches
            FROM search_metrics 
            WHERE timestamp >= ? AND category_filter IS NOT NULL AND category_filter != ''
            GROUP BY category_filter 
            ORDER BY searches DESC 
            LIMIT 10
        ''', (start_date,))
        metrics['categories_distribution'] = cursor.fetchall()
        
        # Estadísticas de tiempo de respuesta de búsquedas
        cursor.execute('''
            SELECT AVG(search_duration_ms) as avg_duration, 
                   MIN(search_duration_ms) as min_duration,
                   MAX(search_duration_ms) as max_duration
            FROM search_metrics 
            WHERE timestamp >= ? AND search_duration_ms > 0
        ''', (start_date,))
        duration_stats = cursor.fetchone()
        metrics['search_performance'] = {
            'avg_duration_ms': duration_stats[0] or 0,
            'min_duration_ms': duration_stats[1] or 0,
            'max_duration_ms': duration_stats[2] or 0
        }
        
        conn.close()
        return metrics
    
    def generate_automatic_report(self, report_type='daily'):
        """Genera reportes automáticos"""
        if report_type == 'daily':
            return self._generate_daily_report()
        elif report_type == 'weekly':
            return self._generate_weekly_report()
        elif report_type == 'monthly':
            return self._generate_monthly_report()
    
    def _generate_daily_report(self):
        """Genera reporte diario"""
        today = datetime.now().strftime('%Y-%m-%d')
        yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Estadísticas del día anterior
        cursor.execute('''
            SELECT COUNT(*) FROM user_activity 
            WHERE DATE(timestamp) = ?
        ''', (yesterday,))
        daily_activities = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT COUNT(DISTINCT user_id) FROM user_activity 
            WHERE DATE(timestamp) = ? AND user_id IS NOT NULL
        ''', (yesterday,))
        daily_unique_users = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT COUNT(*) FROM search_metrics 
            WHERE DATE(timestamp) = ?
        ''', (yesterday,))
        daily_searches = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT search_query, COUNT(*) as count
            FROM search_metrics 
            WHERE DATE(timestamp) = ? AND search_query IS NOT NULL
            GROUP BY search_query 
            ORDER BY count DESC 
            LIMIT 5
        ''', (yesterday,))
        top_searches = cursor.fetchall()
        
        # Guardar estadísticas diarias
        cursor.execute('''
            INSERT OR REPLACE INTO daily_stats 
            (date, total_searches, unique_users, total_document_views, most_searched_term)
            VALUES (?, ?, ?, ?, ?)
        ''', (yesterday, daily_searches, daily_unique_users, 0, 
              top_searches[0][0] if top_searches else None))
        
        conn.commit()
        conn.close()
        
        # Crear reporte
        report = {
            'date': yesterday,
            'type': 'daily',
            'metrics': {
                'total_activities': daily_activities,
                'unique_users': daily_unique_users,
                'total_searches': daily_searches,
                'top_searches': top_searches
            },
            'generated_at': datetime.now().isoformat()
        }
        
        return report
    
    def _generate_weekly_report(self):
        """Genera reporte semanal"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)
        
        metrics = self.get_dashboard_metrics(days=7)
        
        report = {
            'period': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
            'type': 'weekly',
            'metrics': metrics,
            'generated_at': datetime.now().isoformat()
        }
        
        return report
    
    def _generate_monthly_report(self):
        """Genera reporte mensual"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        metrics = self.get_dashboard_metrics(days=30)
        
        report = {
            'period': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
            'type': 'monthly',
            'metrics': metrics,
            'generated_at': datetime.now().isoformat()
        }
        
        return report
    
    def save_report_to_file(self, report, filename=None):
        """Guarda reporte en archivo JSON"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"report_{report['type']}_{timestamp}.json"
        
        reports_dir = 'reports'
        if not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
        
        filepath = os.path.join(reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        return filepath

# Instancia global del sistema de analytics
analytics = AnalyticsSystem()