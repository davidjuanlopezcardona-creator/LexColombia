# 📊 Sistema de Analytics y Reportes Automáticos - LexColombia

## 🎯 Descripción General

Este sistema proporciona análisis avanzado y reportes automáticos para LexColombia, permitiendo monitorear el uso de la plataforma, generar métricas en tiempo real y crear reportes automáticos detallados.

## 🚀 Características Implementadas

### 1. 📈 Dashboard Básico de Métricas

**Ubicación:** `/analytics`

**Características:**
- **Métricas en tiempo real:** Usuarios únicos, búsquedas totales, documentos vistos
- **Gráficos interactivos:** Actividad diaria, distribución por categorías
- **Top rankings:** Términos más buscados, documentos más vistos
- **Estadísticas de rendimiento:** Tiempos de respuesta de búsquedas
- **Filtros temporales:** 7, 30, 90 días
- **Actualización en tiempo real:** Botón de refresh automático

### 2. 📄 Reportes Automáticos

**Tipos de reportes:**
- **Diario:** Estadísticas del día anterior
- **Semanal:** Resumen de los últimos 7 días
- **Mensual:** Análisis completo de 30 días

**Formatos de salida:**
- **JSON:** Datos estructurados para análisis
- **HTML:** Resúmenes visuales listos para compartir

### 3. 🔍 Sistema de Tracking

**Actividades monitoreadas:**
- Búsquedas de usuarios (término, duración, resultados)
- Visualizaciones de documentos
- Agregado/eliminación de favoritos
- Logins y registros
- Navegación general

**Datos capturados:**
- Timestamp preciso
- ID de usuario y username
- Dirección IP y User Agent
- Detalles específicos de cada acción
- Métricas de rendimiento

## 📁 Archivos del Sistema

### Archivos Principales

| Archivo | Descripción |
|---------|-------------|
| `analytics_system.py` | Sistema core de analytics y tracking |
| `templates/analytics.html` | Dashboard web con gráficos interactivos |
| `automated_reports.py` | Generador de reportes automáticos |
| `test_analytics.py` | Suite de pruebas completa |
| `setup_cron.sh` | Configuración de tareas programadas |

### Directorios Generados

| Directorio | Contenido |
|------------|-----------|
| `reports/` | Reportes JSON y HTML generados |
| `logs/` | Logs del sistema y cron jobs |

## 🛠️ Instalación y Configuración

### 1. Verificar Instalación

```bash
# Ejecutar pruebas del sistema
python test_analytics.py
```

### 2. Configurar Reportes Automáticos

```bash
# Configurar tareas programadas (cron)
./setup_cron.sh

# O ejecutar reportes manualmente
python automated_reports.py --type daily
python automated_reports.py --type weekly
python automated_reports.py --type monthly
python automated_reports.py --type all
```

### 3. Acceder al Dashboard

1. Iniciar la aplicación: `python app.py`
2. Acceder a: `http://localhost:5000/analytics`
3. **Nota:** Solo usuarios administradores (ID=1) pueden acceder

## 📊 Métricas Disponibles

### Métricas Principales
- **Usuarios Únicos:** Conteo de usuarios distintos por período
- **Búsquedas Totales:** Número total de búsquedas realizadas
- **Documentos Vistos:** Total de visualizaciones de documentos
- **Actividades Totales:** Suma de todas las acciones registradas

### Análisis Detallados
- **Top 10 Búsquedas:** Términos más consultados
- **Top 10 Documentos:** Contenido más popular
- **Distribución por Categorías:** Popularidad de cada categoría legal
- **Actividad Diaria:** Tendencias de uso por día
- **Rendimiento:** Tiempos de respuesta y velocidad del sistema

### Métricas de Rendimiento
- **Tiempo Promedio de Búsqueda:** Duración media de procesamiento
- **Búsqueda Más Rápida/Lenta:** Extremos de rendimiento
- **Velocidad de Inserción:** Logs por segundo

## 🤖 Reportes Automáticos

### Programación por Defecto
- **Diario:** 23:30 todos los días
- **Semanal:** 23:45 los domingos
- **Mensual:** 23:55 el primer día del mes
- **Limpieza:** 02:00 los viernes (archivos > 30 días)

### Personalización
```bash
# Generar reporte personalizado
python automated_reports.py --type daily --db-path custom.db

# Ejecutar limpieza manual
python automated_reports.py --cleanup
```

## 🔧 API Endpoints

### Endpoints Disponibles

| Endpoint | Método | Descripción |
|----------|---------|-------------|
| `/analytics` | GET | Dashboard principal |
| `/analytics/metrics` | GET | API de métricas (parámetro: `days`) |
| `/analytics/generate-report` | POST | Generar reporte manual |
| `/analytics/activity-log` | GET | Log de actividad reciente |

### Ejemplo de Uso
```javascript
// Obtener métricas de los últimos 7 días
fetch('/analytics/metrics?days=7')
  .then(response => response.json())
  .then(data => console.log(data));

// Generar reporte semanal
fetch('/analytics/generate-report', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({type: 'weekly'})
});
```

## 📈 Base de Datos

### Tablas de Analytics

| Tabla | Propósito |
|-------|-----------|
| `user_activity` | Registro general de actividad |
| `search_metrics` | Métricas específicas de búsqueda |
| `document_metrics` | Interacciones con documentos |
| `daily_stats` | Estadísticas agregadas diarias |

### Esquema de Datos

```sql
-- Actividad de usuarios
CREATE TABLE user_activity (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    username TEXT,
    action_type TEXT,
    details TEXT,
    timestamp DATETIME,
    ip_address TEXT,
    user_agent TEXT
);

-- Métricas de búsqueda
CREATE TABLE search_metrics (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    search_query TEXT,
    category_filter TEXT,
    results_count INTEGER,
    search_duration_ms INTEGER,
    timestamp DATETIME
);
```

## 🔒 Seguridad y Acceso

### Control de Acceso
- **Solo administradores** pueden acceder al dashboard
- **Verificación de sesión** en todas las rutas
- **Validación de permisos** en endpoints de API

### Datos Sensibles
- **IPs hasheadas** en logs de producción
- **Anonymización** de datos personales en reportes
- **Limpieza automática** de logs antiguos

## 🧪 Testing y Verificación

### Suite de Pruebas
```bash
# Ejecutar todas las pruebas
python test_analytics.py

# Verificar estructura de BD
python -c "from analytics_system import AnalyticsSystem; AnalyticsSystem('legislation.db')"
```

### Pruebas Incluidas
- ✅ Inicialización de tablas
- ✅ Inserción de datos de prueba
- ✅ Generación de métricas
- ✅ Creación de reportes
- ✅ Pruebas de rendimiento
- ✅ Verificación de estructura de BD

## 🚀 Uso en Producción

### Consideraciones
1. **Configurar cron jobs** para reportes automáticos
2. **Monitorear logs** en `logs/` regularmente
3. **Revisar reportes** en `reports/` periódicamente
4. **Limpiar archivos antiguos** automáticamente

### Optimización
- **Índices de BD** para consultas rápidas
- **Compresión de reportes** antiguos
- **Archivado de logs** históricos
- **Cache de métricas** frecuentes

## 📞 Soporte y Mantenimiento

### Logs del Sistema
- `logs/automated_reports.log` - Logs de generación de reportes
- `logs/cron_daily.log` - Ejecución de tareas diarias
- `logs/cron_weekly.log` - Ejecución de tareas semanales
- `logs/cron_monthly.log` - Ejecución de tareas mensuales

### Solución de Problemas
1. **Verificar permisos** de archivos y directorios
2. **Comprobar conexión** a base de datos
3. **Revisar logs** para errores específicos
4. **Ejecutar pruebas** para validar funcionamiento

## 🎯 Beneficios Implementados

### Para Administradores
- 📊 **Visibilidad completa** del uso de la plataforma
- 📈 **Métricas en tiempo real** para toma de decisiones
- 📄 **Reportes automáticos** sin intervención manual
- 🔍 **Identificación de patrones** de uso

### Para el Sistema
- ⚡ **Optimización basada en datos** reales de uso
- 🎯 **Identificación de contenido popular** para priorizar
- 🐛 **Detección temprana** de problemas de rendimiento
- 📚 **Base para futuras mejoras** de UX

---

## 🎉 ¡Sistema Completamente Implementado!

El sistema de analytics está listo para uso inmediato con:
- ✅ Dashboard funcional con gráficos interactivos
- ✅ Reportes automáticos programables
- ✅ Tracking completo de actividad de usuarios
- ✅ API para integración con otras herramientas
- ✅ Sistema de limpieza automática
- ✅ Suite completa de pruebas

**Para empezar:** Ejecuta `python test_analytics.py` y luego accede a `/analytics` en tu aplicación web.