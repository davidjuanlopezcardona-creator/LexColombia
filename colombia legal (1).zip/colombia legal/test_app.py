#!/usr/bin/env python3
"""
Aplicación Flask simple para probar la búsqueda en SUIN-Juriscol
"""

from flask import Flask, request, jsonify
import sqlite3
import os

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('legislation.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    return '''
    <html>
    <head>
        <title>LexColombia - SUIN-Juriscol</title>
        <meta charset="utf-8">
    </head>
    <body>
        <h1>LexColombia - Base de Datos SUIN-Juriscol</h1>
        <form id="searchForm">
            <input type="text" id="searchInput" placeholder="Buscar normas..." size="50">
            <button type="submit">Buscar</button>
        </form>
        <div id="results"></div>
        
        <script>
        document.getElementById('searchForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const query = document.getElementById('searchInput').value;
            if (query.trim()) {
                fetch('/search?q=' + encodeURIComponent(query))
                .then(response => response.json())
                .then(data => {
                    const resultsDiv = document.getElementById('results');
                    if (data.documents && data.documents.length > 0) {
                        let html = '<h3>Resultados (' + data.documents.length + '):</h3>';
                        data.documents.forEach((doc, index) => {
                            html += '<div style="border: 1px solid #ccc; margin: 10px; padding: 10px;">';
                            html += '<h4>' + (index + 1) + '. ' + doc.title + '</h4>';
                            html += '<p><strong>Tipo:</strong> ' + doc.document_type + '</p>';
                            html += '<p><strong>Categoría:</strong> ' + doc.category + '</p>';
                            html += '<p><strong>Fecha:</strong> ' + (doc.date_published || 'No especificada') + '</p>';
                            html += '<p><strong>Contenido:</strong> ' + doc.content.substring(0, 200) + '...</p>';
                            html += '</div>';
                        });
                        resultsDiv.innerHTML = html;
                    } else {
                        resultsDiv.innerHTML = '<p>No se encontraron resultados para: ' + query + '</p>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('results').innerHTML = '<p>Error en la búsqueda</p>';
                });
            }
        });
        </script>
    </body>
    </html>
    '''

@app.route('/search')
def search():
    query = request.args.get('q', '').strip()
    
    if not query:
        return jsonify({'documents': [], 'message': 'Query vacío'})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Búsqueda en título, contenido y keywords
    search_pattern = f'%{query}%'
    cursor.execute('''
        SELECT id, title, content, category, subcategory, date_published, 
               document_type, document_number, keywords
        FROM documents 
        WHERE title LIKE ? OR content LIKE ? OR keywords LIKE ?
        ORDER BY date_published DESC
        LIMIT 50
    ''', (search_pattern, search_pattern, search_pattern))
    
    results = cursor.fetchall()
    
    # Filtrar duplicados por título (usando el mismo método que implementamos antes)
    documents = []
    seen_titles = set()
    
    for row in results:
        title = row[1]
        if title not in seen_titles:
            seen_titles.add(title)
            documents.append({
                'id': row[0],
                'title': row[1],
                'content': row[2],
                'category': row[3],
                'subcategory': row[4],
                'date_published': row[5],
                'document_type': row[6],
                'document_number': row[7],
                'keywords': row[8]
            })
    
    conn.close()
    
    return jsonify({
        'documents': documents,
        'total': len(documents),
        'query': query
    })

@app.route('/stats')
def stats():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Estadísticas generales
    cursor.execute('SELECT COUNT(*) FROM documents')
    total = cursor.fetchone()[0]
    
    cursor.execute('SELECT document_type, COUNT(*) FROM documents GROUP BY document_type ORDER BY COUNT(*) DESC')
    types = cursor.fetchall()
    
    cursor.execute('SELECT category, COUNT(*) FROM documents WHERE category IS NOT NULL GROUP BY category ORDER BY COUNT(*) DESC LIMIT 10')
    categories = cursor.fetchall()
    
    conn.close()
    
    return jsonify({
        'total_documents': total,
        'document_types': [{'type': row[0], 'count': row[1]} for row in types],
        'top_categories': [{'category': row[0], 'count': row[1]} for row in categories]
    })

if __name__ == '__main__':
    print("🚀 Iniciando servidor de prueba LexColombia")
    print("📊 Accede a http://localhost:5000 para probar la búsqueda")
    print("📈 Accede a http://localhost:5000/stats para ver estadísticas")
    app.run(debug=True, host='0.0.0.0', port=5000)