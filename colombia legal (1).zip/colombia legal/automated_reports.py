#!/usr/bin/env python3
"""
Script de Reportes Automáticos para LexColombia
Genera reportes diarios, semanales y mensuales automáticamente
Puede ejecutarse como tarea programada (cron) o manualmente
"""

import os
import sys
import json
from datetime import datetime, timedelta
from pathlib import Path

# Agregar el directorio del proyecto al path
sys.path.append(os.path.join(os.path.dirname(__file__)))

from analytics_system import AnalyticsSystem

class AutomatedReportingSystem:
    def __init__(self, db_path='legislation.db'):
        self.analytics = AnalyticsSystem(db_path)
        self.reports_dir = Path('reports')
        self.reports_dir.mkdir(exist_ok=True)
        
        # Configurar logging
        self.setup_logging()
    
    def setup_logging(self):
        """Configurar sistema de logging"""
        import logging
        
        log_dir = Path('logs')
        log_dir.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / 'automated_reports.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def generate_daily_report(self):
        """Generar reporte diario"""
        try:
            self.logger.info("Iniciando generación de reporte diario...")
            
            # Generar reporte
            report = self.analytics.generate_automatic_report('daily')
            
            # Guardar reporte
            timestamp = datetime.now().strftime('%Y%m%d')
            filename = f"daily_report_{timestamp}.json"
            filepath = self.analytics.save_report_to_file(report, filename)
            
            # Generar resumen HTML
            html_summary = self.generate_html_summary(report, 'daily')
            html_filename = f"daily_summary_{timestamp}.html"
            html_filepath = self.reports_dir / html_filename
            
            with open(html_filepath, 'w', encoding='utf-8') as f:
                f.write(html_summary)
            
            self.logger.info(f"Reporte diario generado: {filepath}")
            self.logger.info(f"Resumen HTML generado: {html_filepath}")
            
            return {
                'success': True,
                'report_file': filepath,
                'html_file': str(html_filepath),
                'date': timestamp
            }
            
        except Exception as e:
            self.logger.error(f"Error generando reporte diario: {e}")
            return {'success': False, 'error': str(e)}
    
    def generate_weekly_report(self):
        """Generar reporte semanal"""
        try:
            self.logger.info("Iniciando generación de reporte semanal...")
            
            # Generar reporte
            report = self.analytics.generate_automatic_report('weekly')
            
            # Guardar reporte
            timestamp = datetime.now().strftime('%Y%m%d')
            filename = f"weekly_report_{timestamp}.json"
            filepath = self.analytics.save_report_to_file(report, filename)
            
            # Generar resumen HTML
            html_summary = self.generate_html_summary(report, 'weekly')
            html_filename = f"weekly_summary_{timestamp}.html"
            html_filepath = self.reports_dir / html_filename
            
            with open(html_filepath, 'w', encoding='utf-8') as f:
                f.write(html_summary)
            
            self.logger.info(f"Reporte semanal generado: {filepath}")
            self.logger.info(f"Resumen HTML generado: {html_filepath}")
            
            return {
                'success': True,
                'report_file': filepath,
                'html_file': str(html_filepath),
                'date': timestamp
            }
            
        except Exception as e:
            self.logger.error(f"Error generando reporte semanal: {e}")
            return {'success': False, 'error': str(e)}
    
    def generate_monthly_report(self):
        """Generar reporte mensual"""
        try:
            self.logger.info("Iniciando generación de reporte mensual...")
            
            # Generar reporte
            report = self.analytics.generate_automatic_report('monthly')
            
            # Guardar reporte
            timestamp = datetime.now().strftime('%Y%m%d')
            filename = f"monthly_report_{timestamp}.json"
            filepath = self.analytics.save_report_to_file(report, filename)
            
            # Generar resumen HTML
            html_summary = self.generate_html_summary(report, 'monthly')
            html_filename = f"monthly_summary_{timestamp}.html"
            html_filepath = self.reports_dir / html_filename
            
            with open(html_filepath, 'w', encoding='utf-8') as f:
                f.write(html_summary)
            
            self.logger.info(f"Reporte mensual generado: {filepath}")
            self.logger.info(f"Resumen HTML generado: {html_filepath}")
            
            return {
                'success': True,
                'report_file': filepath,
                'html_file': str(html_filepath),
                'date': timestamp
            }
            
        except Exception as e:
            self.logger.error(f"Error generando reporte mensual: {e}")
            return {'success': False, 'error': str(e)}
    
    def generate_html_summary(self, report, report_type):
        """Generar resumen HTML del reporte"""
        metrics = report.get('metrics', {})
        
        html = f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte {report_type.title()} - LexColombia Analytics</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f7fa;
            color: #333;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
        }}
        .metric-card {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid #3498db;
        }}
        .metric-value {{
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }}
        .metric-label {{
            color: #7f8c8d;
            font-size: 0.9rem;
        }}
        .section {{
            padding: 20px 30px;
            border-bottom: 1px solid #eee;
        }}
        .section h3 {{
            color: #2c3e50;
            margin-bottom: 15px;
        }}
        .top-list {{
            list-style: none;
            padding: 0;
        }}
        .top-list li {{
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f1f1f1;
        }}
        .footer {{
            background: #34495e;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 0.9rem;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Reporte {report_type.title()} - LexColombia</h1>
            <p>Período: {report.get('period', 'N/A')}</p>
            <p>Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
        </div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-value">{metrics.get('unique_users', 0)}</div>
                <div class="metric-label">Usuarios Únicos</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics.get('total_searches', 0)}</div>
                <div class="metric-label">Búsquedas Totales</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics.get('total_document_views', 0)}</div>
                <div class="metric-label">Documentos Vistos</div>
            </div>
            <div class="metric-card">
                <div class="metric-value">{metrics.get('total_activities', 0)}</div>
                <div class="metric-label">Actividades Totales</div>
            </div>
        </div>
        
        <div class="section">
            <h3>🔍 Términos Más Buscados</h3>
            <ul class="top-list">
        """
        
        # Agregar top búsquedas
        for search, count in metrics.get('top_searches', [])[:10]:
            html += f"<li><span>{search}</span><span>{count} búsquedas</span></li>"
        
        html += """
            </ul>
        </div>
        
        <div class="section">
            <h3>📄 Documentos Más Vistos</h3>
            <ul class="top-list">
        """
        
        # Agregar documentos más vistos
        for doc_id, title, category, views in metrics.get('top_documents', [])[:10]:
            safe_title = title[:50] + '...' if len(title) > 50 else title
            html += f"<li><span>{safe_title} ({category})</span><span>{views} vistas</span></li>"
        
        html += f"""
            </ul>
        </div>
        
        <div class="section">
            <h3>⚡ Rendimiento del Sistema</h3>
            <p><strong>Tiempo promedio de búsqueda:</strong> {metrics.get('search_performance', {}).get('avg_duration_ms', 0):.0f}ms</p>
            <p><strong>Búsqueda más rápida:</strong> {metrics.get('search_performance', {}).get('min_duration_ms', 0):.0f}ms</p>
            <p><strong>Búsqueda más lenta:</strong> {metrics.get('search_performance', {}).get('max_duration_ms', 0):.0f}ms</p>
        </div>
        
        <div class="footer">
            <p>Reporte generado automáticamente por LexColombia Analytics System</p>
            <p>Datos calculados en: {report.get('generated_at', datetime.now().isoformat())}</p>
        </div>
    </div>
</body>
</html>
        """
        
        return html
    
    def cleanup_old_reports(self, days_to_keep=30):
        """Limpiar reportes antiguos"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            deleted_count = 0
            
            for file_path in self.reports_dir.glob('*'):
                if file_path.is_file():
                    # Obtener fecha de modificación del archivo
                    file_date = datetime.fromtimestamp(file_path.stat().st_mtime)
                    
                    if file_date < cutoff_date:
                        file_path.unlink()
                        deleted_count += 1
                        self.logger.info(f"Archivo eliminado: {file_path}")
            
            self.logger.info(f"Limpieza completada. {deleted_count} archivos eliminados.")
            return deleted_count
            
        except Exception as e:
            self.logger.error(f"Error en limpieza de archivos: {e}")
            return 0
    
    def run_all_reports(self):
        """Ejecutar todos los reportes"""
        results = {
            'daily': self.generate_daily_report(),
            'weekly': self.generate_weekly_report(),
            'monthly': self.generate_monthly_report()
        }
        
        # Limpiar archivos antiguos
        self.cleanup_old_reports()
        
        return results

def main():
    """Función principal para ejecutar desde línea de comandos"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Sistema de Reportes Automáticos de LexColombia')
    parser.add_argument('--type', choices=['daily', 'weekly', 'monthly', 'all'], 
                       default='daily', help='Tipo de reporte a generar')
    parser.add_argument('--db-path', default='legislation.db', 
                       help='Ruta a la base de datos')
    parser.add_argument('--cleanup', action='store_true', 
                       help='Ejecutar limpieza de archivos antiguos')
    
    args = parser.parse_args()
    
    # Cambiar al directorio del script
    script_dir = Path(__file__).parent
    os.chdir(script_dir)
    
    # Inicializar sistema de reportes
    reporting_system = AutomatedReportingSystem(args.db_path)
    
    print(f"🚀 Iniciando generación de reportes de LexColombia...")
    print(f"Directorio de trabajo: {os.getcwd()}")
    print(f"Tipo de reporte: {args.type}")
    
    try:
        if args.type == 'daily':
            result = reporting_system.generate_daily_report()
        elif args.type == 'weekly':
            result = reporting_system.generate_weekly_report()
        elif args.type == 'monthly':
            result = reporting_system.generate_monthly_report()
        elif args.type == 'all':
            result = reporting_system.run_all_reports()
        
        if args.cleanup:
            print("🧹 Ejecutando limpieza de archivos antiguos...")
            deleted = reporting_system.cleanup_old_reports()
            print(f"✅ {deleted} archivos antiguos eliminados.")
        
        print("✅ Generación de reportes completada exitosamente!")
        print(f"Resultado: {result}")
        
    except Exception as e:
        print(f"❌ Error generando reportes: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()