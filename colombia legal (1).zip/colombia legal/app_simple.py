#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LexColombia - Aplicación Principal (Sin IA)
Versión simplificada para testing básico
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
import json
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
import io

app = Flask(__name__)
app.secret_key = 'lexcolombia_secret_key_2025'

# Clase de IA simplificada (sin transformers)
class LocalAI:
    def __init__(self):
        self.initialized = False
    
    def initialize(self):
        self.initialized = True
        print("IA Mock inicializada correctamente")
    
    def get_answer(self, question, context):
        # Respuesta mock basada en keywords
        if any(word in question.lower() for word in ['constitución', 'constitutional']):
            return "La Constitución Política de Colombia de 1991 es la norma suprema del país. Establece los principios fundamentales del Estado colombiano y los derechos de los ciudadanos."
        elif any(word in question.lower() for word in ['civil', 'persona']):
            return "El Código Civil colombiano regula las relaciones entre personas naturales y jurídicas, incluyendo derechos sobre bienes, obligaciones y contratos."
        elif any(word in question.lower() for word in ['penal', 'delito', 'homicidio']):
            return "El Código Penal establece los delitos y las penas correspondientes. Define principios como la legalidad y tipicidad de las conductas punibles."
        elif any(word in question.lower() for word in ['trabajo', 'laboral', 'empleado']):
            return "El Código Sustantivo del Trabajo regula las relaciones laborales en Colombia, incluyendo contratos, salarios y prestaciones sociales."
        else:
            return f"Basado en la búsqueda realizada, encontré información relacionada con tu pregunta sobre '{question}'. Te sugiero revisar los documentos mostrados para obtener información más específica."

# Instancia global de IA
ai_assistant = LocalAI()

# Inicializar las bases de datos
def init_db():
    # Base de datos de usuarios
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            document_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    conn.commit()
    conn.close()
    
    # Base de datos de legislación
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            subcategory TEXT,
            date_published DATE,
            document_type TEXT,
            document_number TEXT,
            keywords TEXT,
            full_text TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        # Validación básica
        if not username or not password:
            flash('Por favor ingresa usuario y contraseña', 'error')
            return render_template('login.html')
        
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT id, username, password_hash FROM users WHERE username = ?', (username,))
            user = c.fetchone()
            conn.close()
            
            if user is None:
                flash('Usuario no encontrado', 'error')
                return render_template('login.html')
            
            # Verificar contraseña
            if check_password_hash(user[2], password):
                session['user_id'] = user[0]
                session['username'] = user[1]
                flash(f'¡Bienvenido/a {username}!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Contraseña incorrecta', 'error')
                return render_template('login.html')
                
        except Exception as e:
            print(f"Error en login: {e}")
            flash('Error del sistema. Inténtalo de nuevo.', 'error')
            return render_template('login.html')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        
        # Validaciones básicas
        if not username or not email or not password:
            flash('Todos los campos son requeridos', 'error')
            return render_template('register.html')
            
        if len(password) < 6:
            flash('La contraseña debe tener al menos 6 caracteres', 'error')
            return render_template('register.html')
        
        password_hash = generate_password_hash(password)
        
        try:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            
            # Verificar si el usuario ya existe
            c.execute('SELECT username FROM users WHERE username = ? OR email = ?', (username, email))
            existing_user = c.fetchone()
            
            if existing_user:
                flash('El usuario o email ya existe', 'error')
                conn.close()
                return render_template('register.html')
            
            # Insertar nuevo usuario
            c.execute('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                     (username, email, password_hash))
            conn.commit()
            conn.close()
            
            flash('Registro exitoso. Por favor inicia sesión.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Error en registro: {e}")
            flash('Error del sistema. Inténtalo de nuevo.', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Has cerrado sesión correctamente', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/search')
def search():
    query = request.args.get('q', '')
    
    if not query:
        return jsonify({'documents': [], 'suggestions': []})
    
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    # Búsqueda en título, contenido y palabras clave
    search_query = f'%{query}%'
    c.execute('''
        SELECT id, title, content, category, subcategory, document_type, document_number
        FROM documents 
        WHERE title LIKE ? OR content LIKE ? OR keywords LIKE ?
        ORDER BY 
            CASE 
                WHEN title LIKE ? THEN 1
                WHEN keywords LIKE ? THEN 2
                ELSE 3
            END,
            title
        LIMIT 50
    ''', (search_query, search_query, search_query, search_query, search_query))
    
    results = c.fetchall()
    conn.close()
    
    documents = []
    seen_titles = set()  # Para rastrear títulos ya vistos
    for row in results:
        title = row[1]
        # Solo agregar si no hemos visto este título antes
        if title not in seen_titles:
            seen_titles.add(title)
            documents.append({
                'id': row[0],
                'title': title,
                'content': row[2][:200] + '...' if len(row[2]) > 200 else row[2],
                'category': row[3],
                'subcategory': row[4],
                'document_type': row[5],
                'document_number': row[6]
            })
    
    return jsonify({'documents': documents})

@app.route('/autocomplete')
def autocomplete():
    query = request.args.get('q', '')
    
    if len(query) < 2:
        return jsonify([])
    
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    search_query = f'%{query}%'
    c.execute('''
        SELECT DISTINCT title FROM documents 
        WHERE title LIKE ? 
        ORDER BY title 
        LIMIT 10
    ''', (search_query,))
    
    suggestions = [row[0] for row in c.fetchall()]
    conn.close()
    
    return jsonify(suggestions)

@app.route('/document/<int:doc_id>')
def view_document(doc_id):
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('''
        SELECT id, title, content, category, subcategory, date_published, 
               document_type, document_number, keywords, full_text
        FROM documents WHERE id = ?
    ''', (doc_id,))
    
    document = c.fetchone()
    conn.close()
    
    if not document:
        flash('Documento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    doc_dict = {
        'id': document[0],
        'title': document[1],
        'content': document[2],
        'category': document[3],
        'subcategory': document[4],
        'date_published': document[5],
        'document_type': document[6],
        'document_number': document[7],
        'keywords': document[8],
        'full_text': document[9]
    }
    
    return render_template('document.html', document=doc_dict)

@app.route('/add_favorite/<int:doc_id>', methods=['POST'])
def add_favorite(doc_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Debes iniciar sesión'})
    
    user_id = session['user_id']
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    
    # Verificar si ya está en favoritos
    c.execute('SELECT id FROM user_favorites WHERE user_id = ? AND document_id = ?', 
              (user_id, doc_id))
    existing = c.fetchone()
    
    if existing:
        return jsonify({'success': False, 'message': 'Ya está en favoritos'})
    
    c.execute('INSERT INTO user_favorites (user_id, document_id) VALUES (?, ?)',
              (user_id, doc_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Añadido a favoritos'})

@app.route('/remove_favorite/<int:doc_id>', methods=['POST'])
def remove_favorite(doc_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Debes iniciar sesión'})
    
    user_id = session['user_id']
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('DELETE FROM user_favorites WHERE user_id = ? AND document_id = ?',
              (user_id, doc_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Eliminado de favoritos'})

@app.route('/favorites')
def favorites():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    
    conn_users = sqlite3.connect('users.db')
    conn_docs = sqlite3.connect('legislation.db')
    
    c_users = conn_users.cursor()
    c_docs = conn_docs.cursor()
    
    c_users.execute('SELECT document_id FROM user_favorites WHERE user_id = ?', (user_id,))
    favorite_ids = [row[0] for row in c_users.fetchall()]
    
    favorite_documents = []
    for doc_id in favorite_ids:
        c_docs.execute('''
            SELECT id, title, content, category, subcategory, document_type, document_number
            FROM documents WHERE id = ?
        ''', (doc_id,))
        doc = c_docs.fetchone()
        if doc:
            favorite_documents.append({
                'id': doc[0],
                'title': doc[1],
                'content': doc[2][:200] + '...' if len(doc[2]) > 200 else doc[2],
                'category': doc[3],
                'subcategory': doc[4],
                'document_type': doc[5],
                'document_number': doc[6]
            })
    
    conn_users.close()
    conn_docs.close()
    
    return render_template('favorites.html', documents=favorite_documents)

@app.route('/download_pdf/<int:doc_id>')
def download_pdf(doc_id):
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    c.execute('SELECT title, full_text, category, document_type, document_number FROM documents WHERE id = ?', (doc_id,))
    document = c.fetchone()
    conn.close()
    
    if not document:
        flash('Documento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    # Crear PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Estilos personalizados
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=TA_CENTER,
        textColor=colors.HexColor('#1e3a8a')
    )
    
    watermark_style = ParagraphStyle(
        'Watermark',
        parent=styles['Normal'],
        fontSize=10,
        alignment=TA_CENTER,
        textColor=colors.grey
    )
    
    content_style = ParagraphStyle(
        'Content',
        parent=styles['Normal'],
        fontSize=12,
        alignment=TA_JUSTIFY,
        spaceAfter=12
    )
    
    story = []
    
    # Título del documento
    story.append(Paragraph(document[0], title_style))
    story.append(Spacer(1, 12))
    
    # Información del documento
    info = f"<b>Categoría:</b> {document[2]}<br/>"
    info += f"<b>Tipo:</b> {document[3]}<br/>"
    info += f"<b>Número:</b> {document[4]}<br/>"
    story.append(Paragraph(info, styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Contenido
    story.append(Paragraph(document[1], content_style))
    story.append(Spacer(1, 30))
    
    # Marca de agua
    watermark_text = "Generado por LexColombia - Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares"
    story.append(Paragraph(watermark_text, watermark_style))
    
    doc.build(story)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'LexColombia_{document[0][:50]}.pdf',
        mimetype='application/pdf'
    )

@app.route('/ai_chat', methods=['POST'])
def ai_chat():
    if not ai_assistant.initialized:
        ai_assistant.initialize()
    
    data = request.get_json()
    question = data.get('question', '')
    
    if not question:
        return jsonify({
            'success': False, 
            'message': 'Por favor proporciona una pregunta.'
        })
    
    # Buscar contexto relevante en la base de datos
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    search_terms = question.split()
    search_conditions = []
    search_params = []
    
    for term in search_terms[:3]:  # Limitar a 3 términos para evitar consultas muy complejas
        search_conditions.append("(full_text LIKE ? OR title LIKE ? OR keywords LIKE ?)")
        search_params.extend([f'%{term}%', f'%{term}%', f'%{term}%'])
    
    if search_conditions:
        search_query = f'''
            SELECT full_text FROM documents 
            WHERE {' OR '.join(search_conditions)}
            ORDER BY 
                CASE 
                    WHEN title LIKE ? THEN 1
                    WHEN keywords LIKE ? THEN 2
                    ELSE 3
                END
            LIMIT 5
        '''
        
        # Agregar parámetros para ORDER BY
        first_term = search_terms[0] if search_terms else question
        search_params.extend([f'%{first_term}%', f'%{first_term}%'])
        
        c.execute(search_query, search_params)
        contexts = [row[0] for row in c.fetchall()]
    else:
        contexts = []
    
    conn.close()
    
    if not contexts:
        return jsonify({
            'success': True,
            'answer': 'No encontré información relevante en la base de datos para responder tu pregunta. Por favor, intenta con términos más específicos relacionados con la legislación colombiana.'
        })
    
    # Combinar contextos
    combined_context = ' '.join(contexts[:3])  # Limitar para evitar tokens excesivos
    
    # Obtener respuesta de la IA
    answer = ai_assistant.get_answer(question, combined_context)
    
    return jsonify({
        'success': True,
        'answer': answer
    })

if __name__ == '__main__':
    # Inicializar bases de datos
    init_db()
    
    # Inicializar IA
    ai_assistant.initialize()
    
    app.run(debug=True, host='0.0.0.0', port=5000)