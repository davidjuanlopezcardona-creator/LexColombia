"""
Sistema de Integraciones Externas para Colombia Legal
Implementa APIs REST, webhooks y conectores para herramientas externas
"""

import sqlite3
import json
import requests
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request, make_response
import hashlib
import hmac
import base64
from typing import Dict, List, Optional
import pandas as pd

class ExternalIntegrations:
    def __init__(self, db_path='legislation.db'):
        self.db_path = db_path
        self.webhook_endpoints = {}
        self.api_keys = {}
        self.rate_limits = {}
        
    def register_webhook(self, event_type: str, endpoint_url: str, secret_key: str = None):
        """Registrar webhook para eventos específicos"""
        self.webhook_endpoints[event_type] = {
            'url': endpoint_url,
            'secret': secret_key,
            'active': True,
            'created_at': datetime.now().isoformat()
        }
        
        return True
    
    def trigger_webhook(self, event_type: str, data: Dict):
        """Disparar webhook para un evento"""
        if event_type not in self.webhook_endpoints:
            return False
        
        webhook = self.webhook_endpoints[event_type]
        if not webhook['active']:
            return False
        
        # Preparar payload
        payload = {
            'event_type': event_type,
            'timestamp': datetime.now().isoformat(),
            'data': data
        }
        
        # Agregar firma si hay secret key
        headers = {'Content-Type': 'application/json'}
        if webhook['secret']:
            signature = self._generate_signature(json.dumps(payload), webhook['secret'])
            headers['X-Webhook-Signature'] = signature
        
        try:
            response = requests.post(
                webhook['url'],
                json=payload,
                headers=headers,
                timeout=10
            )
            return response.status_code == 200
        except:
            return False
    
    def _generate_signature(self, payload: str, secret: str) -> str:
        """Generar firma HMAC para webhook"""
        signature = hmac.new(
            secret.encode('utf-8'),
            payload.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return f"sha256={signature}"
    
    def generate_api_key(self, client_name: str, permissions: List[str]) -> str:
        """Generar API key para cliente externo"""
        key_data = f"{client_name}:{datetime.now().isoformat()}:{len(self.api_keys)}"
        api_key = hashlib.sha256(key_data.encode()).hexdigest()[:32]
        
        self.api_keys[api_key] = {
            'client_name': client_name,
            'permissions': permissions,
            'created_at': datetime.now().isoformat(),
            'active': True,
            'last_used': None,
            'usage_count': 0
        }
        
        return api_key
    
    def validate_api_key(self, api_key: str, required_permission: str = None) -> bool:
        """Validar API key y permisos"""
        if api_key not in self.api_keys:
            return False
        
        key_info = self.api_keys[api_key]
        if not key_info['active']:
            return False
        
        if required_permission and required_permission not in key_info['permissions']:
            return False
        
        # Actualizar estadísticas de uso
        key_info['last_used'] = datetime.now().isoformat()
        key_info['usage_count'] += 1
        
        return True
    
    def export_analytics_data(self, start_date: str, end_date: str, format: str = 'json') -> Dict:
        """Exportar datos de analytics para herramientas externas"""
        conn = sqlite3.connect(self.db_path)
        
        # Métricas de búsqueda
        search_query = """
        SELECT DATE(timestamp) as date,
               search_query,
               category_filter,
               results_count,
               search_duration_ms,
               user_id
        FROM search_metrics
        WHERE timestamp BETWEEN ? AND ?
        ORDER BY timestamp
        """
        
        search_df = pd.read_sql_query(search_query, conn, params=[start_date, end_date])
        
        # Métricas de documentos
        doc_query = """
        SELECT DATE(dm.timestamp) as date,
               dm.document_id,
               d.title,
               d.category,
               d.document_type,
               dm.action,
               dm.time_spent_seconds,
               dm.user_id
        FROM document_metrics dm
        JOIN documents d ON dm.document_id = d.id
        WHERE dm.timestamp BETWEEN ? AND ?
        ORDER BY dm.timestamp
        """
        
        doc_df = pd.read_sql_query(doc_query, conn, params=[start_date, end_date])
        
        # Actividad de usuarios
        activity_query = """
        SELECT DATE(timestamp) as date,
               user_id,
               username,
               action_type,
               details
        FROM user_activity
        WHERE timestamp BETWEEN ? AND ?
        ORDER BY timestamp
        """
        
        activity_df = pd.read_sql_query(activity_query, conn, params=[start_date, end_date])
        
        conn.close()
        
        # Preparar datos de exportación
        export_data = {
            'metadata': {
                'exported_at': datetime.now().isoformat(),
                'start_date': start_date,
                'end_date': end_date,
                'format': format,
                'total_records': {
                    'searches': len(search_df),
                    'document_interactions': len(doc_df),
                    'user_activities': len(activity_df)
                }
            },
            'search_metrics': search_df.to_dict('records'),
            'document_metrics': doc_df.to_dict('records'),
            'user_activity': activity_df.to_dict('records')
        }
        
        if format == 'csv':
            # Para CSV, devolver DataFrames separados
            return {
                'search_metrics': search_df,
                'document_metrics': doc_df,
                'user_activity': activity_df
            }
        
        return export_data
    
    def create_tableau_connector(self):
        """Crear datos formateados para Tableau"""
        conn = sqlite3.connect(self.db_path)
        
        # Query optimizada para Tableau
        tableau_query = """
        SELECT 
            DATE(sm.timestamp) as date,
            sm.search_query,
            sm.category_filter,
            sm.results_count,
            sm.search_duration_ms,
            sm.user_id,
            CASE 
                WHEN sm.search_duration_ms < 100 THEN 'Fast'
                WHEN sm.search_duration_ms < 500 THEN 'Medium'
                ELSE 'Slow'
            END as search_speed,
            strftime('%w', sm.timestamp) as day_of_week,
            strftime('%H', sm.timestamp) as hour_of_day,
            CASE 
                WHEN strftime('%w', sm.timestamp) IN ('0', '6') THEN 'Weekend'
                ELSE 'Weekday'
            END as day_type
        FROM search_metrics sm
        WHERE sm.timestamp >= date('now', '-90 days')
        ORDER BY sm.timestamp DESC
        """
        
        tableau_df = pd.read_sql_query(tableau_query, conn)
        conn.close()
        
        return tableau_df
    
    def create_powerbi_dataset(self):
        """Crear dataset para Power BI"""
        conn = sqlite3.connect(self.db_path)
        
        # Datos agregados por día para Power BI
        powerbi_query = """
        SELECT 
            DATE(timestamp) as date,
            COUNT(*) as total_searches,
            COUNT(DISTINCT user_id) as unique_users,
            AVG(search_duration_ms) as avg_search_duration,
            COUNT(DISTINCT search_query) as unique_queries,
            SUM(CASE WHEN results_count > 0 THEN 1 ELSE 0 END) as successful_searches,
            SUM(CASE WHEN results_count = 0 THEN 1 ELSE 0 END) as failed_searches
        FROM search_metrics
        WHERE timestamp >= date('now', '-365 days')
        GROUP BY DATE(timestamp)
        ORDER BY date
        """
        
        powerbi_df = pd.read_sql_query(powerbi_query, conn)
        
        # Agregar métricas calculadas
        powerbi_df['success_rate'] = (powerbi_df['successful_searches'] / powerbi_df['total_searches'] * 100).round(2)
        powerbi_df['searches_per_user'] = (powerbi_df['total_searches'] / powerbi_df['unique_users']).round(2)
        
        conn.close()
        
        return powerbi_df
    
    def setup_google_analytics_integration(self, ga_tracking_id: str):
        """Configurar integración con Google Analytics"""
        # En un entorno real, esto configuraría el tracking de GA
        ga_config = {
            'tracking_id': ga_tracking_id,
            'events_to_track': [
                'search_performed',
                'document_viewed',
                'document_favorited',
                'user_registered',
                'session_started'
            ],
            'custom_dimensions': {
                'document_category': 1,
                'document_type': 2,
                'user_type': 3
            }
        }
        
        return ga_config
    
    def create_elasticsearch_mapping(self):
        """Crear mapping para Elasticsearch"""
        es_mapping = {
            "mappings": {
                "properties": {
                    "timestamp": {
                        "type": "date",
                        "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis"
                    },
                    "user_id": {
                        "type": "integer"
                    },
                    "search_query": {
                        "type": "text",
                        "analyzer": "spanish",
                        "fields": {
                            "keyword": {
                                "type": "keyword"
                            }
                        }
                    },
                    "category_filter": {
                        "type": "keyword"
                    },
                    "results_count": {
                        "type": "integer"
                    },
                    "search_duration_ms": {
                        "type": "integer"
                    },
                    "document_id": {
                        "type": "integer"
                    },
                    "document_title": {
                        "type": "text",
                        "analyzer": "spanish"
                    },
                    "document_category": {
                        "type": "keyword"
                    },
                    "action_type": {
                        "type": "keyword"
                    },
                    "success": {
                        "type": "boolean"
                    }
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0,
                "analysis": {
                    "analyzer": {
                        "spanish": {
                            "tokenizer": "standard",
                            "filter": [
                                "lowercase",
                                "spanish_stop",
                                "spanish_stemmer"
                            ]
                        }
                    },
                    "filter": {
                        "spanish_stop": {
                            "type": "stop",
                            "stopwords": "_spanish_"
                        },
                        "spanish_stemmer": {
                            "type": "stemmer",
                            "language": "spanish"
                        }
                    }
                }
            }
        }
        
        return es_mapping
    
    def stream_data_to_elasticsearch(self, es_client, index_name: str, days_back: int = 1):
        """Enviar datos a Elasticsearch"""
        conn = sqlite3.connect(self.db_path)
        
        # Obtener datos recientes
        start_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d')
        
        stream_query = """
        SELECT 
            sm.timestamp,
            sm.user_id,
            sm.search_query,
            sm.category_filter,
            sm.results_count,
            sm.search_duration_ms,
            CASE WHEN sm.results_count > 0 THEN true ELSE false END as success
        FROM search_metrics sm
        WHERE DATE(sm.timestamp) >= ?
        
        UNION ALL
        
        SELECT 
            dm.timestamp,
            dm.user_id,
            d.title as search_query,
            d.category as category_filter,
            1 as results_count,
            dm.time_spent_seconds * 1000 as search_duration_ms,
            true as success
        FROM document_metrics dm
        JOIN documents d ON dm.document_id = d.id
        WHERE DATE(dm.timestamp) >= ? AND dm.action = 'view'
        """
        
        stream_df = pd.read_sql_query(stream_query, conn, params=[start_date, start_date])
        conn.close()
        
        # Enviar a Elasticsearch (simulado)
        documents_sent = 0
        for _, row in stream_df.iterrows():
            doc = {
                'timestamp': row['timestamp'],
                'user_id': row['user_id'],
                'search_query': row['search_query'],
                'category_filter': row['category_filter'],
                'results_count': row['results_count'],
                'search_duration_ms': row['search_duration_ms'],
                'success': row['success']
            }
            
            # En implementación real:
            # es_client.index(index=index_name, body=doc)
            documents_sent += 1
        
        return documents_sent

# Blueprint para API REST
api_blueprint = Blueprint('api', __name__)
integrations = ExternalIntegrations()

@api_blueprint.route('/api/v1/analytics/summary', methods=['GET'])
def api_analytics_summary():
    """Endpoint para resumen de analytics"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'analytics_read'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    days = request.args.get('days', 30, type=int)
    
    # Importar analytics system
    from analytics_system import analytics
    metrics = analytics.get_dashboard_metrics(days=days)
    
    return jsonify({
        'status': 'success',
        'data': metrics,
        'meta': {
            'days': days,
            'generated_at': datetime.now().isoformat()
        }
    })

@api_blueprint.route('/api/v1/documents/popular', methods=['GET'])
def api_popular_documents():
    """Endpoint para documentos populares"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'documents_read'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    limit = request.args.get('limit', 10, type=int)
    
    from recommendation_system import recommendation_system
    popular_docs = recommendation_system.get_popular_documents(limit)
    
    return jsonify({
        'status': 'success',
        'data': popular_docs,
        'meta': {
            'limit': limit,
            'generated_at': datetime.now().isoformat()
        }
    })

@api_blueprint.route('/api/v1/recommendations/<int:user_id>', methods=['GET'])
def api_user_recommendations(user_id):
    """Endpoint para recomendaciones de usuario"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'recommendations_read'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    limit = request.args.get('limit', 10, type=int)
    
    from recommendation_system import recommendation_system
    recommendations = recommendation_system.get_personalized_recommendations(user_id, limit)
    
    return jsonify({
        'status': 'success',
        'data': recommendations,
        'meta': {
            'user_id': user_id,
            'limit': limit,
            'generated_at': datetime.now().isoformat()
        }
    })

@api_blueprint.route('/api/v1/export/analytics', methods=['GET'])
def api_export_analytics():
    """Endpoint para exportar datos de analytics"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'analytics_export'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    format_type = request.args.get('format', 'json')
    
    if not start_date or not end_date:
        return jsonify({'error': 'start_date and end_date are required'}), 400
    
    export_data = integrations.export_analytics_data(start_date, end_date, format_type)
    
    if format_type == 'csv':
        # Para CSV, retornar enlaces de descarga
        return jsonify({
            'status': 'success',
            'message': 'CSV export prepared',
            'download_links': {
                'search_metrics': '/api/v1/download/search_metrics.csv',
                'document_metrics': '/api/v1/download/document_metrics.csv',
                'user_activity': '/api/v1/download/user_activity.csv'
            }
        })
    
    return jsonify({
        'status': 'success',
        'data': export_data
    })

@api_blueprint.route('/api/v1/tableau/connector', methods=['GET'])
def api_tableau_connector():
    """Endpoint para conectar con Tableau"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'bi_connector'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    tableau_data = integrations.create_tableau_connector()
    
    # Convertir a formato JSON para Tableau
    return jsonify({
        'status': 'success',
        'data': tableau_data.to_dict('records'),
        'schema': {
            'columns': list(tableau_data.columns),
            'types': tableau_data.dtypes.to_dict()
        }
    })

@api_blueprint.route('/api/v1/powerbi/dataset', methods=['GET'])
def api_powerbi_dataset():
    """Endpoint para dataset de Power BI"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'bi_connector'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    powerbi_data = integrations.create_powerbi_dataset()
    
    return jsonify({
        'status': 'success',
        'data': powerbi_data.to_dict('records'),
        'metadata': {
            'total_records': len(powerbi_data),
            'date_range': {
                'start': powerbi_data['date'].min(),
                'end': powerbi_data['date'].max()
            }
        }
    })

@api_blueprint.route('/api/v1/webhooks/register', methods=['POST'])
def api_register_webhook():
    """Endpoint para registrar webhooks"""
    api_key = request.headers.get('X-API-Key')
    if not integrations.validate_api_key(api_key, 'webhooks_manage'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.get_json()
    event_type = data.get('event_type')
    endpoint_url = data.get('endpoint_url')
    secret_key = data.get('secret_key')
    
    if not event_type or not endpoint_url:
        return jsonify({'error': 'event_type and endpoint_url are required'}), 400
    
    success = integrations.register_webhook(event_type, endpoint_url, secret_key)
    
    return jsonify({
        'status': 'success' if success else 'error',
        'message': 'Webhook registered successfully' if success else 'Failed to register webhook'
    })

# Instancia global de integraciones
external_integrations = integrations