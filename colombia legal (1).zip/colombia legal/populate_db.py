#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Colombia Legal - Poblador de Base de Datos
Script para poblar la base de datos con legislación colombiana de ejemplo
"""

import sqlite3
import json
from datetime import datetime

def populate_legislation_database():
    """Poblar la base de datos con documentos legales colombianos"""
    
    conn = sqlite3.connect('legislation.db')
    c = conn.cursor()
    
    # Documentos legales más completos
    documents = [
        # Constitución Política
        {
            'title': 'Constitución Política de Colombia - Artículo 1',
            'content': 'Colombia es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, con autonomía de sus entidades territoriales, democrática, participativa y pluralista, fundada en el respeto de la dignidad humana, en el trabajo y la solidaridad de las personas que la integran y en la prevalencia del interés general.',
            'category': 'Constitución',
            'subcategory': 'Principios Fundamentales',
            'date_published': '1991-07-04',
            'document_type': 'Constitución',
            'document_number': 'Art. 1',
            'keywords': 'estado social derecho república democrática pluralista dignidad humana',
            'full_text': 'ARTÍCULO 1°. Colombia es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, con autonomía de sus entidades territoriales, democrática, participativa y pluralista, fundada en el respeto de la dignidad humana, en el trabajo y la solidaridad de las personas que la integran y en la prevalencia del interés general.'
        },
        {
            'title': 'Constitución Política de Colombia - Artículo 2',
            'content': 'Son fines esenciales del Estado: servir a la comunidad, promover la prosperidad general y garantizar la efectividad de los principios, derechos y deberes consagrados en la Constitución.',
            'category': 'Constitución',
            'subcategory': 'Principios Fundamentales',
            'date_published': '1991-07-04',
            'document_type': 'Constitución',
            'document_number': 'Art. 2',
            'keywords': 'fines estado servir comunidad prosperidad principios derechos deberes',
            'full_text': 'ARTÍCULO 2°. Son fines esenciales del Estado: servir a la comunidad, promover la prosperidad general y garantizar la efectividad de los principios, derechos y deberes consagrados en la Constitución; facilitar la participación de todos en las decisiones que los afectan y en la vida económica, política, administrativa y cultural de la Nación; defender la independencia nacional, mantener la integridad territorial y asegurar la convivencia pacífica y la vigencia de un orden justo.'
        },
        {
            'title': 'Constitución Política de Colombia - Artículo 11 - Derecho a la vida',
            'content': 'El derecho a la vida es inviolable. No habrá pena de muerte.',
            'category': 'Constitución',
            'subcategory': 'Derechos Fundamentales',
            'date_published': '1991-07-04',
            'document_type': 'Constitución',
            'document_number': 'Art. 11',
            'keywords': 'derecho vida inviolable pena muerte prohibición',
            'full_text': 'ARTÍCULO 11. El derecho a la vida es inviolable. No habrá pena de muerte.'
        },
        {
            'title': 'Constitución Política de Colombia - Artículo 13 - Igualdad',
            'content': 'Todas las personas nacen libres e iguales ante la ley, recibirán la misma protección y trato de las autoridades y gozarán de los mismos derechos, libertades y oportunidades sin ninguna discriminación.',
            'category': 'Constitución',
            'subcategory': 'Derechos Fundamentales',
            'date_published': '1991-07-04',
            'document_type': 'Constitución',
            'document_number': 'Art. 13',
            'keywords': 'igualdad ante ley protección discriminación libertades oportunidades',
            'full_text': 'ARTÍCULO 13. Todas las personas nacen libres e iguales ante la ley, recibirán la misma protección y trato de las autoridades y gozarán de los mismos derechos, libertades y oportunidades sin ninguna discriminación por razones de sexo, raza, origen nacional o familiar, lengua, religión, opinión política o filosófica.'
        },
        
        # Código Civil
        {
            'title': 'Código Civil Colombiano - Artículo 1',
            'content': 'La ley es una declaración de la voluntad soberana que, manifestada en la forma prescrita por la Constitución, manda, prohíbe o permite.',
            'category': 'Código Civil',
            'subcategory': 'Disposiciones Generales',
            'date_published': '1887-05-26',
            'document_type': 'Código',
            'document_number': 'Art. 1',
            'keywords': 'ley voluntad soberana constitución manda prohíbe permite',
            'full_text': 'ARTÍCULO 1°. La ley es una declaración de la voluntad soberana que, manifestada en la forma prescrita por la Constitución, manda, prohíbe o permite.'
        },
        {
            'title': 'Código Civil Colombiano - Artículo 74 - Personas naturales',
            'content': 'Son personas todos los individuos de la especie humana, cualquiera que sea su edad, sexo, estirpe o condición.',
            'category': 'Código Civil',
            'subcategory': 'Personas',
            'date_published': '1887-05-26',
            'document_type': 'Código',
            'document_number': 'Art. 74',
            'keywords': 'personas individuos especie humana edad sexo estirpe condición',
            'full_text': 'ARTÍCULO 74. Son personas todos los individuos de la especie humana, cualquiera que sea su edad, sexo, estirpe o condición. Divídense en colombianos y extranjeros.'
        },
        
        # Código Penal
        {
            'title': 'Código Penal Colombiano - Artículo 1 - Legalidad',
            'content': 'Nadie podrá ser juzgado sino conforme a las leyes preexistentes al acto que se le imputa, ante el juez o tribunal competente y con observancia de la plenitud de las formas propias de cada juicio.',
            'category': 'Código Penal',
            'subcategory': 'Principios Generales',
            'date_published': '2000-07-24',
            'document_type': 'Ley',
            'document_number': '599',
            'keywords': 'legalidad juzgado leyes preexistentes juez tribunal competente',
            'full_text': 'ARTÍCULO 1°. LEGALIDAD. Nadie podrá ser juzgado sino conforme a las leyes preexistentes al acto que se le imputa, ante el juez o tribunal competente y con observancia de la plenitud de las formas propias de cada juicio.'
        },
        {
            'title': 'Código Penal - Artículo 103 - Homicidio',
            'content': 'El que matare a otro, incurrirá en prisión de doscientos ocho (208) a cuatrocientos cincuenta (450) meses.',
            'category': 'Código Penal',
            'subcategory': 'Delitos contra la vida',
            'date_published': '2000-07-24',
            'document_type': 'Ley',
            'document_number': '599',
            'keywords': 'homicidio matar prisión delito vida',
            'full_text': 'ARTÍCULO 103. HOMICIDIO. El que matare a otro, incurrirá en prisión de doscientos ocho (208) a cuatrocientos cincuenta (450) meses.'
        },
        
        # Código de Procedimiento Penal
        {
            'title': 'Ley 906 de 2004 - Código de Procedimiento Penal - Artículo 1',
            'content': 'El presente código tiene por objeto establecer las normas que rigen la actuación de la Fiscalía General de la Nación, la Policía Judicial, los jueces y tribunales penales.',
            'category': 'Procedimiento Penal',
            'subcategory': 'Disposiciones Generales',
            'date_published': '2004-08-31',
            'document_type': 'Ley',
            'document_number': '906',
            'keywords': 'procedimiento penal fiscalía policía judicial jueces tribunales',
            'full_text': 'ARTÍCULO 1°. OBJETO. El presente código tiene por objeto establecer las normas que rigen la actuación de la Fiscalía General de la Nación, la Policía Judicial, los jueces y tribunales penales, la defensa, las víctimas y los terceros intervinientes en el desarrollo de la investigación y el juzgamiento de las conductas punibles.'
        },
        
        # Código Laboral
        {
            'title': 'Código Sustantivo del Trabajo - Artículo 22 - Contrato de trabajo',
            'content': 'Contrato de trabajo es aquel por el cual una persona natural se obliga a prestar un servicio personal a otra persona, natural o jurídica, bajo la continuada dependencia o subordinación.',
            'category': 'Código Laboral',
            'subcategory': 'Contrato de trabajo',
            'date_published': '1950-07-05',
            'document_type': 'Código',
            'document_number': 'Art. 22',
            'keywords': 'contrato trabajo servicio personal dependencia subordinación',
            'full_text': 'ARTÍCULO 22. CONTRATO DE TRABAJO. 1. Contrato de trabajo es aquel por el cual una persona natural se obliga a prestar un servicio personal a otra persona, natural o jurídica, bajo la continuada dependencia o subordinación de la segunda y mediante remuneración.'
        },
        
        # Derecho Administrativo
        {
            'title': 'Ley 1437 de 2011 - Código de Procedimiento Administrativo - Artículo 1',
            'content': 'La presente ley tiene por objeto establecer las normas que rigen los procedimientos y actuaciones de las entidades públicas.',
            'category': 'Administrativo',
            'subcategory': 'Procedimiento Administrativo',
            'date_published': '2011-01-18',
            'document_type': 'Ley',
            'document_number': '1437',
            'keywords': 'procedimiento administrativo entidades públicas actuaciones',
            'full_text': 'ARTÍCULO 1°. OBJETO Y ÁMBITO DE APLICACIÓN. La presente ley tiene por objeto establecer las normas que rigen los procedimientos y actuaciones de las entidades públicas y la participación de los administrados en dichas actuaciones.'
        },
        
        # Jurisprudencia Constitucional
        {
            'title': 'Sentencia C-025 de 2004 - Corte Constitucional',
            'content': 'La dignidad humana es el fundamento de los derechos fundamentales y principio fundante del ordenamiento jurídico constitucional.',
            'category': 'Jurisprudencia',
            'subcategory': 'Corte Constitucional',
            'date_published': '2004-01-27',
            'document_type': 'Sentencia',
            'document_number': 'C-025/04',
            'keywords': 'dignidad humana derechos fundamentales principio fundante',
            'full_text': 'SENTENCIA C-025/04. La dignidad humana es el fundamento de los derechos fundamentales y principio fundante del ordenamiento jurídico constitucional. Como tal, la dignidad humana constituye el presupuesto esencial de la consagración y efectividad del entero sistema de derechos y garantías contemplado en la Constitución.'
        },
        
        # Derecho Comercial
        {
            'title': 'Código de Comercio - Artículo 10 - Actos de comercio',
            'content': 'Son mercantiles para todos los efectos legales: La adquisición de bienes a título oneroso con destino a enajenarlos en igual forma.',
            'category': 'Código de Comercio',
            'subcategory': 'Actos de comercio',
            'date_published': '1971-03-27',
            'document_type': 'Decreto',
            'document_number': '410',
            'keywords': 'actos comercio mercantiles adquisición bienes enajenar',
            'full_text': 'ARTÍCULO 10. Son mercantiles para todos los efectos legales: 1) La adquisición de bienes a título oneroso con destino a enajenarlos en igual forma, y la enajenación de los mismos.'
        },
        
        # Derecho Tributario
        {
            'title': 'Estatuto Tributario - Artículo 1 - Contenido',
            'content': 'El presente Estatuto contiene las normas aplicables en materia de impuestos administrados por la Dirección de Impuestos y Aduanas Nacionales.',
            'category': 'Tributario',
            'subcategory': 'Disposiciones Generales',
            'date_published': '1989-03-30',
            'document_type': 'Decreto',
            'document_number': '624',
            'keywords': 'estatuto tributario impuestos DIAN aduanas nacionales',
            'full_text': 'ARTÍCULO 1°. CONTENIDO. El presente Estatuto contiene las normas aplicables en materia de impuestos administrados por la Dirección de Impuestos y Aduanas Nacionales, DIAN.'
        },
        
        # Derecho de Familia
        {
            'title': 'Código Civil - Artículo 113 - Matrimonio',
            'content': 'El matrimonio es un contrato solemne por el cual un hombre y una mujer se unen con el fin de vivir juntos, procrear y auxiliarse mutuamente.',
            'category': 'Familia',
            'subcategory': 'Matrimonio',
            'date_published': '1887-05-26',
            'document_type': 'Código',
            'document_number': 'Art. 113',
            'keywords': 'matrimonio contrato solemne unión vivir juntos procrear auxiliarse',
            'full_text': 'ARTÍCULO 113. El matrimonio es un contrato solemne por el cual un hombre y una mujer se unen con el fin de vivir juntos, procrear y auxiliarse mutuamente.'
        },
        
        # Más documentos de ejemplo
        {
            'title': 'Ley 1564 de 2012 - Código General del Proceso',
            'content': 'Por medio de la cual se expide el Código General del Proceso y se dictan otras disposiciones.',
            'category': 'Procedimiento Civil',
            'subcategory': 'Disposiciones Generales',
            'date_published': '2012-07-12',
            'document_type': 'Ley',
            'document_number': '1564',
            'keywords': 'código general proceso civil disposiciones',
            'full_text': 'LEY 1564 DE 2012. Por medio de la cual se expide el Código General del Proceso y se dictan otras disposiciones. El Congreso de Colombia DECRETA: ARTÍCULO 1°. FINALIDAD. La finalidad del proceso es la efectividad de los derechos reconocidos en el derecho sustancial.'
        },
        
        {
            'title': 'Decreto 1072 de 2015 - Decreto Único Reglamentario del Sector Trabajo',
            'content': 'Por medio del cual se expide el Decreto Único Reglamentario del Sector Trabajo.',
            'category': 'Código Laboral',
            'subcategory': 'Reglamentación',
            'date_published': '2015-05-26',
            'document_type': 'Decreto',
            'document_number': '1072',
            'keywords': 'decreto único reglamentario sector trabajo',
            'full_text': 'DECRETO 1072 DE 2015. Por medio del cual se expide el Decreto Único Reglamentario del Sector Trabajo. El Presidente de la República de Colombia, en ejercicio de sus facultades constitucionales y legales, DECRETA:'
        }
    ]
    
    # Insertar documentos
    for doc in documents:
        c.execute('''
            INSERT OR REPLACE INTO documents 
            (title, content, category, subcategory, date_published, document_type, document_number, keywords, full_text)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (doc['title'], doc['content'], doc['category'], doc['subcategory'], 
              doc['date_published'], doc['document_type'], doc['document_number'], 
              doc['keywords'], doc['full_text']))
    
    conn.commit()
    conn.close()
    
    print(f"✅ Base de datos poblada con {len(documents)} documentos legales")
    print("📚 Categorías incluidas:")
    categories = set(doc['category'] for doc in documents)
    for category in sorted(categories):
        count = sum(1 for doc in documents if doc['category'] == category)
        print(f"   • {category}: {count} documento(s)")

def create_sample_users():
    """Crear usuarios de ejemplo para testing"""
    
    from werkzeug.security import generate_password_hash
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    
    # Usuarios de ejemplo
    sample_users = [
        {
            'username': 'admin',
            'email': 'admin@colombialegal.com',
            'password': 'admin123'
        },
        {
            'username': 'demo',
            'email': 'demo@colombialegal.com',
            'password': 'demo123'
        },
        {
            'username': 'test',
            'email': 'test@colombialegal.com',
            'password': 'test123'
        }
    ]
    
    for user in sample_users:
        password_hash = generate_password_hash(user['password'])
        try:
            c.execute('''
                INSERT OR IGNORE INTO users (username, email, password_hash)
                VALUES (?, ?, ?)
            ''', (user['username'], user['email'], password_hash))
        except:
            pass  # Usuario ya existe
    
    conn.commit()
    conn.close()
    
    print("👥 Usuarios de ejemplo creados:")
    for user in sample_users:
        print(f"   • Usuario: {user['username']} | Contraseña: {user['password']}")

if __name__ == '__main__':
    print("🚀 Poblando base de datos de Colombia Legal...")
    print("="*50)
    
    populate_legislation_database()
    create_sample_users()
    
    print("="*50)
    print("✅ Base de datos poblada exitosamente!")
    print("🎉 Colombia Legal está listo para usar!")