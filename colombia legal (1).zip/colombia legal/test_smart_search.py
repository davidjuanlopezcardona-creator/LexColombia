#!/usr/bin/env python3
"""
Script de prueba para la nueva búsqueda inteligente
"""

import sys
import sqlite3
from app import SmartSearch

def test_database_connection():
    """Verifica la conexión a la base de datos"""
    try:
        conn = sqlite3.connect('legislation.db')
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM documents')
        count = c.fetchone()[0]
        conn.close()
        print(f"✅ Conexión a BD exitosa. Documentos encontrados: {count}")
        return True
    except Exception as e:
        print(f"❌ Error conectando a BD: {e}")
        return False

def test_smart_search_initialization():
    """Prueba la inicialización del sistema de búsqueda"""
    print("\n🔍 Probando inicialización de búsqueda inteligente...")
    
    search_system = SmartSearch()
    success = search_system.initialize()
    
    if success:
        print(f"✅ Sistema inicializado correctamente")
        print(f"   - Documentos cargados: {len(search_system.documents)}")
        print(f"   - Matriz TF-IDF: {search_system.tfidf_matrix.shape}")
        return search_system
    else:
        print("❌ Error en inicialización")
        return None

def test_search_functionality(search_system):
    """Prueba las funcionalidades de búsqueda"""
    print("\n🔎 Probando funcionalidades de búsqueda...")
    
    test_queries = [
        "constitución colombia",
        "código civil",
        "procedimiento penal",
        "derechos fundamentales",
        "ley 906"
    ]
    
    for query in test_queries:
        print(f"\n--- Búsqueda: '{query}' ---")
        results = search_system.search_documents(query, max_results=3)
        
        if results:
            for i, doc in enumerate(results, 1):
                print(f"{i}. {doc['title']} (Score: {doc['score_percentage']}%)")
        else:
            print("No se encontraron resultados")

def test_question_answering(search_system):
    """Prueba el sistema de respuesta a preguntas"""
    print("\n❓ Probando respuesta a preguntas...")
    
    test_questions = [
        "¿Qué es la constitución colombiana?",
        "¿Cómo funciona el procedimiento penal?",
        "¿Cuándo se aplica el código civil?",
        "¿Qué dice la ley sobre derechos fundamentales?"
    ]
    
    for question in test_questions:
        print(f"\n--- Pregunta: '{question}' ---")
        answer = search_system.answer_question(question)
        print(f"Respuesta: {answer[:200]}...")

def main():
    print("🧪 PRUEBA DEL SISTEMA DE BÚSQUEDA INTELIGENTE")
    print("=" * 50)
    
    # Verificar BD
    if not test_database_connection():
        print("❌ Error crítico: No se puede conectar a la base de datos")
        sys.exit(1)
    
    # Inicializar sistema
    search_system = test_smart_search_initialization()
    if not search_system:
        print("❌ Error crítico: No se pudo inicializar el sistema")
        sys.exit(1)
    
    # Probar búsquedas
    test_search_functionality(search_system)
    
    # Probar respuestas
    test_question_answering(search_system)
    
    print("\n" + "=" * 50)
    print("✅ Pruebas completadas exitosamente")

if __name__ == "__main__":
    main()