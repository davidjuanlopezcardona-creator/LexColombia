#!/bin/bash

# Script de configuración de Cron Jobs para LexColombia Analytics
# Este script configura tareas programadas para generar reportes automáticamente

echo "🚀 Configurando tareas programadas para LexColombia Analytics..."

# Directorio del proyecto
PROJECT_DIR="/workspace/lexcolombia17octubre"
PYTHON_PATH="/usr/bin/python3"

# Crear directorio de logs si no existe
mkdir -p "$PROJECT_DIR/logs"

# Archivo de cron temporal
CRON_FILE="/tmp/lexcolombia_cron"

# Crear el archivo de cron con las tareas programadas
cat > "$CRON_FILE" << EOF
# LexColombia Analytics - Reportes Automáticos
# Generado automáticamente el $(date)

# Reporte diario a las 23:30 todos los días
30 23 * * * cd $PROJECT_DIR && $PYTHON_PATH automated_reports.py --type daily >> logs/cron_daily.log 2>&1

# Reporte semanal los domingos a las 23:45
45 23 * * 0 cd $PROJECT_DIR && $PYTHON_PATH automated_reports.py --type weekly >> logs/cron_weekly.log 2>&1

# Reporte mensual el primer día del mes a las 23:55
55 23 1 * * cd $PROJECT_DIR && $PYTHON_PATH automated_reports.py --type monthly >> logs/cron_monthly.log 2>&1

# Limpieza de archivos antiguos los viernes a las 2:00 AM
0 2 * * 5 cd $PROJECT_DIR && $PYTHON_PATH automated_reports.py --type daily --cleanup >> logs/cron_cleanup.log 2>&1

EOF

echo "📝 Archivo de cron creado:"
cat "$CRON_FILE"

echo ""
echo "⚙️  Para instalar estas tareas programadas, ejecuta:"
echo "   crontab $CRON_FILE"
echo ""
echo "📋 Para ver las tareas programadas actuales:"
echo "   crontab -l"
echo ""
echo "🗑️  Para eliminar todas las tareas programadas:"
echo "   crontab -r"
echo ""

# Preguntar si quiere instalar automáticamente
read -p "¿Quieres instalar las tareas programadas ahora? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    crontab "$CRON_FILE"
    echo "✅ Tareas programadas instaladas exitosamente!"
    echo ""
    echo "📊 Horarios configurados:"
    echo "   - Reporte diario: 23:30 todos los días"
    echo "   - Reporte semanal: 23:45 los domingos"
    echo "   - Reporte mensual: 23:55 el primer día del mes"
    echo "   - Limpieza: 02:00 los viernes"
else
    echo "⏸️  Instalación cancelada. Puedes instalar manualmente con: crontab $CRON_FILE"
fi

echo ""
echo "🔍 Los logs se guardarán en:"
echo "   - $PROJECT_DIR/logs/cron_daily.log"
echo "   - $PROJECT_DIR/logs/cron_weekly.log"
echo "   - $PROJECT_DIR/logs/cron_monthly.log"
echo "   - $PROJECT_DIR/logs/cron_cleanup.log"

# Limpiar archivo temporal
rm -f "$CRON_FILE"

echo ""
echo "✨ Configuración completada!"