#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Colombia Legal - Script de inicio
Punto de entrada principal de la aplicación
"""

import os
import sys
import logging
from logging.config import dictConfig
from config import config, LOGGING_CONFIG

# Configurar logging
dictConfig(LOGGING_CONFIG)
logger = logging.getLogger(__name__)

def create_app(config_name=None):
    """Factory function para crear la aplicación Flask"""
    
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    # Importar la aplicación
    from app import app, init_db, ai_assistant
    
    # Aplicar configuración
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Inicializar bases de datos
    with app.app_context():
        init_db()
        logger.info("Bases de datos inicializadas correctamente")
    
    # Inicializar IA en background
    import threading
    def init_ai():
        try:
            ai_assistant.initialize()
            logger.info("Sistema de IA inicializado correctamente")
        except Exception as e:
            logger.error(f"Error inicializando IA: {e}")
    
    ai_thread = threading.Thread(target=init_ai, daemon=True)
    ai_thread.start()
    
    logger.info(f"Colombia Legal iniciado en modo: {config_name}")
    return app

def main():
    """Función principal para ejecutar la aplicación"""
    
    # Verificar versión de Python
    if sys.version_info < (3, 8):
        print("Error: Se requiere Python 3.8 o superior")
        sys.exit(1)
    
    # Obtener configuración del entorno
    config_name = os.environ.get('FLASK_ENV', 'development')
    host = os.environ.get('FLASK_HOST', '0.0.0.0')
    port = int(os.environ.get('FLASK_PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'True').lower() in ['true', '1', 'yes']
    
    print("""
╔══════════════════════════════════════════════════════════════╗
║                      Colombia Legal                      ║
║          Plataforma de Legislación y Jurisprudencia         ║
║                       Versión 1.0.0                         ║
╠══════════════════════════════════════════════════════════════╣
║ Autores:                                                     ║
║ • Vicente Soto Liemann                                       ║
║ • Juan David Cardona Lopez                                   ║
║ • Sharon Sofia Castellanos Alvares                          ║
║                                                              ║
║ Contacto: 3205214751                                         ║
║ Email: davidjuanlopezcardona@gmail.com                       ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    print(f"🚀 Iniciando Colombia Legal...")
    print(f"📍 Servidor: http://{host}:{port}")
    print(f"🔧 Entorno: {config_name}")
    print(f"🐛 Debug: {'Activado' if debug else 'Desactivado'}")
    print(f"📱 Acceso móvil: Totalmente responsive")
    print(f"🤖 IA Legal: Inicializando en segundo plano...")
    print(f"🎨 Tema: Azul oscuro profesional")
    print(f"⚡ Estado: Iniciando aplicación...\n")
    
    try:
        # Crear aplicación
        app = create_app(config_name)
        
        print("✅ Aplicación inicializada correctamente")
        print("🔍 Sistema de búsqueda: Activo")
        print("💾 Bases de datos: Conectadas")
        print("🎯 Todas las funciones: Disponibles")
        print("\n" + "="*60)
        print("🌐 Colombia Legal está listo para usar!")
        print("="*60 + "\n")
        
        # Ejecutar aplicación
        app.run(
            host=host,
            port=port,
            debug=debug,
            threaded=True
        )
        
    except KeyboardInterrupt:
        print("\n🛑 Aplicación detenida por el usuario")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Error fatal al iniciar la aplicación: {e}")
        print(f"\n❌ Error fatal: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()