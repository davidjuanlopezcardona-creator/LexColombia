#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LexColombia - Configuración de la aplicación
Configuración principal y variables de entorno

"""

import os
from dotenv import load_dotenv

# Cargar variables de entorno desde .env
load_dotenv()

class Config:
    """Configuración base de la aplicación"""
    
    # Configuración básica de Flask
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'lexcolombia_secret_key_2025_desarrollo'
    
    # Configuración de base de datos
    DATABASE_USERS = os.path.join(os.path.dirname(__file__), 'users.db')
    DATABASE_LEGISLATION = os.path.join(os.path.dirname(__file__), 'legislation.db')
    
    # Configuración de archivos
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    
    # Configuración de sesiones
    PERMANENT_SESSION_LIFETIME = 86400  # 24 horas en segundos
    
    # Configuración de seguridad
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600  # 1 hora
    
    # Configuración de la aplicación
    APP_NAME = 'LexColombia'
    APP_VERSION = '1.0.0'
    APP_DESCRIPTION = 'Plataforma integral de consulta de legislación y jurisprudencia colombiana'
    
    # Autores
    AUTHORS = [
        'Vicente Soto Liemann',
        'Juan David Cardona Lopez', 
        'Sharon Sofia Castellanos Alvares'
    ]
    CONTACT_PHONE = '3205214751'
    CONTACT_EMAIL = 'davidjuanlopezcardona@gmail.com'
    
    # Configuración de IA
    AI_MODEL_NAME = os.environ.get('AI_MODEL_NAME') or 'distilbert-base-cased-distilled-squad'
    AI_MAX_CONTEXT_LENGTH = 1000
    AI_MAX_ANSWER_LENGTH = 500
    
    # Configuración de PDF
    PDF_MARGIN = 72  # 1 inch
    PDF_FONT_SIZE = 12
    PDF_LINE_HEIGHT = 14
    
    # Configuración de búsqueda
    SEARCH_RESULTS_PER_PAGE = 20
    SEARCH_MAX_RESULTS = 100
    AUTOCOMPLETE_MAX_RESULTS = 10
    
    # Configuración de cache
    CACHE_TIMEOUT = 300  # 5 minutos
    
    # Rutas de archivos estáticos
    STATIC_FOLDER = 'static'
    TEMPLATE_FOLDER = 'templates'
    
    @staticmethod
    def init_app(app):
        """Inicializar configuración específica de la aplicación"""
        # Crear directorios necesarios
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        
class DevelopmentConfig(Config):
    """Configuración para desarrollo"""
    DEBUG = True
    TESTING = False
    
class ProductionConfig(Config):
    """Configuración para producción"""
    DEBUG = False
    TESTING = False
    
    # Configuración de seguridad adicional para producción
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
class TestingConfig(Config):
    """Configuración para testing"""
    TESTING = True
    DEBUG = True
    WTF_CSRF_ENABLED = False
    
# Diccionario de configuraciones
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

# Configuración de logging
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {
            'format': '[%(asctime)s] %(levelname)s in %(module)s: %(message)s',
        }
    },
    'handlers': {
        'default': {
            'level': 'INFO',
            'formatter': 'default',
            'class': 'logging.StreamHandler',
            'stream': 'ext://sys.stdout'
        }
    },
    'root': {
        'level': 'INFO',
        'handlers': ['default']
    }
}

# Configuración de categorías de documentos
DOCUMENT_CATEGORIES = {
    'Constitución': {
        'icon': 'fas fa-landmark',
        'description': 'Constitución Política de Colombia y normas constitucionales',
        'subcategories': ['Principios Fundamentales', 'Derechos', 'Deberes', 'Organización del Estado']
    },
    'Código Civil': {
        'icon': 'fas fa-balance-scale',
        'description': 'Normas sobre personas, bienes, obligaciones y contratos',
        'subcategories': ['Personas', 'Bienes', 'Obligaciones', 'Contratos', 'Sucesiones']
    },
    'Código Penal': {
        'icon': 'fas fa-gavel',
        'description': 'Delitos, penas y medidas de seguridad',
        'subcategories': ['Delitos contra la vida', 'Delitos contra el patrimonio', 'Delitos contra la administración']
    },
    'Código de Comercio': {
        'icon': 'fas fa-chart-line',
        'description': 'Normas sobre actividades mercantiles y empresariales',
        'subcategories': ['Actos de comercio', 'Sociedades', 'Títulos valores', 'Contratos mercantiles']
    },
    'Código Laboral': {
        'icon': 'fas fa-briefcase',
        'description': 'Relaciones de trabajo y seguridad social',
        'subcategories': ['Contrato de trabajo', 'Salarios', 'Prestaciones', 'Riesgos laborales']
    },
    'Procedimiento Civil': {
        'icon': 'fas fa-file-contract',
        'description': 'Normas procesales civiles',
        'subcategories': ['Proceso ordinario', 'Procesos especiales', 'Medidas cautelares']
    },
    'Procedimiento Penal': {
        'icon': 'fas fa-shield-alt',
        'description': 'Normas procesales penales',
        'subcategories': ['Investigación', 'Juzgamiento', 'Recursos']
    },
    'Administrativo': {
        'icon': 'fas fa-building',
        'description': 'Organización y funcionamiento del Estado',
        'subcategories': ['Función pública', 'Contratación estatal', 'Régimen disciplinario']
    },
    'Tributario': {
        'icon': 'fas fa-calculator',
        'description': 'Normas fiscales y tributarias',
        'subcategories': ['Impuesto de renta', 'IVA', 'Procedimiento tributario']
    },
    'Familia': {
        'icon': 'fas fa-home',
        'description': 'Normas sobre relaciones familiares',
        'subcategories': ['Matrimonio', 'Divorcio', 'Filiación', 'Alimentos']
    }
}

# Configuración de tipos de documentos
DOCUMENT_TYPES = {
    'Constitución': {
        'prefix': 'Art.',
        'color': '#dc2626'
    },
    'Ley': {
        'prefix': 'Ley',
        'color': '#2563eb'
    },
    'Decreto': {
        'prefix': 'Decreto',
        'color': '#059669'
    },
    'Resolución': {
        'prefix': 'Resolución',
        'color': '#d97706'
    },
    'Sentencia': {
        'prefix': 'Sentencia',
        'color': '#7c3aed'
    },
    'Auto': {
        'prefix': 'Auto',
        'color': '#dc2626'
    },
    'Concepto': {
        'prefix': 'Concepto',
        'color': '#0891b2'
    },
    'Circular': {
        'prefix': 'Circular',
        'color': '#be185d'
    }
}

# Configuración de colores del tema
THEME_COLORS = {
    'primary': '#1e3a8a',
    'primary_dark': '#1e40af',
    'primary_light': '#3b82f6',
    'secondary': '#64748b',
    'accent': '#f59e0b',
    'success': '#10b981',
    'error': '#ef4444',
    'warning': '#f59e0b',
    'info': '#3b82f6'
}

# Mensajes de la aplicación
MESSAGES = {
    'welcome': '¡Bienvenido/a a LexColombia!',
    'login_success': 'Inicio de sesión exitoso',
    'login_error': 'Credenciales incorrectas',
    'register_success': 'Registro exitoso. Por favor inicia sesión.',
    'register_error': 'Error en el registro. Intenta de nuevo.',
    'logout_success': 'Has cerrado sesión correctamente',
    'favorite_added': 'Documento añadido a favoritos',
    'favorite_removed': 'Documento eliminado de favoritos',
    'search_no_results': 'No se encontraron resultados para tu búsqueda',
    'ai_not_available': 'El asistente de IA no está disponible en este momento',
    'ai_error': 'Error al procesar la pregunta'
}

# Configuración de meta tags para SEO
SEO_CONFIG = {
    'title': 'LexColombia - Legislación y Jurisprudencia de Colombia',
    'description': 'Plataforma integral para consultar toda la legislación y jurisprudencia colombiana. Acceso completo a leyes, decretos, códigos y normatividad con búsqueda inteligente y asistente de IA.',
    'keywords': 'legislación colombia, jurisprudencia, leyes colombia, código civil, código penal, constitución colombia, normatividad, legal colombia',
    'author': 'Vicente Soto Liemann, Juan David Cardona Lopez, Sharon Sofia Castellanos Alvares',
    'robots': 'index, follow',
    'og_type': 'website',
    'og_locale': 'es_CO'
}