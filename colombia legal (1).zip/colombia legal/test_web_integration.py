#!/usr/bin/env python3
"""
Prueba rápida del servidor web con búsqueda inteligente
"""

from flask import Flask
import sqlite3
import json
import sys
import os

# Simular las funciones del app.py
def test_web_endpoints():
    """Prueba los endpoints principales del app.py modificado"""
    
    # Importar la clase SmartSearch
    sys.path.append('/workspace/extracted_documents')
    from app import SmartSearch
    
    print("🌐 PRUEBA DE INTEGRACIÓN WEB")
    print("=" * 40)
    
    # Inicializar sistema
    search_system = SmartSearch()
    success = search_system.initialize()
    
    if not success:
        print("❌ Error: No se pudo inicializar el sistema")
        return False
    
    print("✅ Sistema inicializado para prueba web")
    
    # Simular endpoint de búsqueda
    print("\n🔍 Simulando endpoint /search...")
    test_queries = ["constitución", "código civil", "decreto"]
    
    for query in test_queries:
        results = search_system.search_documents(query, max_results=3)
        print(f"\nConsulta: '{query}' -> {len(results)} resultados")
        
        if results:
            for doc in results[:2]:  # Mostrar solo 2 resultados
                print(f"  - {doc['title']} (Score: {doc['score_percentage']}%)")
    
    # Simular endpoint de AI chat
    print("\n🤖 Simulando endpoint /ai_chat...")
    test_question = "¿Qué es una constitución?"
    answer = search_system.answer_question(test_question)
    print(f"Pregunta: {test_question}")
    print(f"Respuesta: {answer[:150]}...")
    
    return True

def check_app_syntax():
    """Verifica que el app.py no tenga errores de sintaxis"""
    print("\n📝 Verificando sintaxis de app.py...")
    
    try:
        import ast
        with open('/workspace/extracted_documents/app.py', 'r') as f:
            code = f.read()
        
        ast.parse(code)
        print("✅ Sintaxis de app.py correcta")
        return True
        
    except SyntaxError as e:
        print(f"❌ Error de sintaxis en app.py: {e}")
        return False
    except Exception as e:
        print(f"❌ Error leyendo app.py: {e}")
        return False

def main():
    # Verificar sintaxis
    if not check_app_syntax():
        return False
    
    # Prueba de integración
    if not test_web_endpoints():
        return False
    
    print("\n" + "=" * 40)
    print("✅ INTEGRACIÓN WEB EXITOSA")
    print("\n📋 RESUMEN DE MEJORAS IMPLEMENTADAS:")
    print("• ✅ Reemplazada IA pesada (transformers) por búsqueda inteligente")
    print("• ✅ Implementado TF-IDF para búsqueda semántica")
    print("• ✅ Sistema de scoring con porcentajes de relevancia")
    print("• ✅ Respuesta a preguntas en español optimizada")
    print("• ✅ Fallback a búsqueda básica si falla la inteligente")
    print("• ✅ Normalización de texto para mejor matching")
    print("• ✅ Detección de tipos de pregunta")
    print("• ✅ Extracción de fragmentos relevantes")
    
    print("\n🚀 La aplicación está lista para usar!")
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)