#!/usr/bin/env python3
"""
Script de prueba para el Sistema de Analytics de LexColombia
Verifica que todas las funcionalidades funcionen correctamente
"""

import os
import sys
import json
import sqlite3
import time
from datetime import datetime, timedelta

# Agregar el directorio del proyecto al path
sys.path.append(os.path.dirname(__file__))

from analytics_system import AnalyticsSystem
from automated_reports import AutomatedReportingSystem

def test_analytics_system():
    """Probar el sistema de analytics"""
    print("🧪 === PRUEBAS DEL SISTEMA DE ANALYTICS ===\n")
    
    # Inicializar sistema
    analytics = AnalyticsSystem('legislation.db')
    
    print("✅ Sistema de analytics inicializado")
    
    # Verificar que las tablas se crearon
    conn = sqlite3.connect('legislation.db')
    cursor = conn.cursor()
    
    # Verificar tablas de analytics
    tables_to_check = ['user_activity', 'search_metrics', 'document_metrics', 'daily_stats']
    
    for table in tables_to_check:
        cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
        if cursor.fetchone():
            print(f"✅ Tabla {table} existe")
        else:
            print(f"❌ Tabla {table} NO existe")
    
    conn.close()
    
    # Generar datos de prueba
    print("\n📊 Generando datos de prueba...")
    
    # Simular actividad de usuario
    test_users = [
        (1, 'admin'),
        (2, 'user1'),
        (3, 'user2')
    ]
    
    # Simular búsquedas
    test_searches = [
        'Constitución Política',
        'Código Civil',
        'Derechos Fundamentales',
        'Habeas Corpus',
        'Procedimiento Penal'
    ]
    
    # Simular actividad de los últimos días
    for day_offset in range(7):
        test_date = datetime.now() - timedelta(days=day_offset)
        
        for user_id, username in test_users:
            # Simular login
            analytics.log_user_activity(
                user_id=user_id,
                username=username,
                action_type='login',
                details={'test_data': True},
                ip_address='127.0.0.1',
                user_agent='Test User Agent'
            )
            
            # Simular búsquedas
            for i, search_term in enumerate(test_searches[:3]):  # 3 búsquedas por usuario
                search_duration = 100 + (i * 50)  # Simular diferentes duraciones
                
                analytics.log_search(
                    user_id=user_id,
                    search_query=search_term,
                    category_filter='Constitución Política' if i == 0 else '',
                    results_count=5 + i,
                    search_duration_ms=search_duration
                )
                
                # Simular visualización de documento
                analytics.log_document_view(
                    document_id=i + 1,
                    user_id=user_id,
                    action='view',
                    time_spent_seconds=30 + (i * 10)
                )
    
    print("✅ Datos de prueba generados")
    
    # Probar métricas del dashboard
    print("\n📈 Probando métricas del dashboard...")
    
    metrics = analytics.get_dashboard_metrics(days=7)
    
    print(f"   - Usuarios únicos: {metrics['unique_users']}")
    print(f"   - Búsquedas totales: {metrics['total_searches']}")
    print(f"   - Visualizaciones de documentos: {metrics['total_document_views']}")
    print(f"   - Actividades totales: {metrics['total_activities']}")
    print(f"   - Top búsquedas: {len(metrics['top_searches'])}")
    print(f"   - Top documentos: {len(metrics['top_documents'])}")
    print(f"   - Actividad diaria: {len(metrics['daily_activity'])}")
    
    print("✅ Métricas del dashboard funcionando")
    
    return analytics

def test_reporting_system():
    """Probar el sistema de reportes"""
    print("\n📄 === PRUEBAS DEL SISTEMA DE REPORTES ===\n")
    
    reporting = AutomatedReportingSystem('legislation.db')
    
    print("✅ Sistema de reportes inicializado")
    
    # Probar generación de reporte diario
    print("\n📅 Generando reporte diario de prueba...")
    daily_result = reporting.generate_daily_report()
    
    if daily_result['success']:
        print(f"✅ Reporte diario generado: {daily_result['report_file']}")
        print(f"✅ Resumen HTML generado: {daily_result['html_file']}")
    else:
        print(f"❌ Error en reporte diario: {daily_result['error']}")
    
    # Probar generación de reporte semanal
    print("\n📊 Generando reporte semanal de prueba...")
    weekly_result = reporting.generate_weekly_report()
    
    if weekly_result['success']:
        print(f"✅ Reporte semanal generado: {weekly_result['report_file']}")
        print(f"✅ Resumen HTML generado: {weekly_result['html_file']}")
    else:
        print(f"❌ Error en reporte semanal: {weekly_result['error']}")
    
    return reporting

def test_performance():
    """Probar rendimiento del sistema"""
    print("\n⚡ === PRUEBAS DE RENDIMIENTO ===\n")
    
    analytics = AnalyticsSystem('legislation.db')
    
    # Probar velocidad de inserción de logs
    print("🏃 Probando velocidad de inserción de logs...")
    
    start_time = time.time()
    
    for i in range(100):
        analytics.log_user_activity(
            user_id=999,
            username='test_performance',
            action_type='performance_test',
            details={'iteration': i},
            ip_address='127.0.0.1',
            user_agent='Performance Test'
        )
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"✅ 100 logs insertados en {duration:.2f} segundos")
    print(f"   Velocidad: {100/duration:.1f} logs/segundo")
    
    # Probar velocidad de consulta de métricas
    print("\n📊 Probando velocidad de consulta de métricas...")
    
    start_time = time.time()
    metrics = analytics.get_dashboard_metrics(days=30)
    end_time = time.time()
    
    duration = end_time - start_time
    print(f"✅ Métricas consultadas en {duration:.3f} segundos")

def verify_database_structure():
    """Verificar estructura de la base de datos"""
    print("\n🔍 === VERIFICACIÓN DE BASE DE DATOS ===\n")
    
    conn = sqlite3.connect('legislation.db')
    cursor = conn.cursor()
    
    # Verificar tablas principales
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    
    print("📋 Tablas encontradas:")
    for table in tables:
        table_name = table[0]
        
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        
        print(f"   - {table_name}: {count} registros")
    
    # Verificar estructura de tablas de analytics
    analytics_tables = ['user_activity', 'search_metrics', 'document_metrics', 'daily_stats']
    
    print("\n🏗️  Estructura de tablas de analytics:")
    for table in analytics_tables:
        try:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = cursor.fetchall()
            print(f"\n   {table}:")
            for col in columns:
                print(f"     - {col[1]} ({col[2]})")
        except sqlite3.OperationalError:
            print(f"   ❌ Tabla {table} no existe")
    
    conn.close()

def main():
    """Función principal de pruebas"""
    print("🚀 INICIANDO PRUEBAS DEL SISTEMA DE ANALYTICS DE LEXCOLOMBIA")
    print("=" * 60)
    
    # Cambiar al directorio correcto
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    try:
        # Verificar estructura de base de datos
        verify_database_structure()
        
        # Probar sistema de analytics
        analytics = test_analytics_system()
        
        # Probar sistema de reportes
        reporting = test_reporting_system()
        
        # Probar rendimiento
        test_performance()
        
        print("\n🎉 === TODAS LAS PRUEBAS COMPLETADAS ===")
        print("✅ Sistema de analytics funcionando correctamente")
        print("✅ Sistema de reportes funcionando correctamente")
        print("✅ Rendimiento dentro de parámetros esperados")
        
        print("\n📁 Archivos generados:")
        print("   - reports/: Reportes JSON y HTML")
        print("   - logs/: Logs del sistema")
        
        print("\n🌐 Para probar la interfaz web:")
        print("   1. Ejecuta: python app.py")
        print("   2. Accede a: http://localhost:5000/analytics")
        print("   3. Inicia sesión con usuario admin (ID=1)")
        
    except Exception as e:
        print(f"\n❌ ERROR EN LAS PRUEBAS: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()