// LexColombia - JavaScript Principal
// Funcionalidades principales de la aplicación

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Inicializar componentes principales
    initializeTheme();
    initializeMobileMenu();
    initializeAIChat();
    initializeNotifications();
    initializeAnimations();
    initializeVoiceSearch();
    
    // Auto-close flash messages
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            if (alert.parentElement) {
                alert.style.animation = 'slideInRight 0.3s ease-out reverse';
                setTimeout(() => alert.remove(), 300);
            }
        });
    }, 5000);
    
    console.log('LexColombia initialized successfully');
}

// ===== THEME MANAGEMENT =====
function initializeTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    const body = document.body;
    
    // Load saved theme
    const savedTheme = localStorage.getItem('lexcolombia-theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        if (themeIcon) themeIcon.className = 'fas fa-sun';
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

function toggleTheme() {
    const body = document.body;
    const themeIcon = document.getElementById('themeIcon');
    
    body.classList.toggle('dark-theme');
    const isDark = body.classList.contains('dark-theme');
    
    // Update icon
    if (themeIcon) {
        themeIcon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    // Save preference
    localStorage.setItem('lexcolombia-theme', isDark ? 'dark' : 'light');
    
    // Show notification
    showNotification(
        `Tema ${isDark ? 'oscuro' : 'claro'} activado`,
        'info'
    );
}

// ===== VOICE SEARCH SYSTEM =====
let isListening = false;
let recognition = null;
let voiceSearchTimeout = null;

function initializeVoiceSearch() {
    // Check for Web Speech API support
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        console.log('Speech recognition not supported');
        // Hide voice search buttons if not supported
        const voiceButtons = document.querySelectorAll('.voice-search-btn, .ai-chat-voice');
        voiceButtons.forEach(btn => btn.style.display = 'none');
        return;
    }

    // Initialize speech recognition
    recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'es-CO'; // Colombian Spanish

    // Main search voice button
    const voiceSearchBtn = document.getElementById('voiceSearchBtn');
    const voiceSearchFeedback = document.getElementById('voiceSearchFeedback');
    const voiceTranscript = document.getElementById('voiceTranscript');
    const voiceCancelBtn = document.getElementById('voiceCancelBtn');
    const voiceConfirmBtn = document.getElementById('voiceConfirmBtn');

    // AI Chat voice button
    const aiChatVoice = document.getElementById('aiChatVoice');

    if (voiceSearchBtn) {
        voiceSearchBtn.addEventListener('click', () => startVoiceSearch('main'));
    }

    if (aiChatVoice) {
        aiChatVoice.addEventListener('click', () => startVoiceSearch('ai'));
    }

    if (voiceCancelBtn) {
        voiceCancelBtn.addEventListener('click', stopVoiceSearch);
    }

    if (voiceConfirmBtn) {
        voiceConfirmBtn.addEventListener('click', () => {
            const transcript = voiceTranscript?.textContent.trim();
            if (transcript) {
                executeVoiceSearch(transcript, 'main');
            }
            stopVoiceSearch();
        });
    }

    // Speech recognition event handlers
    recognition.onstart = function() {
        isListening = true;
        updateVoiceUI(true);
        console.log('Voice recognition started');
    };

    recognition.onresult = function(event) {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }

        // Update transcript display
        if (voiceTranscript) {
            voiceTranscript.textContent = finalTranscript + interimTranscript;
        }

        // Auto-search after 2 seconds of silence with final result
        if (finalTranscript) {
            clearTimeout(voiceSearchTimeout);
            voiceSearchTimeout = setTimeout(() => {
                if (finalTranscript.trim()) {
                    executeVoiceSearch(finalTranscript.trim(), getCurrentVoiceSearchType());
                    stopVoiceSearch();
                }
            }, 2000);
        }
    };

    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        let errorMessage = 'Error en el reconocimiento de voz';
        
        switch(event.error) {
            case 'no-speech':
                errorMessage = 'No se detectó voz. Intenta de nuevo.';
                break;
            case 'audio-capture':
                errorMessage = 'No se puede acceder al micrófono.';
                break;
            case 'not-allowed':
                errorMessage = 'Permiso de micrófono denegado.';
                break;
            case 'network':
                errorMessage = 'Error de conexión. Verifica tu internet.';
                break;
        }
        
        showNotification(errorMessage, 'error');
        stopVoiceSearch();
    };

    recognition.onend = function() {
        isListening = false;
        updateVoiceUI(false);
        console.log('Voice recognition ended');
    };
}

let currentVoiceSearchType = 'main';

function getCurrentVoiceSearchType() {
    return currentVoiceSearchType;
}

function startVoiceSearch(type = 'main') {
    if (!recognition) {
        showNotification('Reconocimiento de voz no disponible', 'error');
        return;
    }

    if (isListening) {
        stopVoiceSearch();
        return;
    }

    currentVoiceSearchType = type;

    // Request microphone permission and start recognition
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(() => {
            // Clear previous transcript
            const voiceTranscript = document.getElementById('voiceTranscript');
            if (voiceTranscript) {
                voiceTranscript.textContent = '';
            }

            // Show feedback for main search
            if (type === 'main') {
                const voiceSearchFeedback = document.getElementById('voiceSearchFeedback');
                if (voiceSearchFeedback) {
                    voiceSearchFeedback.classList.add('active');
                }
            }

            recognition.start();
            showNotification('Escuchando... Habla ahora', 'info');
        })
        .catch((error) => {
            console.error('Microphone access denied:', error);
            showNotification('No se puede acceder al micrófono. Verifica los permisos.', 'error');
        });
}

function stopVoiceSearch() {
    if (recognition && isListening) {
        recognition.stop();
    }
    
    isListening = false;
    updateVoiceUI(false);
    
    // Hide feedback
    const voiceSearchFeedback = document.getElementById('voiceSearchFeedback');
    if (voiceSearchFeedback) {
        voiceSearchFeedback.classList.remove('active');
    }

    clearTimeout(voiceSearchTimeout);
}

function updateVoiceUI(listening) {
    // Update main search button
    const voiceSearchBtn = document.getElementById('voiceSearchBtn');
    const voiceSearchIcon = document.getElementById('voiceSearchIcon');
    
    if (voiceSearchBtn && voiceSearchIcon) {
        if (listening) {
            voiceSearchBtn.classList.add('listening');
            voiceSearchIcon.className = 'fas fa-stop';
            voiceSearchBtn.title = 'Detener grabación';
        } else {
            voiceSearchBtn.classList.remove('listening');
            voiceSearchIcon.className = 'fas fa-microphone';
            voiceSearchBtn.title = 'Búsqueda por voz';
        }
    }

    // Update AI chat button
    const aiChatVoice = document.getElementById('aiChatVoice');
    if (aiChatVoice) {
        if (listening) {
            aiChatVoice.classList.add('listening');
            aiChatVoice.querySelector('i').className = 'fas fa-stop';
            aiChatVoice.title = 'Detener grabación';
        } else {
            aiChatVoice.classList.remove('listening');
            aiChatVoice.querySelector('i').className = 'fas fa-microphone';
            aiChatVoice.title = 'Búsqueda por voz';
        }
    }
}

function executeVoiceSearch(transcript, type) {
    if (!transcript.trim()) return;

    if (type === 'ai') {
        // Insert transcript into AI chat input
        const aiChatInput = document.getElementById('aiChatInput');
        if (aiChatInput) {
            aiChatInput.value = transcript;
            aiChatInput.style.height = 'auto';
            aiChatInput.style.height = aiChatInput.scrollHeight + 'px';
            
            // Update character count
            const characterCount = document.getElementById('characterCount');
            if (characterCount) {
                characterCount.textContent = `${transcript.length}/1000`;
            }
            
            // Send the message automatically
            sendAIMessage();
        }
    } else {
        // Execute main search
        const quickSearchInput = document.getElementById('quickSearchInput');
        if (quickSearchInput) {
            quickSearchInput.value = transcript;
            
            // Trigger search
            const event = new Event('submit', { bubbles: true, cancelable: true });
            const form = quickSearchInput.closest('form');
            if (form) {
                form.dispatchEvent(event);
            } else {
                // Manual search trigger
                performQuickSearch(transcript);
            }
        }
    }

    showNotification(`Búsqueda ejecutada: "${transcript}"`, 'success');
}

function performQuickSearch(query) {
    if (!query.trim()) return;
    
    // Redirect to search page with query
    window.location.href = `/search?q=${encodeURIComponent(query.trim())}`;
}

// ===== MOBILE MENU =====
function initializeMobileMenu() {
    const mobileToggle = document.getElementById('mobileMenuToggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileToggle && navLinks) {
        mobileToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            const icon = this.querySelector('i');
            icon.className = navLinks.classList.contains('active') 
                ? 'fas fa-times' 
                : 'fas fa-bars';
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!mobileToggle.contains(e.target) && !navLinks.contains(e.target)) {
                navLinks.classList.remove('active');
                mobileToggle.querySelector('i').className = 'fas fa-bars';
            }
        });
    }
}

// ===== AI CHAT SYSTEM =====
let aiChatActive = false;
let isAITyping = false;
let aiChatHistory = [];
let currentChatId = null;
let historyPanelActive = false;

function initializeAIChat() {
    const aiToggle = document.getElementById('aiChatToggle');
    const aiFullscreen = document.getElementById('aiChatFullscreen');
    const aiOverlay = document.getElementById('aiChatOverlay');
    const aiClose = document.getElementById('aiChatClose');
    const aiMinimize = document.getElementById('aiChatMinimize');
    const aiHistoryToggle = document.getElementById('aiChatHistoryToggle');
    const aiHistoryClear = document.getElementById('aiChatHistoryClear');
    const aiInput = document.getElementById('aiChatInput');
    const aiSend = document.getElementById('aiChatSend');
    const aiAttach = document.getElementById('aiChatAttach');
    
    // Load chat history from localStorage
    loadChatHistory();
    
    if (aiToggle) {
        aiToggle.addEventListener('click', openAIChat);
    }
    
    if (aiOverlay) {
        aiOverlay.addEventListener('click', closeAIChat);
    }
    
    if (aiClose) {
        aiClose.addEventListener('click', closeAIChat);
    }
    
    if (aiMinimize) {
        aiMinimize.addEventListener('click', minimizeAIChat);
    }
    
    if (aiHistoryToggle) {
        aiHistoryToggle.addEventListener('click', toggleHistoryPanel);
    }
    
    if (aiHistoryClear) {
        aiHistoryClear.addEventListener('click', clearChatHistory);
    }
    
    if (aiInput) {
        // Auto-resize textarea
        aiInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
            
            // Update character count
            const characterCount = document.getElementById('characterCount');
            if (characterCount) {
                characterCount.textContent = `${this.value.length}/1000`;
            }
        });
        
        aiInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendAIMessage();
            }
        });
    }
    
    if (aiSend) {
        aiSend.addEventListener('click', sendAIMessage);
    }
    
    if (aiAttach) {
        aiAttach.addEventListener('click', function() {
            showNotification('Función de adjuntar archivos próximamente disponible', 'info');
        });
    }
    
    // ESC key to close
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && aiChatActive) {
            closeAIChat();
        }
    });
}

function openAIChat() {
    const aiFullscreen = document.getElementById('aiChatFullscreen');
    const aiInput = document.getElementById('aiChatInput');
    
    if (aiFullscreen) {
        aiFullscreen.classList.add('active');
        aiChatActive = true;
        document.body.style.overflow = 'hidden';
        
        // Focus input after animation
        setTimeout(() => {
            if (aiInput) {
                aiInput.focus();
            }
        }, 300);
        
        // Start new conversation if none exists
        if (!currentChatId) {
            startNewConversation();
        }
        
        // Update history panel
        updateHistoryPanel();
    }
}

function closeAIChat() {
    const aiFullscreen = document.getElementById('aiChatFullscreen');
    
    if (aiFullscreen) {
        aiFullscreen.classList.remove('active');
        aiChatActive = false;
        document.body.style.overflow = '';
        
        // Save current conversation
        saveCurrentConversation();
    }
}

function minimizeAIChat() {
    // In a real app, this would minimize to taskbar
    // For now, we'll just close it
    closeAIChat();
    showNotification('Chat minimizado', 'info');
}

function toggleHistoryPanel() {
    const historyPanel = document.getElementById('aiChatHistoryPanel');
    const historyToggle = document.getElementById('aiChatHistoryToggle');
    
    if (historyPanel && historyToggle) {
        historyPanelActive = !historyPanelActive;
        
        if (historyPanelActive) {
            historyPanel.classList.add('active');
            historyToggle.style.background = 'rgba(255, 255, 255, 0.3)';
        } else {
            historyPanel.classList.remove('active');
            historyToggle.style.background = 'rgba(255, 255, 255, 0.1)';
        }
        
        updateHistoryPanel();
    }
}

function startNewConversation() {
    currentChatId = 'chat_' + Date.now();
    const messagesContainer = document.getElementById('aiChatMessages');
    
    if (messagesContainer) {
        // Clear messages except welcome message
        const welcomeMessage = messagesContainer.querySelector('.ai-welcome-message');
        messagesContainer.innerHTML = '';
        if (welcomeMessage) {
            messagesContainer.appendChild(welcomeMessage);
        }
    }
}

function sendAIMessage() {
    const aiInput = document.getElementById('aiChatInput');
    const aiSend = document.getElementById('aiChatSend');
    
    if (!aiInput || isAITyping) return;
    
    const message = aiInput.value.trim();
    if (!message) return;
    
    // Add user message
    addUserMessage(message);
    aiInput.value = '';
    aiInput.style.height = 'auto';
    
    // Update character count
    const characterCount = document.getElementById('characterCount');
    if (characterCount) {
        characterCount.textContent = '0/1000';
    }
    
    // Disable input while processing
    aiInput.disabled = true;
    aiSend.disabled = true;
    isAITyping = true;
    
    // Add typing indicator
    addTypingIndicator();
    
    // Send to backend
    fetch('/ai_chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question: message })
    })
    .then(response => response.json())
    .then(data => {
        removeTypingIndicator();
        
        if (data.success) {
            addAIMessage(data.answer);
        } else {
            addAIMessage('Lo siento, no pude procesar tu pregunta en este momento. Por favor, intenta de nuevo.');
        }
        
        // Save conversation to history
        saveCurrentConversation();
    })
    .catch(error => {
        console.error('Error:', error);
        removeTypingIndicator();
        addAIMessage('Disculpa, hay un problema de conexión. Por favor, intenta de nuevo más tarde.');
    })
    .finally(() => {
        // Re-enable input
        aiInput.disabled = false;
        aiSend.disabled = false;
        isAITyping = false;
        aiInput.focus();
    });
}

function addUserMessage(message) {
    const messagesContainer = document.getElementById('aiChatMessages');
    if (!messagesContainer) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'user-message';
    messageDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div class="message-content">${escapeHtml(message)}</div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    scrollToBottom(messagesContainer);
}

function addAIMessage(message) {
    const messagesContainer = document.getElementById('aiChatMessages');
    if (!messagesContainer) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'ai-message';
    messageDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content">${escapeHtml(message)}</div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    scrollToBottom(messagesContainer);
}

function addTypingIndicator() {
    const messagesContainer = document.getElementById('aiChatMessages');
    if (!messagesContainer) return;
    
    const typingDiv = document.createElement('div');
    typingDiv.className = 'ai-message typing-indicator';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content">
            <span class="typing-dots">
                <span></span><span></span><span></span>
            </span>
            Escribiendo...
        </div>
    `;
    
    messagesContainer.appendChild(typingDiv);
    scrollToBottom(messagesContainer);
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function scrollToBottom(container) {
    setTimeout(() => {
        container.scrollTop = container.scrollHeight;
    }, 100);
}

// ===== CHAT HISTORY MANAGEMENT =====
function loadChatHistory() {
    const savedHistory = localStorage.getItem('lexcolombia-ai-history');
    if (savedHistory) {
        try {
            aiChatHistory = JSON.parse(savedHistory);
        } catch (e) {
            console.error('Error loading chat history:', e);
            aiChatHistory = [];
        }
    }
}

function saveChatHistory() {
    localStorage.setItem('lexcolombia-ai-history', JSON.stringify(aiChatHistory));
}

function saveCurrentConversation() {
    if (!currentChatId) return;
    
    const messagesContainer = document.getElementById('aiChatMessages');
    if (!messagesContainer) return;
    
    const messages = [];
    const messageElements = messagesContainer.querySelectorAll('.ai-message:not(.typing-indicator), .user-message');
    
    messageElements.forEach(element => {
        const isUser = element.classList.contains('user-message');
        const content = element.querySelector('.message-content').textContent.trim();
        
        if (content && !element.querySelector('.ai-welcome-message')) {
            messages.push({
                type: isUser ? 'user' : 'ai',
                content: content,
                timestamp: new Date().toISOString()
            });
        }
    });
    
    if (messages.length === 0) return;
    
    // Find existing conversation or create new one
    let conversation = aiChatHistory.find(chat => chat.id === currentChatId);
    
    if (!conversation) {
        // Create new conversation
        const firstUserMessage = messages.find(m => m.type === 'user');
        const title = firstUserMessage ? 
            firstUserMessage.content.slice(0, 50) + (firstUserMessage.content.length > 50 ? '...' : '') :
            'Nueva conversación';
        
        conversation = {
            id: currentChatId,
            title: title,
            messages: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        aiChatHistory.unshift(conversation);
    }
    
    // Update conversation
    conversation.messages = messages;
    conversation.updatedAt = new Date().toISOString();
    
    // Keep only last 50 conversations
    if (aiChatHistory.length > 50) {
        aiChatHistory = aiChatHistory.slice(0, 50);
    }
    
    saveChatHistory();
    updateHistoryPanel();
}

function updateHistoryPanel() {
    const historyList = document.getElementById('aiChatHistoryList');
    if (!historyList) return;
    
    historyList.innerHTML = '';
    
    if (aiChatHistory.length === 0) {
        historyList.innerHTML = `
            <div style="text-align: center; padding: 2rem; color: var(--text-secondary);">
                <i class="fas fa-comments" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                <p>No hay conversaciones aún</p>
                <p style="font-size: 0.75rem;">Inicia una nueva conversación para ver el historial aquí</p>
            </div>
        `;
        return;
    }
    
    aiChatHistory.forEach((chat, index) => {
        const historyItem = document.createElement('div');
        historyItem.className = 'ai-chat-history-item';
        if (chat.id === currentChatId) {
            historyItem.classList.add('active');
        }
        
        const lastMessage = chat.messages[chat.messages.length - 1];
        const date = new Date(chat.updatedAt).toLocaleDateString('es-ES', {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        historyItem.innerHTML = `
            <div class="ai-chat-history-item-title">${escapeHtml(chat.title)}</div>
            <div class="ai-chat-history-item-preview">${escapeHtml(lastMessage ? lastMessage.content : 'Sin mensajes')}</div>
            <div class="ai-chat-history-item-date">${date}</div>
        `;
        
        historyItem.addEventListener('click', () => loadConversation(chat.id));
        historyList.appendChild(historyItem);
    });
}

function loadConversation(chatId) {
    const conversation = aiChatHistory.find(chat => chat.id === chatId);
    if (!conversation) return;
    
    currentChatId = chatId;
    const messagesContainer = document.getElementById('aiChatMessages');
    
    if (messagesContainer) {
        // Clear current messages
        messagesContainer.innerHTML = '';
        
        // Add welcome message
        const welcomeDiv = document.createElement('div');
        welcomeDiv.className = 'ai-welcome-message';
        welcomeDiv.innerHTML = `
            <div class="ai-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="ai-message-content">
                <h3>Conversación del ${new Date(conversation.createdAt).toLocaleDateString('es-ES')}</h3>
                <p>Continuando conversación anterior...</p>
            </div>
        `;
        messagesContainer.appendChild(welcomeDiv);
        
        // Load conversation messages
        conversation.messages.forEach(message => {
            if (message.type === 'user') {
                addUserMessage(message.content);
            } else {
                addAIMessage(message.content);
            }
        });
    }
    
    updateHistoryPanel();
}

function clearChatHistory() {
    if (confirm('¿Estás seguro de que deseas borrar todo el historial de conversaciones?')) {
        aiChatHistory = [];
        saveChatHistory();
        updateHistoryPanel();
        
        // Start new conversation
        startNewConversation();
        
        showNotification('Historial de conversaciones borrado', 'success');
    }
}

// ===== NOTIFICATIONS =====
let notificationTimeout;

function initializeNotifications() {
    // Clear any existing notifications on page load
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
}

function showNotification(message, type = 'info', duration = 5000) {
    // Clear existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icon = getNotificationIcon(type);
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <i class="${icon}"></i>
            <span>${escapeHtml(message)}</span>
        </div>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; cursor: pointer; opacity: 0.7; margin-left: 1rem;">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after duration
    if (duration > 0) {
        clearTimeout(notificationTimeout);
        notificationTimeout = setTimeout(() => {
            if (notification.parentElement) {
                notification.style.animation = 'slideInLeft 0.3s ease-out reverse';
                setTimeout(() => notification.remove(), 300);
            }
        }, duration);
    }
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'fas fa-check-circle';
        case 'error': return 'fas fa-exclamation-circle';
        case 'warning': return 'fas fa-exclamation-triangle';
        case 'info': 
        default: return 'fas fa-info-circle';
    }
}

// ===== ANIMATIONS =====
function initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements with animation classes
    const animatedElements = document.querySelectorAll(
        '.feature-card, .stat-item, .category-card, .result-card, .favorite-card'
    );
    
    animatedElements.forEach(el => {
        observer.observe(el);
    });
    
    // Add stagger delay to grid items
    const gridItems = document.querySelectorAll('.features-grid .feature-card, .categories-grid .category-card');
    gridItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.1}s`;
    });
}

// ===== SEARCH FUNCTIONALITY =====
function initializeSearch() {
    const searchInputs = document.querySelectorAll('#searchInput, #quickSearchInput, #searchFavorites');
    
    searchInputs.forEach(input => {
        if (input) {
            // Add search icon animation on focus
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('search-focused');
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('search-focused');
            });
        }
    });
}

// ===== UTILITIES =====
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// ===== PASSWORD STRENGTH INDICATOR =====
function createPasswordStrengthIndicator(passwordInput, strengthContainer) {
    if (!passwordInput || !strengthContainer) return;
    
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        const strength = calculatePasswordStrength(password);
        updatePasswordStrengthDisplay(strengthContainer, strength);
    });
}

function calculatePasswordStrength(password) {
    let score = 0;
    const checks = {
        length: password.length >= 8,
        lowercase: /[a-z]/.test(password),
        uppercase: /[A-Z]/.test(password),
        numbers: /\d/.test(password),
        special: /[!@#$%^&*(),.?\":{}|<>]/.test(password)
    };
    
    score = Object.values(checks).filter(Boolean).length;
    
    let level = 'weak';
    if (score >= 4) level = 'strong';
    else if (score >= 3) level = 'medium';
    
    return { score, level, checks };
}

function updatePasswordStrengthDisplay(container, strength) {
    const colors = {
        weak: '#ef4444',
        medium: '#f59e0b',
        strong: '#10b981'
    };
    
    const labels = {
        weak: 'Débil',
        medium: 'Media',
        strong: 'Fuerte'
    };
    
    container.innerHTML = `
        <div class="password-strength-bar">
            <div class="strength-bar" style="width: ${(strength.score / 5) * 100}%; background-color: ${colors[strength.level]}"></div>
        </div>
        <span class="strength-label" style="color: ${colors[strength.level]}">
            Fortaleza: ${labels[strength.level]}
        </span>
    `;
}

// ===== FORM VALIDATION =====
function validateForm(formElement) {
    const inputs = formElement.querySelectorAll('input[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            showFieldError(input, 'Este campo es requerido');
            isValid = false;
        } else {
            clearFieldError(input);
        }
        
        // Email validation
        if (input.type === 'email' && input.value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(input.value)) {
                showFieldError(input, 'Ingresa un email válido');
                isValid = false;
            }
        }
    });
    
    return isValid;
}

function showFieldError(input, message) {
    clearFieldError(input);
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#ef4444';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.25rem';
    
    input.parentElement.appendChild(errorDiv);
    input.style.borderColor = '#ef4444';
}

function clearFieldError(input) {
    const existingError = input.parentElement.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
    input.style.borderColor = '';
}

// ===== LOADING STATES =====
function showLoading(element, text = 'Cargando...') {
    const originalContent = element.innerHTML;
    element.dataset.originalContent = originalContent;
    
    element.innerHTML = `
        <span class="loading-spinner"></span>
        ${text}
    `;
    element.disabled = true;
}

function hideLoading(element) {
    const originalContent = element.dataset.originalContent;
    if (originalContent) {
        element.innerHTML = originalContent;
        delete element.dataset.originalContent;
    }
    element.disabled = false;
}

// ===== COPY TO CLIPBOARD =====
function copyToClipboard(text, successMessage = 'Copiado al portapapeles') {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification(successMessage, 'success');
        }).catch(err => {
            console.error('Error copying to clipboard:', err);
            fallbackCopyToClipboard(text);
        });
    } else {
        fallbackCopyToClipboard(text);
    }
}

function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showNotification('Copiado al portapapeles', 'success');
    } catch (err) {
        console.error('Fallback copy failed:', err);
        showNotification('Error al copiar', 'error');
    }
    
    document.body.removeChild(textArea);
}

// ===== KEYBOARD SHORTCUTS =====
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K for search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            const searchInput = document.querySelector('#searchInput, #quickSearchInput');
            if (searchInput) {
                searchInput.focus();
            }
        }
        
        // Escape to close modals/popups
        if (e.key === 'Escape') {
            closeAIChat();
            const suggestions = document.querySelector('.search-suggestions');
            if (suggestions) {
                suggestions.style.display = 'none';
            }
        }
        
        // Ctrl/Cmd + / for help
        if ((e.ctrlKey || e.metaKey) && e.key === '/') {
            e.preventDefault();
            toggleAIChat();
        }
    });
}

// ===== SMOOTH SCROLLING =====
function initializeSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ===== PERFORMANCE OPTIMIZATION =====
function optimizeImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// ===== ERROR HANDLING =====
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    showNotification('Se produjo un error inesperado', 'error');
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled Promise Rejection:', e.reason);
    showNotification('Error de conexión', 'error');
});

// ===== INITIALIZATION =====
// Initialize additional features when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
    initializeKeyboardShortcuts();
    initializeSmoothScrolling();
    optimizeImages();
});

// Export functions for use in other files
window.LexColombia = {
    showNotification,
    copyToClipboard,
    toggleTheme,
    toggleAIChat,
    validateForm,
    showLoading,
    hideLoading,
    debounce,
    throttle
};

// Add custom CSS for animations and effects
const customStyles = `
<style>
.search-focused {
    transform: scale(1.02);
    transition: transform 0.2s ease;
}

.loading-spinner {
    display: inline-block;
    width: 12px;
    height: 12px;
    border: 2px solid #f3f3f3;
    border-top: 2px solid var(--primary-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-right: 0.5rem;
}

.typing-dots {
    display: inline-flex;
    gap: 0.25rem;
    margin-right: 0.5rem;
}

.typing-dots span {
    width: 0.5rem;
    height: 0.5rem;
    border-radius: 50%;
    background-color: var(--text-muted);
    animation: typing 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(1) { animation-delay: -0.32s; }
.typing-dots span:nth-child(2) { animation-delay: -0.16s; }

@keyframes typing {
    0%, 80%, 100% { opacity: 0.3; transform: scale(0.8); }
    40% { opacity: 1; transform: scale(1); }
}

.password-strength-bar {
    height: 4px;
    background-color: #e2e8f0;
    border-radius: 2px;
    overflow: hidden;
    margin-bottom: 0.5rem;
}

.strength-bar {
    height: 100%;
    transition: width 0.3s ease, background-color 0.3s ease;
    border-radius: 2px;
}

.animate-in {
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.nav-links.active {
    display: flex !important;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    flex-direction: column;
    padding: 1rem;
    box-shadow: var(--shadow-lg);
    border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}

.dark-theme .nav-links.active {
    background: var(--bg-secondary);
}

@media (max-width: 768px) {
    .nav-links {
        display: none;
    }
}
</style>
`;

// Inject custom styles
document.head.insertAdjacentHTML('beforeend', customStyles);