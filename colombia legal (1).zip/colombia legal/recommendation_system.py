"""
Sistema de Recomendaciones AI para LexColombia
Implementa recomendaciones personalizadas y sugerencias inteligentes
"""

import sqlite3
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
from collections import defaultdict, Counter
import json
import re
from datetime import datetime, timedelta

class RecommendationSystem:
    def __init__(self, db_path='legislation.db'):
        self.db_path = db_path
        self.tfidf_vectorizer = None
        self.document_vectors = None
        self.user_profiles = {}
        self.document_features = None
        self.similarity_matrix = None
        
    def load_documents(self):
        """Cargar documentos para el sistema de recomendaciones"""
        conn = sqlite3.connect(self.db_path)
        
        query = """
        SELECT id, title, content, category, document_type, keywords, full_text
        FROM documents
        ORDER BY id
        """
        
        documents_df = pd.read_sql_query(query, conn)
        conn.close()
        
        return documents_df
    
    def preprocess_text(self, text):
        """Preprocesar texto para análisis"""
        if not text:
            return ""
        
        # Convertir a minúsculas
        text = text.lower()
        
        # Remover caracteres especiales pero mantener espacios y letras
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # Remover espacios múltiples
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def build_content_vectors(self):
        """Construir vectores TF-IDF para contenido de documentos"""
        documents_df = self.load_documents()
        
        # Combinar título, contenido y palabras clave
        combined_text = []
        for _, doc in documents_df.iterrows():
            text_parts = [
                doc['title'] or '',
                doc['content'] or '',
                doc['keywords'] or '',
                doc['full_text'] or ''
            ]
            combined = ' '.join(self.preprocess_text(part) for part in text_parts)
            combined_text.append(combined)
        
        # Crear vectorizador TF-IDF
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            stop_words=None,  # Mantener todas las palabras para términos legales específicos
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.95
        )
        
        # Ajustar vectorizador y transformar documentos
        self.document_vectors = self.tfidf_vectorizer.fit_transform(combined_text)
        
        # Calcular matriz de similitud entre documentos
        self.similarity_matrix = cosine_similarity(self.document_vectors)
        
        # Guardar características de documentos
        self.document_features = documents_df[['id', 'title', 'category', 'document_type']].copy()
        
        return True
    
    def build_user_profiles(self):
        """Construir perfiles de usuario basados en historial"""
        conn = sqlite3.connect(self.db_path)
        
        # Obtener historial de visualizaciones
        views_query = """
        SELECT dm.user_id, dm.document_id, dm.time_spent_seconds,
               d.category, d.document_type, d.title
        FROM document_metrics dm
        JOIN documents d ON dm.document_id = d.id
        WHERE dm.action = 'view' AND dm.user_id IS NOT NULL
        """
        
        views_df = pd.read_sql_query(views_query, conn)
        
        # Obtener historial de búsquedas
        search_query = """
        SELECT user_id, search_query, category_filter
        FROM search_metrics
        WHERE user_id IS NOT NULL AND search_query IS NOT NULL
        """
        
        search_df = pd.read_sql_query(search_query, conn)
        
        # Obtener favoritos
        favorites_query = """
        SELECT uf.user_id, uf.document_id, d.category, d.document_type
        FROM user_favorites uf
        JOIN documents d ON uf.document_id = d.id
        """
        
        try:
            # Usar la base de datos de usuarios para favoritos
            conn_users = sqlite3.connect('users.db')
            favorites_df = pd.read_sql_query(favorites_query, conn_users)
            conn_users.close()
        except:
            favorites_df = pd.DataFrame()
        
        conn.close()
        
        # Construir perfiles por usuario
        for user_id in views_df['user_id'].unique():
            if pd.isna(user_id):
                continue
                
            user_id = int(user_id)
            profile = {
                'user_id': user_id,
                'categories_interest': {},
                'document_types_interest': {},
                'viewed_documents': [],
                'search_terms': [],
                'favorite_documents': [],
                'total_time_spent': 0,
                'activity_score': 0
            }
            
            # Análisis de visualizaciones
            user_views = views_df[views_df['user_id'] == user_id]
            
            # Categorías de interés (basado en tiempo gastado)
            category_time = user_views.groupby('category')['time_spent_seconds'].sum()
            total_time = category_time.sum()
            
            if total_time > 0:
                profile['categories_interest'] = (category_time / total_time).to_dict()
            
            # Tipos de documento preferidos
            doc_type_counts = user_views['document_type'].value_counts()
            if len(doc_type_counts) > 0:
                profile['document_types_interest'] = (doc_type_counts / doc_type_counts.sum()).to_dict()
            
            # Documentos vistos
            profile['viewed_documents'] = user_views['document_id'].tolist()
            profile['total_time_spent'] = user_views['time_spent_seconds'].sum()
            
            # Términos de búsqueda
            user_searches = search_df[search_df['user_id'] == user_id]
            profile['search_terms'] = user_searches['search_query'].tolist()
            
            # Favoritos
            if not favorites_df.empty:
                user_favorites = favorites_df[favorites_df['user_id'] == user_id]
                profile['favorite_documents'] = user_favorites['document_id'].tolist()
            
            # Score de actividad
            profile['activity_score'] = (
                len(profile['viewed_documents']) * 2 +
                len(profile['search_terms']) +
                len(profile['favorite_documents']) * 3
            )
            
            self.user_profiles[user_id] = profile
        
        return len(self.user_profiles)
    
    def get_similar_documents(self, document_id, num_recommendations=5):
        """Obtener documentos similares basados en contenido"""
        if self.similarity_matrix is None:
            self.build_content_vectors()
        
        documents_df = self.load_documents()
        doc_index = documents_df[documents_df['id'] == document_id].index
        
        if len(doc_index) == 0:
            return []
        
        doc_index = doc_index[0]
        
        # Obtener similitudes
        sim_scores = list(enumerate(self.similarity_matrix[doc_index]))
        
        # Ordenar por similitud (excluyendo el documento actual)
        sim_scores = [(i, score) for i, score in sim_scores if i != doc_index]
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        
        # Obtener top recomendaciones
        top_indices = [i for i, _ in sim_scores[:num_recommendations]]
        
        recommendations = []
        for idx in top_indices:
            doc_data = documents_df.iloc[idx]
            recommendations.append({
                'document_id': int(doc_data['id']),
                'title': doc_data['title'],
                'category': doc_data['category'],
                'document_type': doc_data['document_type'],
                'similarity_score': sim_scores[top_indices.index(idx)][1]
            })
        
        return recommendations
    
    def get_personalized_recommendations(self, user_id, num_recommendations=10):
        """Obtener recomendaciones personalizadas para un usuario"""
        if user_id not in self.user_profiles:
            self.build_user_profiles()
        
        if user_id not in self.user_profiles:
            # Usuario nuevo - recomendar documentos populares
            return self.get_popular_documents(num_recommendations)
        
        profile = self.user_profiles[user_id]
        documents_df = self.load_documents()
        
        # Documentos ya vistos o en favoritos
        seen_docs = set(profile['viewed_documents'] + profile['favorite_documents'])
        
        recommendations = []
        
        # Estrategia 1: Documentos similares a los favoritos
        for fav_doc_id in profile['favorite_documents'][:3]:  # Top 3 favoritos
            similar_docs = self.get_similar_documents(fav_doc_id, 3)
            for doc in similar_docs:
                if doc['document_id'] not in seen_docs:
                    doc['reason'] = 'Similar a tus favoritos'
                    doc['confidence'] = doc['similarity_score'] * 0.9
                    recommendations.append(doc)
        
        # Estrategia 2: Documentos de categorías de interés
        for category, interest_score in profile['categories_interest'].items():
            if interest_score > 0.2:  # Solo categorías con interés significativo
                category_docs = documents_df[
                    (documents_df['category'] == category) & 
                    (~documents_df['id'].isin(seen_docs))
                ][:3]
                
                for _, doc in category_docs.iterrows():
                    recommendations.append({
                        'document_id': int(doc['id']),
                        'title': doc['title'],
                        'category': doc['category'],
                        'document_type': doc['document_type'],
                        'reason': f'Te gusta la categoría {category}',
                        'confidence': interest_score * 0.8
                    })
        
        # Estrategia 3: Documentos populares que no ha visto
        popular_docs = self.get_popular_documents(5)
        for doc in popular_docs:
            if doc['document_id'] not in seen_docs:
                doc['reason'] = 'Popular entre usuarios'
                doc['confidence'] = 0.6
                recommendations.append(doc)
        
        # Remover duplicados y ordenar por confianza
        seen_rec_ids = set()
        unique_recommendations = []
        
        for rec in recommendations:
            if rec['document_id'] not in seen_rec_ids:
                seen_rec_ids.add(rec['document_id'])
                unique_recommendations.append(rec)
        
        unique_recommendations.sort(key=lambda x: x.get('confidence', 0), reverse=True)
        
        return unique_recommendations[:num_recommendations]
    
    def get_popular_documents(self, num_recommendations=10):
        """Obtener documentos más populares"""
        conn = sqlite3.connect(self.db_path)
        
        query = """
        SELECT dm.document_id, d.title, d.category, d.document_type,
               COUNT(*) as view_count,
               AVG(dm.time_spent_seconds) as avg_time_spent
        FROM document_metrics dm
        JOIN documents d ON dm.document_id = d.id
        WHERE dm.action = 'view'
        GROUP BY dm.document_id
        ORDER BY view_count DESC, avg_time_spent DESC
        LIMIT ?
        """
        
        popular_df = pd.read_sql_query(query, conn, params=[num_recommendations])
        conn.close()
        
        recommendations = []
        for _, doc in popular_df.iterrows():
            recommendations.append({
                'document_id': int(doc['document_id']),
                'title': doc['title'],
                'category': doc['category'],
                'document_type': doc['document_type'],
                'view_count': int(doc['view_count']),
                'avg_time_spent': float(doc['avg_time_spent']),
                'popularity_score': float(doc['view_count'])
            })
        
        return recommendations
    
    def get_search_suggestions(self, partial_query, user_id=None, num_suggestions=8):
        """Obtener sugerencias de búsqueda inteligentes"""
        conn = sqlite3.connect(self.db_path)
        
        # Obtener términos populares que coincidan
        popular_query = """
        SELECT search_query, COUNT(*) as frequency
        FROM search_metrics
        WHERE search_query LIKE ? AND search_query IS NOT NULL
        GROUP BY search_query
        ORDER BY frequency DESC
        LIMIT ?
        """
        
        pattern = f"%{partial_query}%"
        popular_df = pd.read_sql_query(popular_query, conn, params=[pattern, num_suggestions])
        
        suggestions = []
        
        # Sugerencias basadas en popularidad
        for _, row in popular_df.iterrows():
            suggestions.append({
                'query': row['search_query'],
                'type': 'popular',
                'frequency': int(row['frequency']),
                'reason': 'Búsqueda popular'
            })
        
        # Sugerencias basadas en documentos similares
        documents_df = self.load_documents()
        title_matches = documents_df[
            documents_df['title'].str.contains(partial_query, case=False, na=False)
        ]
        
        for _, doc in title_matches.head(3).iterrows():
            suggestions.append({
                'query': doc['title'],
                'type': 'document_title',
                'document_id': int(doc['id']),
                'category': doc['category'],
                'reason': 'Título de documento'
            })
        
        # Sugerencias personalizadas si hay perfil de usuario
        if user_id and user_id in self.user_profiles:
            profile = self.user_profiles[user_id]
            
            # Sugerir búsquedas relacionadas con categorías de interés
            for category in profile['categories_interest'].keys():
                if partial_query.lower() in category.lower():
                    suggestions.append({
                        'query': f"{partial_query} {category}",
                        'type': 'personalized',
                        'reason': 'Basado en tus intereses'
                    })
        
        conn.close()
        
        # Remover duplicados y limitar resultados
        seen_queries = set()
        unique_suggestions = []
        
        for suggestion in suggestions:
            if suggestion['query'] not in seen_queries:
                seen_queries.add(suggestion['query'])
                unique_suggestions.append(suggestion)
        
        return unique_suggestions[:num_suggestions]
    
    def get_trending_topics(self, days=7):
        """Obtener temas en tendencia"""
        conn = sqlite3.connect(self.db_path)
        
        # Términos más buscados recientemente
        trending_query = """
        SELECT search_query, COUNT(*) as recent_frequency
        FROM search_metrics
        WHERE timestamp >= date('now', '-{} days')
        AND search_query IS NOT NULL
        GROUP BY search_query
        ORDER BY recent_frequency DESC
        LIMIT 10
        """.format(days)
        
        trending_df = pd.read_sql_query(trending_query, conn)
        
        # Categorías más consultadas
        category_query = """
        SELECT d.category, COUNT(*) as recent_views
        FROM document_metrics dm
        JOIN documents d ON dm.document_id = d.id
        WHERE dm.timestamp >= date('now', '-{} days')
        AND dm.action = 'view'
        GROUP BY d.category
        ORDER BY recent_views DESC
        LIMIT 5
        """.format(days)
        
        category_df = pd.read_sql_query(category_query, conn)
        conn.close()
        
        trending_topics = {
            'search_terms': trending_df.to_dict('records'),
            'categories': category_df.to_dict('records'),
            'period': f'{days} days',
            'generated_at': datetime.now().isoformat()
        }
        
        return trending_topics
    
    def update_user_interaction(self, user_id, document_id, interaction_type='view', rating=None):
        """Actualizar interacción del usuario para mejorar recomendaciones"""
        if user_id not in self.user_profiles:
            self.build_user_profiles()
        
        # Registrar interacción para futuras mejoras del modelo
        # Por ahora, simplemente rebuildeamos el perfil periódicamente
        
        # En una implementación más avanzada, aquí se actualizaría
        # el perfil en tiempo real y se reentrenarían los modelos
        
        return True
    
    def generate_recommendation_report(self, user_id):
        """Generar reporte de recomendaciones para un usuario"""
        if user_id not in self.user_profiles:
            self.build_user_profiles()
        
        report = {
            'user_id': user_id,
            'generated_at': datetime.now().isoformat(),
            'personalized_recommendations': self.get_personalized_recommendations(user_id),
            'trending_topics': self.get_trending_topics(),
            'user_profile_summary': {}
        }
        
        if user_id in self.user_profiles:
            profile = self.user_profiles[user_id]
            report['user_profile_summary'] = {
                'activity_score': profile['activity_score'],
                'total_documents_viewed': len(profile['viewed_documents']),
                'total_searches': len(profile['search_terms']),
                'favorite_categories': list(profile['categories_interest'].keys())[:3],
                'total_time_spent': profile['total_time_spent']
            }
        
        return report

# Instancia global del sistema de recomendaciones
recommendation_system = RecommendationSystem()