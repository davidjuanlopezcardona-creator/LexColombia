"""
Sistema de Analytics Predictivos para Colombia Legal
Implementa predicciones, forecasting y análisis de tendencias
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import json
import warnings
warnings.filterwarnings('ignore')

class PredictiveAnalytics:
    def __init__(self, db_path='legislation.db'):
        self.db_path = db_path
        self.models = {}
        self.scalers = {}
        
    def get_historical_data(self, days=90):
        """Obtener datos históricos para análisis predictivo"""
        conn = sqlite3.connect(self.db_path)
        
        # Datos de búsquedas por día
        search_query = """
        SELECT DATE(timestamp) as date, 
               COUNT(*) as daily_searches,
               COUNT(DISTINCT user_id) as unique_users,
               AVG(search_duration_ms) as avg_duration,
               COUNT(DISTINCT search_query) as unique_queries
        FROM search_metrics 
        WHERE timestamp >= date('now', '-{} days')
        GROUP BY DATE(timestamp)
        ORDER BY date
        """.format(days)
        
        search_df = pd.read_sql_query(search_query, conn)
        
        # Datos de visualizaciones por día
        views_query = """
        SELECT DATE(timestamp) as date,
               COUNT(*) as daily_views,
               COUNT(DISTINCT document_id) as unique_documents,
               AVG(time_spent_seconds) as avg_time_spent
        FROM document_metrics 
        WHERE timestamp >= date('now', '-{} days')
        GROUP BY DATE(timestamp)
        ORDER BY date
        """.format(days)
        
        views_df = pd.read_sql_query(views_query, conn)
        
        # Datos de actividad general por día
        activity_query = """
        SELECT DATE(timestamp) as date,
               COUNT(*) as daily_activities,
               COUNT(DISTINCT user_id) as active_users
        FROM user_activity 
        WHERE timestamp >= date('now', '-{} days')
        GROUP BY DATE(timestamp)
        ORDER BY date
        """.format(days)
        
        activity_df = pd.read_sql_query(activity_query, conn)
        
        conn.close()
        
        # Combinar datos
        historical_data = pd.merge(search_df, views_df, on='date', how='outer')
        historical_data = pd.merge(historical_data, activity_df, on='date', how='outer')
        
        # Rellenar valores faltantes
        historical_data = historical_data.fillna(0)
        
        # Convertir fecha a datetime
        historical_data['date'] = pd.to_datetime(historical_data['date'])
        
        return historical_data
    
    def prepare_features(self, df):
        """Preparar características para el modelo predictivo"""
        # Agregar características temporales
        df['day_of_week'] = df['date'].dt.dayofweek
        df['month'] = df['date'].dt.month
        df['day_of_month'] = df['date'].dt.day
        df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
        
        # Agregar features de tendencia
        df['days_since_start'] = (df['date'] - df['date'].min()).dt.days
        
        # Agregar medias móviles
        for col in ['daily_searches', 'daily_views', 'daily_activities']:
            if col in df.columns:
                df[f'{col}_ma_7'] = df[col].rolling(window=7, min_periods=1).mean()
                df[f'{col}_ma_30'] = df[col].rolling(window=30, min_periods=1).mean()
        
        return df
    
    def train_prediction_model(self, target_column='daily_searches'):
        """Entrenar modelo predictivo para una métrica específica"""
        data = self.get_historical_data()
        
        if len(data) < 7:
            return None, "Insufficient data for training"
        
        # Preparar características
        data = self.prepare_features(data)
        
        # Seleccionar características
        feature_columns = [
            'day_of_week', 'month', 'day_of_month', 'is_weekend', 'days_since_start'
        ]
        
        # Agregar medias móviles si existen
        ma_columns = [col for col in data.columns if '_ma_' in col and target_column in col]
        feature_columns.extend(ma_columns)
        
        # Preparar datos para entrenamiento
        X = data[feature_columns].fillna(0)
        y = data[target_column].fillna(0)
        
        # Dividir en entrenamiento y prueba (80/20)
        split_idx = int(len(X) * 0.8)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Escalar características
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Entrenar modelo
        model = LinearRegression()
        model.fit(X_train_scaled, y_train)
        
        # Evaluar modelo
        y_pred = model.predict(X_test_scaled)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        # Guardar modelo y scaler
        self.models[target_column] = model
        self.scalers[target_column] = scaler
        
        return {
            'target': target_column,
            'mae': mae,
            'r2_score': r2,
            'training_samples': len(X_train),
            'test_samples': len(X_test),
            'feature_importance': dict(zip(feature_columns, abs(model.coef_)))
        }, None
    
    def predict_next_days(self, target_column='daily_searches', days=7):
        """Predecir valores para los próximos días"""
        if target_column not in self.models:
            result, error = self.train_prediction_model(target_column)
            if error:
                return None, error
        
        model = self.models[target_column]
        scaler = self.scalers[target_column]
        
        # Obtener datos recientes para context
        recent_data = self.get_historical_data(days=30)
        recent_data = self.prepare_features(recent_data)
        
        predictions = []
        last_date = recent_data['date'].max()
        
        for i in range(1, days + 1):
            future_date = last_date + timedelta(days=i)
            
            # Crear características para fecha futura
            features = {
                'day_of_week': future_date.weekday(),
                'month': future_date.month,
                'day_of_month': future_date.day,
                'is_weekend': 1 if future_date.weekday() >= 5 else 0,
                'days_since_start': (future_date - recent_data['date'].min()).days
            }
            
            # Agregar medias móviles (usar últimos valores conocidos)
            for col in recent_data.columns:
                if '_ma_' in col and target_column in col:
                    features[col] = recent_data[col].iloc[-1] if len(recent_data) > 0 else 0
            
            # Preparar para predicción
            feature_vector = [features.get(col, 0) for col in scaler.feature_names_in_]
            feature_vector_scaled = scaler.transform([feature_vector])
            
            # Hacer predicción
            prediction = model.predict(feature_vector_scaled)[0]
            prediction = max(0, prediction)  # No puede ser negativo
            
            predictions.append({
                'date': future_date.strftime('%Y-%m-%d'),
                'predicted_value': round(prediction, 2),
                'day_of_week': future_date.strftime('%A'),
                'confidence': 'medium'  # Simplificado por ahora
            })
        
        return predictions, None
    
    def analyze_trends(self):
        """Analizar tendencias en los datos"""
        data = self.get_historical_data()
        
        if len(data) < 7:
            return None, "Insufficient data for trend analysis"
        
        trends = {}
        
        # Analizar tendencias para métricas principales
        metrics = ['daily_searches', 'daily_views', 'daily_activities', 'unique_users']
        
        for metric in metrics:
            if metric in data.columns:
                values = data[metric].fillna(0)
                
                # Calcular tendencia (slope de regresión lineal)
                x = np.arange(len(values))
                slope, intercept = np.polyfit(x, values, 1)
                
                # Calcular estadísticas
                avg_value = values.mean()
                recent_avg = values.tail(7).mean()  # Última semana
                growth_rate = ((recent_avg - avg_value) / avg_value * 100) if avg_value > 0 else 0
                
                # Determinar dirección de tendencia
                if slope > 0.1:
                    direction = 'ascending'
                elif slope < -0.1:
                    direction = 'descending'
                else:
                    direction = 'stable'
                
                trends[metric] = {
                    'slope': slope,
                    'direction': direction,
                    'average_value': round(avg_value, 2),
                    'recent_average': round(recent_avg, 2),
                    'growth_rate': round(growth_rate, 2),
                    'trend_strength': 'strong' if abs(slope) > 1 else 'weak'
                }
        
        return trends, None
    
    def seasonal_analysis(self):
        """Análisis de patrones estacionales"""
        data = self.get_historical_data(days=180)  # 6 meses
        
        if len(data) < 30:
            return None, "Insufficient data for seasonal analysis"
        
        data = self.prepare_features(data)
        
        seasonal_patterns = {}
        
        # Análisis por día de la semana
        day_patterns = data.groupby('day_of_week').agg({
            'daily_searches': 'mean',
            'daily_views': 'mean',
            'unique_users': 'mean'
        }).round(2)
        
        # Convertir índices a nombres de días
        day_names = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']
        day_patterns.index = day_names
        
        # Análisis por mes
        month_patterns = data.groupby('month').agg({
            'daily_searches': 'mean',
            'daily_views': 'mean',
            'unique_users': 'mean'
        }).round(2)
        
        # Patrones de fin de semana vs días laborales
        weekend_comparison = data.groupby('is_weekend').agg({
            'daily_searches': 'mean',
            'daily_views': 'mean',
            'unique_users': 'mean'
        }).round(2)
        
        weekend_comparison.index = ['Días Laborales', 'Fin de Semana']
        
        seasonal_patterns = {
            'daily_patterns': day_patterns.to_dict(),
            'monthly_patterns': month_patterns.to_dict(),
            'weekend_comparison': weekend_comparison.to_dict(),
            'peak_day': day_patterns['daily_searches'].idxmax(),
            'peak_month': month_patterns['daily_searches'].idxmax() if len(month_patterns) > 0 else None
        }
        
        return seasonal_patterns, None
    
    def generate_forecast_report(self, days=14):
        """Generar reporte completo de forecast"""
        report = {
            'generated_at': datetime.now().isoformat(),
            'forecast_period': f'{days} days',
            'predictions': {},
            'trends': {},
            'seasonal_analysis': {}
        }
        
        # Generar predicciones para métricas principales
        metrics = ['daily_searches', 'daily_views', 'daily_activities']
        
        for metric in metrics:
            predictions, error = self.predict_next_days(metric, days)
            if not error:
                report['predictions'][metric] = predictions
            else:
                report['predictions'][metric] = {'error': error}
        
        # Análisis de tendencias
        trends, error = self.analyze_trends()
        if not error:
            report['trends'] = trends
        else:
            report['trends'] = {'error': error}
        
        # Análisis estacional
        seasonal, error = self.seasonal_analysis()
        if not error:
            report['seasonal_analysis'] = seasonal
        else:
            report['seasonal_analysis'] = {'error': error}
        
        return report
    
    def save_forecast_report(self, report, filename=None):
        """Guardar reporte de forecast en archivo"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'forecast_report_{timestamp}.json'
        
        import os
        reports_dir = 'reports/forecasts'
        os.makedirs(reports_dir, exist_ok=True)
        
        filepath = os.path.join(reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        return filepath

# Instancia global del sistema predictivo
predictive_analytics = PredictiveAnalytics()