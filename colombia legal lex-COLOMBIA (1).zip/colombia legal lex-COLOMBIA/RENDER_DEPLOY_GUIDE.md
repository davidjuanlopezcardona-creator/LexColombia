# 🚀 Guía de Despliegue en Render.com - Colombia Legal

## 🎯 Preparación del Proyecto

**¡Perfecto!** Tu proyecto **Colombia Legal** ya está completamente preparado para Render con:

✅ **Procfile** optimizado para producción  
✅ **requirements.txt** completo con todas las dependencias  
✅ **build.sh** script de construcción automática  
✅ **render.yaml** configuración específica para Render  

---

## 📋 Pasos para Subir a Render

### **1. 📁 Subir Código a GitHub** *(Requerido)*

```bash
# En tu terminal local, navega al directorio del proyecto
cd "ruta/a/colombia legal"

# Inicializar repositorio Git (si no existe)
git init

# Agregar todos los archivos
git add .

# Hacer primer commit
git commit -m "🚀 Colombia Legal v2.0.0 - Ready for Render deployment"

# Crear repositorio en GitHub y conectar
git remote add origin https://github.com/tu-usuario/colombia-legal.git

# Subir a GitHub
git push -u origin main
```

### **2. 🌐 Crear Cuenta en Render**

1. Ve a **https://render.com**
2. Haz click en **"Get Started for Free"**
3. Regístrate con GitHub (recomendado)
4. Conecta tu cuenta de GitHub con Render

### **3. 🚀 Crear Web Service en Render**

#### **Paso A: Nuevo Servicio**
1. En tu dashboard de Render, click **"New +"**
2. Selecciona **"Web Service"**
3. Conecta tu repositorio **"colombia-legal"**
4. Click **"Connect"**

#### **Paso B: Configuración del Servicio**

**📝 Configuración Básica:**
```
🏷️ Name: colombia-legal
🌍 Region: Oregon (US West) o Frankfurt (Europe)
🌿 Branch: main
📁 Root Directory: (dejar vacío)
🐍 Runtime: Python 3
```

**⚙️ Build & Deploy:**
```
🔨 Build Command: ./build.sh
🚀 Start Command: gunicorn app:app --bind 0.0.0.0:$PORT --workers 2
```

**💰 Plan:**
```
💳 Plan: Free Tier (suficiente para pruebas)
    └── 512MB RAM, 0.1 CPU
    └── Suspende después de inactividad
    └── 750 horas/mes gratis

💼 Para producción: Starter ($7/mes)
    └── 512MB RAM, 0.5 CPU  
    └── Siempre activo
    └── Dominio personalizado
```

### **4. 🔧 Variables de Entorno**

En la sección **"Environment"** agregar:

```bash
# Variables Esenciales
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=tu_clave_super_secreta_render_2025

# Variables Opcionales
AI_MODEL_CACHE=True
LOG_LEVEL=INFO
PYTHONPATH=/opt/render/project/src
```

### **5. 🎯 Deploy Inicial**

1. Click **"Create Web Service"**
2. Render iniciará el build automáticamente
3. ⏳ Espera 3-5 minutos (primera vez)
4. 📺 Monitorea los logs en tiempo real

---

## 📊 Logs de Deploy Exitoso

```bash
==> Building application
==> Installing dependencies
==> Running build.sh
✅ Build completado para Colombia Legal
==> Starting gunicorn
==> Your service is live at: https://colombia-legal-xxxx.onrender.com
```

---

## 🌍 Acceso a tu Aplicación

### **🔗 URL Automática**
```
https://colombia-legal-xxxx.onrender.com
```
*(Render asigna un subdominio único)*

### **🎯 Testing Post-Deploy**

**Verificar funcionalidades:**
1. **✅ Página principal** carga correctamente
2. **✅ Sistema de registro** funciona
3. **✅ Búsqueda** encuentra documentos
4. **✅ Dashboard analytics** (usuarios admin)
5. **✅ Exportación PDF** funciona
6. **✅ API endpoints** responden

---

## ⚙️ Configuraciones Adicionales

### **🔒 Dominio Personalizado** *(Plan Starter+)*

1. En Render Dashboard → **"Settings"**
2. **"Custom Domains"** → **"Add"**
3. Configurar DNS:
   ```
   Type: CNAME
   Name: www (o subdominio deseado)
   Value: colombia-legal-xxxx.onrender.com
   ```

### **📊 Monitoreo y Logs**

**Ver logs en tiempo real:**
1. Dashboard → **"Logs"**
2. Click **"Live tail"**
3. Monitorear requests y errores

**Métricas disponibles:**
- 📈 CPU usage
- 💾 Memory usage  
- 🌐 HTTP requests
- ⏱️ Response times

### **🔄 Auto-Deploy**

**Deploy automático configurado:**
```bash
# Cada push a main triggerea nuevo deploy
git add .
git commit -m "🔄 Actualización Colombia Legal"
git push origin main
# → Render inicia build automáticamente
```

---

## 🛠️ Troubleshooting

### **❌ Problemas Comunes**

#### **Build Fallido - Dependencias**
```bash
# Error: No module named 'pandas'
# Solución: Verificar requirements.txt
pip freeze > requirements.txt
git add requirements.txt && git commit -m "📦 Fix dependencies" && git push
```

#### **Timeout en Build**
```bash
# Si el build toma >15 minutos
# Solución: Optimizar requirements.txt
# Remover dependencias innecesarias
# Usar versiones específicas
```

#### **Error 503 - Service Unavailable**
```bash
# Verificar start command en configuración:
gunicorn app:app --bind 0.0.0.0:$PORT --workers 2

# Revisar logs para errores de inicio
```

#### **Base de Datos no Persistente**
```bash
# Free tier: DB se resetea en cada deploy
# Solución: Upgrade a plan Starter para persistent disk
# O usar external DB (PostgreSQL en Render)
```

### **🔧 Optimizaciones para Free Tier**

#### **Reducir Uso de Memoria**
```python
# En app.py - Configuración optimizada
import os
if os.environ.get('RENDER'):
    # Configuración específica para Render
    app.config['MAX_WORKERS'] = 1
    app.config['AI_MODEL_CACHE'] = False
```

#### **Evitar Sleep de Free Tier**
```bash
# Mantener activo con cron job (cada 14 min)
*/14 * * * * curl https://colombia-legal-xxxx.onrender.com

# O usar servicio como UptimeRobot
```

---

## 📈 Escalabilidad en Render

### **💼 Plan Starter ($7/mes)**
- ✅ 512MB RAM, 0.5 CPU
- ✅ Always-on (no sleep)
- ✅ Persistent disk 
- ✅ Custom domains
- ✅ SSL automático

### **🚀 Plan Professional ($25/mes)**
- ✅ 2GB RAM, 1 CPU
- ✅ Horizontal scaling
- ✅ Background workers
- ✅ PostgreSQL incluida

### **🏢 Para Empresas**
- ✅ Dedicated instances
- ✅ VPC privada
- ✅ Support prioritario
- ✅ SLA 99.9%

---

## 🎯 Checklist Final Pre-Deploy

```bash
☐ Código subido a GitHub
☐ requirements.txt completo
☐ Procfile configurado
☐ build.sh executable
☐ Variables de entorno definidas
☐ Secret key segura configurada
☐ Plan de Render seleccionado
☐ Dominio personalizado (opcional)
☐ Monitoreo configurado
```

---

## 🎉 ¡Deploy Exitoso!

**Una vez completado el deploy, tendrás:**

🌐 **Colombia Legal** funcionando en la nube  
📊 **Analytics** disponibles 24/7  
🤖 **IA legal** accesible globalmente  
🔒 **Seguridad** nivel empresarial  
📱 **Acceso móvil** responsive  
⚡ **Performance** optimizado  

### **🔗 Próximos Pasos**

1. **Compartir URL** con usuarios objetivo
2. **Monitorear métricas** de uso
3. **Recopilar feedback** de usuarios
4. **Iterar y mejorar** basado en datos
5. **Considerar upgrade** según crecimiento

---

## 📞 Soporte Render

- 📚 **Docs:** https://render.com/docs
- 💬 **Community:** https://community.render.com
- 📧 **Support:** Tickets desde dashboard
- 🐦 **Twitter:** @render

---

## 🏆 ¡Felicitaciones!

**Colombia Legal** ahora está desplegado profesionalmente en **Render** y disponible para usuarios en todo el mundo. 

**Tu plataforma legal está lista para impactar la justicia en Colombia** 🇨🇴⚖️

---

*📋 Creado por: Vicente Soto Liemann, Juan David Cardona López, Sharon Sofia Castellanos Alvares*  
*🚀 Deploy guide para Colombia Legal v2.0.0*