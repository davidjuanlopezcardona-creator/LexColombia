# Build script para Render
#!/bin/bash

# Instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt

# Crear directorios necesarios
mkdir -p logs
mkdir -p reports
mkdir -p reports/forecasts

# Inicializar base de datos
python -c "from app import init_db; init_db()"

echo "✅ Build completado para Colombia Legal"