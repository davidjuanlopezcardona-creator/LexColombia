# Configuración específica para entorno Render
import os

def configure_for_render():
    """Configuraciones específicas para Render.com"""
    
    # Detectar si estamos en Render
    if os.environ.get('RENDER'):
        print("🌐 Configurando Colombia Legal para Render...")
        
        # Configuraciones de memoria optimizadas
        os.environ.setdefault('AI_MODEL_CACHE', 'False')
        os.environ.setdefault('MAX_WORKERS', '2')
        os.environ.setdefault('LOG_LEVEL', 'INFO')
        
        # Configuración de paths
        os.environ.setdefault('DATABASE_PATH', '/opt/render/project/src/legislation.db')
        os.environ.setdefault('USERS_DATABASE_PATH', '/opt/render/project/src/users.db')
        
        print("✅ Configuración de Render aplicada")
        
    return True

# Configurar automáticamente al importar
configure_for_render()